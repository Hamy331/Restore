import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_en.dart';
import 'app_localizations_vi.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale)
    : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
        delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('en'),
    Locale('vi'),
  ];

  /// No description provided for @appName.
  ///
  /// In en, this message translates to:
  /// **'ReStore'**
  String get appName;

  /// No description provided for @loginTitle.
  ///
  /// In en, this message translates to:
  /// **'Login to your Account'**
  String get loginTitle;

  /// No description provided for @email.
  ///
  /// In en, this message translates to:
  /// **'Email'**
  String get email;

  /// No description provided for @password.
  ///
  /// In en, this message translates to:
  /// **'Password'**
  String get password;

  /// No description provided for @signIn.
  ///
  /// In en, this message translates to:
  /// **'Sign in'**
  String get signIn;

  /// No description provided for @orSignInWith.
  ///
  /// In en, this message translates to:
  /// **'Or sign in with'**
  String get orSignInWith;

  /// No description provided for @dontHaveAccount.
  ///
  /// In en, this message translates to:
  /// **'Don\'t have an account?'**
  String get dontHaveAccount;

  /// No description provided for @signUp.
  ///
  /// In en, this message translates to:
  /// **'Sign up'**
  String get signUp;

  /// No description provided for @successTitle.
  ///
  /// In en, this message translates to:
  /// **'Success'**
  String get successTitle;

  /// No description provided for @errorTitle.
  ///
  /// In en, this message translates to:
  /// **'Error occurred'**
  String get errorTitle;

  /// No description provided for @warningTitle.
  ///
  /// In en, this message translates to:
  /// **'Warning'**
  String get warningTitle;

  /// No description provided for @infoTitle.
  ///
  /// In en, this message translates to:
  /// **'Information'**
  String get infoTitle;

  /// No description provided for @deviceNotSupported.
  ///
  /// In en, this message translates to:
  /// **'Device not supported'**
  String get deviceNotSupported;

  /// No description provided for @deviceNotSupportedDesc.
  ///
  /// In en, this message translates to:
  /// **'The ReStore application is currently designed and optimized exclusively for mobile handheld experiences.'**
  String get deviceNotSupportedDesc;

  /// No description provided for @loginSuccessMsg.
  ///
  /// In en, this message translates to:
  /// **'Successfully logged into the system.'**
  String get loginSuccessMsg;

  /// No description provided for @loginErrorMsg.
  ///
  /// In en, this message translates to:
  /// **'Invalid email or password.'**
  String get loginErrorMsg;

  /// No description provided for @verifyOtpTitle.
  ///
  /// In en, this message translates to:
  /// **'Verify OTP'**
  String get verifyOtpTitle;

  /// No description provided for @checkYourEmail.
  ///
  /// In en, this message translates to:
  /// **'Check your email'**
  String get checkYourEmail;

  /// No description provided for @otpSentToEmail.
  ///
  /// In en, this message translates to:
  /// **'An OTP has been sent to {email}. Enter the 6 digits to continue.'**
  String otpSentToEmail(String email);

  /// No description provided for @otpValidFor.
  ///
  /// In en, this message translates to:
  /// **'You can resend the code in {time}'**
  String otpValidFor(String time);

  /// No description provided for @verifyEmailTitle.
  ///
  /// In en, this message translates to:
  /// **'Verify Email'**
  String get verifyEmailTitle;

  /// No description provided for @enterVerificationCode.
  ///
  /// In en, this message translates to:
  /// **'Enter verification code'**
  String get enterVerificationCode;

  /// No description provided for @verifyOtpButton.
  ///
  /// In en, this message translates to:
  /// **'Verify OTP'**
  String get verifyOtpButton;

  /// No description provided for @verifyEmailButton.
  ///
  /// In en, this message translates to:
  /// **'Verify email'**
  String get verifyEmailButton;

  /// No description provided for @resendOtp.
  ///
  /// In en, this message translates to:
  /// **'Didn\'t receive code? Resend OTP'**
  String get resendOtp;

  /// No description provided for @otpExpireInfo.
  ///
  /// In en, this message translates to:
  /// **'The code is for one-time use and expires in 5 minutes.'**
  String get otpExpireInfo;

  /// No description provided for @emailVerifyInfo.
  ///
  /// In en, this message translates to:
  /// **'You can continue browsing after verifying your email.'**
  String get emailVerifyInfo;

  /// No description provided for @invalidOtpError.
  ///
  /// In en, this message translates to:
  /// **'Invalid OTP. Please check and try again.'**
  String get invalidOtpError;

  /// No description provided for @accountTitle.
  ///
  /// In en, this message translates to:
  /// **'Account'**
  String get accountTitle;

  /// No description provided for @settingsTitle.
  ///
  /// In en, this message translates to:
  /// **'Settings'**
  String get settingsTitle;

  /// No description provided for @memberSince.
  ///
  /// In en, this message translates to:
  /// **'Member since {year}'**
  String memberSince(String year);

  /// No description provided for @editProfile.
  ///
  /// In en, this message translates to:
  /// **'Edit profile'**
  String get editProfile;

  /// No description provided for @activeListings.
  ///
  /// In en, this message translates to:
  /// **'Active listings'**
  String get activeListings;

  /// No description provided for @soldListings.
  ///
  /// In en, this message translates to:
  /// **'Sold listings'**
  String get soldListings;

  /// No description provided for @myAccount.
  ///
  /// In en, this message translates to:
  /// **'My account'**
  String get myAccount;

  /// No description provided for @savedListings.
  ///
  /// In en, this message translates to:
  /// **'Saved listings'**
  String get savedListings;

  /// No description provided for @reviews.
  ///
  /// In en, this message translates to:
  /// **'Reviews'**
  String get reviews;

  /// No description provided for @notifications.
  ///
  /// In en, this message translates to:
  /// **'Notifications'**
  String get notifications;

  /// No description provided for @addressArea.
  ///
  /// In en, this message translates to:
  /// **'Address / Area'**
  String get addressArea;

  /// No description provided for @restoreAi.
  ///
  /// In en, this message translates to:
  /// **'ReStore AI'**
  String get restoreAi;

  /// No description provided for @help.
  ///
  /// In en, this message translates to:
  /// **'Help'**
  String get help;

  /// No description provided for @logout.
  ///
  /// In en, this message translates to:
  /// **'Log out'**
  String get logout;

  /// No description provided for @newCount.
  ///
  /// In en, this message translates to:
  /// **'{count} new'**
  String newCount(int count);

  /// No description provided for @editProfileTitle.
  ///
  /// In en, this message translates to:
  /// **'Edit profile'**
  String get editProfileTitle;

  /// No description provided for @changeAvatar.
  ///
  /// In en, this message translates to:
  /// **'Change profile photo'**
  String get changeAvatar;

  /// No description provided for @fullName.
  ///
  /// In en, this message translates to:
  /// **'Full name'**
  String get fullName;

  /// No description provided for @phoneNumber.
  ///
  /// In en, this message translates to:
  /// **'Phone number'**
  String get phoneNumber;

  /// No description provided for @birthday.
  ///
  /// In en, this message translates to:
  /// **'Date of birth'**
  String get birthday;

  /// No description provided for @gender.
  ///
  /// In en, this message translates to:
  /// **'Gender'**
  String get gender;

  /// No description provided for @male.
  ///
  /// In en, this message translates to:
  /// **'Male'**
  String get male;

  /// No description provided for @female.
  ///
  /// In en, this message translates to:
  /// **'Female'**
  String get female;

  /// No description provided for @other.
  ///
  /// In en, this message translates to:
  /// **'Other'**
  String get other;

  /// No description provided for @district1Hcm.
  ///
  /// In en, this message translates to:
  /// **'District 1, Ho Chi Minh City'**
  String get district1Hcm;

  /// No description provided for @thuDucHcm.
  ///
  /// In en, this message translates to:
  /// **'Thu Duc, Ho Chi Minh City'**
  String get thuDucHcm;

  /// No description provided for @district3Hcm.
  ///
  /// In en, this message translates to:
  /// **'District 3, Ho Chi Minh City'**
  String get district3Hcm;

  /// No description provided for @saveChanges.
  ///
  /// In en, this message translates to:
  /// **'Save changes'**
  String get saveChanges;

  /// No description provided for @options.
  ///
  /// In en, this message translates to:
  /// **'Options'**
  String get options;

  /// No description provided for @receiveNotifications.
  ///
  /// In en, this message translates to:
  /// **'Receive notifications'**
  String get receiveNotifications;

  /// No description provided for @privacy.
  ///
  /// In en, this message translates to:
  /// **'Privacy'**
  String get privacy;

  /// No description provided for @changePassword.
  ///
  /// In en, this message translates to:
  /// **'Change password'**
  String get changePassword;

  /// No description provided for @helpSupport.
  ///
  /// In en, this message translates to:
  /// **'Help / Support'**
  String get helpSupport;

  /// No description provided for @termsPolicies.
  ///
  /// In en, this message translates to:
  /// **'Terms & policies'**
  String get termsPolicies;

  /// No description provided for @savedCount.
  ///
  /// In en, this message translates to:
  /// **'{count} saved listings'**
  String savedCount(int count);

  /// No description provided for @tapHeartToRemove.
  ///
  /// In en, this message translates to:
  /// **'Tap ♡ to remove'**
  String get tapHeartToRemove;

  /// No description provided for @emptySavedTitle.
  ///
  /// In en, this message translates to:
  /// **'No saved listings yet'**
  String get emptySavedTitle;

  /// No description provided for @emptySavedDescription.
  ///
  /// In en, this message translates to:
  /// **'Save listings you like to find them faster later.'**
  String get emptySavedDescription;

  /// No description provided for @exploreProducts.
  ///
  /// In en, this message translates to:
  /// **'Explore products'**
  String get exploreProducts;

  /// No description provided for @today.
  ///
  /// In en, this message translates to:
  /// **'Today'**
  String get today;

  /// No description provided for @yesterday.
  ///
  /// In en, this message translates to:
  /// **'Yesterday'**
  String get yesterday;

  /// No description provided for @earlier.
  ///
  /// In en, this message translates to:
  /// **'Earlier'**
  String get earlier;

  /// No description provided for @newMessage.
  ///
  /// In en, this message translates to:
  /// **'New message'**
  String get newMessage;

  /// No description provided for @newMessageDescription.
  ///
  /// In en, this message translates to:
  /// **'Minh Anh sent another photo of the Canon AE-1.'**
  String get newMessageDescription;

  /// No description provided for @newOffer.
  ///
  /// In en, this message translates to:
  /// **'New price offer'**
  String get newOffer;

  /// No description provided for @newOfferDescription.
  ///
  /// In en, this message translates to:
  /// **'There is a 2,200,000 đ offer for the Canon AE-1 listing.'**
  String get newOfferDescription;

  /// No description provided for @offerResponse.
  ///
  /// In en, this message translates to:
  /// **'Offer response'**
  String get offerResponse;

  /// No description provided for @offerResponseDescription.
  ///
  /// In en, this message translates to:
  /// **'Minh Anh proposed another price: 2,300,000 đ.'**
  String get offerResponseDescription;

  /// No description provided for @listingApproved.
  ///
  /// In en, this message translates to:
  /// **'Listing approved'**
  String get listingApproved;

  /// No description provided for @listingApprovedDescription.
  ///
  /// In en, this message translates to:
  /// **'The vintage brass desk lamp listing is now visible.'**
  String get listingApprovedDescription;

  /// No description provided for @listingNeedsEdit.
  ///
  /// In en, this message translates to:
  /// **'Listing needs changes'**
  String get listingNeedsEdit;

  /// No description provided for @listingNeedsEditDescription.
  ///
  /// In en, this message translates to:
  /// **'Please add photos to the oak chair listing.'**
  String get listingNeedsEditDescription;

  /// No description provided for @listingSavedNotification.
  ///
  /// In en, this message translates to:
  /// **'Your listing was saved'**
  String get listingSavedNotification;

  /// No description provided for @listingSavedDescription.
  ///
  /// In en, this message translates to:
  /// **'3 people saved your Canon AE-1 listing.'**
  String get listingSavedDescription;

  /// No description provided for @sellerTitle.
  ///
  /// In en, this message translates to:
  /// **'Seller'**
  String get sellerTitle;

  /// No description provided for @sellerName.
  ///
  /// In en, this message translates to:
  /// **'Minh Anh'**
  String get sellerName;

  /// No description provided for @sellerArea.
  ///
  /// In en, this message translates to:
  /// **'District 1, Ho Chi Minh City'**
  String get sellerArea;

  /// No description provided for @sellerMemberSince.
  ///
  /// In en, this message translates to:
  /// **'Member since 2022'**
  String get sellerMemberSince;

  /// No description provided for @ratingValue.
  ///
  /// In en, this message translates to:
  /// **'★ 4.9'**
  String get ratingValue;

  /// No description provided for @ratingCount.
  ///
  /// In en, this message translates to:
  /// **'{count} ratings'**
  String ratingCount(int count);

  /// No description provided for @sellingListings.
  ///
  /// In en, this message translates to:
  /// **'Listings for sale'**
  String get sellingListings;

  /// No description provided for @chat.
  ///
  /// In en, this message translates to:
  /// **'Chat'**
  String get chat;

  /// No description provided for @viewListings.
  ///
  /// In en, this message translates to:
  /// **'View listings'**
  String get viewListings;

  /// No description provided for @listingCountShort.
  ///
  /// In en, this message translates to:
  /// **'{count} listings ›'**
  String listingCountShort(int count);

  /// No description provided for @reportSeller.
  ///
  /// In en, this message translates to:
  /// **'Report seller'**
  String get reportSeller;

  /// No description provided for @sellerRatingsTitle.
  ///
  /// In en, this message translates to:
  /// **'Seller ratings'**
  String get sellerRatingsTitle;

  /// No description provided for @communityReviews.
  ///
  /// In en, this message translates to:
  /// **'Community reviews'**
  String get communityReviews;

  /// No description provided for @reviewCount.
  ///
  /// In en, this message translates to:
  /// **'{count} reviews'**
  String reviewCount(int count);

  /// No description provided for @writeReview.
  ///
  /// In en, this message translates to:
  /// **'Write a review'**
  String get writeReview;

  /// No description provided for @leaveReviewTitle.
  ///
  /// In en, this message translates to:
  /// **'Write review'**
  String get leaveReviewTitle;

  /// No description provided for @sellerRoleArea.
  ///
  /// In en, this message translates to:
  /// **'Seller · District 1, HCMC'**
  String get sellerRoleArea;

  /// No description provided for @reviewQuestion.
  ///
  /// In en, this message translates to:
  /// **'How would you rate the seller?'**
  String get reviewQuestion;

  /// No description provided for @starSelection.
  ///
  /// In en, this message translates to:
  /// **'{count} stars · {label}'**
  String starSelection(int count, String label);

  /// No description provided for @veryGood.
  ///
  /// In en, this message translates to:
  /// **'Very good'**
  String get veryGood;

  /// No description provided for @selected.
  ///
  /// In en, this message translates to:
  /// **'Selected'**
  String get selected;

  /// No description provided for @optionalReview.
  ///
  /// In en, this message translates to:
  /// **'Review (optional)'**
  String get optionalReview;

  /// No description provided for @reviewHint.
  ///
  /// In en, this message translates to:
  /// **'Share your exchange experience...'**
  String get reviewHint;

  /// No description provided for @reviewGuidance.
  ///
  /// In en, this message translates to:
  /// **'Reviews help the community understand sellers. Please share your exchange experience.'**
  String get reviewGuidance;

  /// No description provided for @submitReview.
  ///
  /// In en, this message translates to:
  /// **'Submit review'**
  String get submitReview;

  /// No description provided for @reportListing.
  ///
  /// In en, this message translates to:
  /// **'Report listing'**
  String get reportListing;

  /// No description provided for @reportUser.
  ///
  /// In en, this message translates to:
  /// **'Report user'**
  String get reportUser;

  /// No description provided for @report.
  ///
  /// In en, this message translates to:
  /// **'Report'**
  String get report;

  /// No description provided for @reportReason.
  ///
  /// In en, this message translates to:
  /// **'Report reason'**
  String get reportReason;

  /// No description provided for @inappropriateContent.
  ///
  /// In en, this message translates to:
  /// **'Inappropriate content'**
  String get inappropriateContent;

  /// No description provided for @suspectedFraud.
  ///
  /// In en, this message translates to:
  /// **'Suspected fraud'**
  String get suspectedFraud;

  /// No description provided for @prohibitedProduct.
  ///
  /// In en, this message translates to:
  /// **'Prohibited product'**
  String get prohibitedProduct;

  /// No description provided for @misleadingInformation.
  ///
  /// In en, this message translates to:
  /// **'Misleading information'**
  String get misleadingInformation;

  /// No description provided for @spam.
  ///
  /// In en, this message translates to:
  /// **'Spam'**
  String get spam;

  /// No description provided for @otherReason.
  ///
  /// In en, this message translates to:
  /// **'Other reason'**
  String get otherReason;

  /// No description provided for @optionalDescription.
  ///
  /// In en, this message translates to:
  /// **'Additional description (optional)'**
  String get optionalDescription;

  /// No description provided for @reportDescriptionHint.
  ///
  /// In en, this message translates to:
  /// **'Add information to help us review...'**
  String get reportDescriptionHint;

  /// No description provided for @submitReport.
  ///
  /// In en, this message translates to:
  /// **'Submit report'**
  String get submitReport;

  /// No description provided for @reportSuccessTitle.
  ///
  /// In en, this message translates to:
  /// **'Report submitted'**
  String get reportSuccessTitle;

  /// No description provided for @reportSuccessDescription.
  ///
  /// In en, this message translates to:
  /// **'Thank you for helping keep ReStore safe. Our moderation team will review this content.'**
  String get reportSuccessDescription;

  /// No description provided for @goBack.
  ///
  /// In en, this message translates to:
  /// **'Go back'**
  String get goBack;

  /// No description provided for @reportedListingTitle.
  ///
  /// In en, this message translates to:
  /// **'Canon AE-1 camera + 50mm lens'**
  String get reportedListingTitle;

  /// No description provided for @reportedListingMeta.
  ///
  /// In en, this message translates to:
  /// **'Listing by Minh Anh · District 1'**
  String get reportedListingMeta;

  /// No description provided for @aiSampleCameraQuery.
  ///
  /// In en, this message translates to:
  /// **'Find a film camera under 4 million'**
  String get aiSampleCameraQuery;

  /// No description provided for @aiSampleGamingQuery.
  ///
  /// In en, this message translates to:
  /// **'Find a gaming laptop under 15 million'**
  String get aiSampleGamingQuery;

  /// No description provided for @aiSampleIphoneQuery.
  ///
  /// In en, this message translates to:
  /// **'Find an old iPhone under 10 million'**
  String get aiSampleIphoneQuery;

  /// No description provided for @aiSampleStudentLaptopQuery.
  ///
  /// In en, this message translates to:
  /// **'Find a laptop for students'**
  String get aiSampleStudentLaptopQuery;

  /// No description provided for @aiStartOver.
  ///
  /// In en, this message translates to:
  /// **'Start over'**
  String get aiStartOver;

  /// No description provided for @aiEmptyStateMenu.
  ///
  /// In en, this message translates to:
  /// **'View empty state'**
  String get aiEmptyStateMenu;

  /// No description provided for @aiErrorStateMenu.
  ///
  /// In en, this message translates to:
  /// **'View error state'**
  String get aiErrorStateMenu;

  /// No description provided for @aiInputHint.
  ///
  /// In en, this message translates to:
  /// **'Ask about products, price, area...'**
  String get aiInputHint;

  /// No description provided for @askRestoreAi.
  ///
  /// In en, this message translates to:
  /// **'Ask ReStore AI'**
  String get askRestoreAi;

  /// No description provided for @aiIntro.
  ///
  /// In en, this message translates to:
  /// **'Describe what you need. AI will find and compare suitable ReStore listings.'**
  String get aiIntro;

  /// No description provided for @quickPrompts.
  ///
  /// In en, this message translates to:
  /// **'Quick prompts'**
  String get quickPrompts;

  /// No description provided for @sellerOwnsListings.
  ///
  /// In en, this message translates to:
  /// **'Listings belong to sellers'**
  String get sellerOwnsListings;

  /// No description provided for @sellerOwnsListingsDescription.
  ///
  /// In en, this message translates to:
  /// **'Open a listing and contact the seller directly when interested.'**
  String get sellerOwnsListingsDescription;

  /// No description provided for @continueConversation.
  ///
  /// In en, this message translates to:
  /// **'You can continue asking in the same conversation'**
  String get continueConversation;

  /// No description provided for @continueConversationTips.
  ///
  /// In en, this message translates to:
  /// **'• Limit price and area\n• Choose brand or condition\n• Compare listing information'**
  String get continueConversationTips;

  /// No description provided for @aiDefaultQuery.
  ///
  /// In en, this message translates to:
  /// **'Find a film camera under 4 million in HCMC'**
  String get aiDefaultQuery;

  /// No description provided for @aiResultsMessage.
  ///
  /// In en, this message translates to:
  /// **'I found 2 matching film camera listings. Open either listing to see more.'**
  String get aiResultsMessage;

  /// No description provided for @aiFilteredMessage.
  ///
  /// In en, this message translates to:
  /// **'I updated the results using your new request.'**
  String get aiFilteredMessage;

  /// No description provided for @matchingListingsDemo.
  ///
  /// In en, this message translates to:
  /// **'MATCHING LISTINGS · DEMO DATA'**
  String get matchingListingsDemo;

  /// No description provided for @canonListingTitle.
  ///
  /// In en, this message translates to:
  /// **'Canon AE-1 + 50mm lens'**
  String get canonListingTitle;

  /// No description provided for @canonPrice.
  ///
  /// In en, this message translates to:
  /// **'2,450,000 đ'**
  String get canonPrice;

  /// No description provided for @canonLocationTime.
  ///
  /// In en, this message translates to:
  /// **'District 1 · 2 hours ago'**
  String get canonLocationTime;

  /// No description provided for @nikonListingTitle.
  ///
  /// In en, this message translates to:
  /// **'Nikon FM2 camera'**
  String get nikonListingTitle;

  /// No description provided for @nikonPrice.
  ///
  /// In en, this message translates to:
  /// **'3,800,000 đ'**
  String get nikonPrice;

  /// No description provided for @nikonLocationTime.
  ///
  /// In en, this message translates to:
  /// **'District 10 · Yesterday'**
  String get nikonLocationTime;

  /// No description provided for @sellerDataCaveat.
  ///
  /// In en, this message translates to:
  /// **'Price and condition are based on seller-provided information.'**
  String get sellerDataCaveat;

  /// No description provided for @youCanAskNext.
  ///
  /// In en, this message translates to:
  /// **'You can ask next:'**
  String get youCanAskNext;

  /// No description provided for @canonOnly.
  ///
  /// In en, this message translates to:
  /// **'Canon only'**
  String get canonOnly;

  /// No description provided for @compareTheseTwo.
  ///
  /// In en, this message translates to:
  /// **'Compare these two'**
  String get compareTheseTwo;

  /// No description provided for @comparisonMessage.
  ///
  /// In en, this message translates to:
  /// **'I compared the information in these two ReStore listings.'**
  String get comparisonMessage;

  /// No description provided for @canonVsNikon.
  ///
  /// In en, this message translates to:
  /// **'Canon AE-1 and Nikon FM2'**
  String get canonVsNikon;

  /// No description provided for @listing.
  ///
  /// In en, this message translates to:
  /// **'Listing'**
  String get listing;

  /// No description provided for @price.
  ///
  /// In en, this message translates to:
  /// **'Price'**
  String get price;

  /// No description provided for @condition.
  ///
  /// In en, this message translates to:
  /// **'Condition'**
  String get condition;

  /// No description provided for @area.
  ///
  /// In en, this message translates to:
  /// **'Area'**
  String get area;

  /// No description provided for @posted.
  ///
  /// In en, this message translates to:
  /// **'Posted'**
  String get posted;

  /// No description provided for @goodCondition.
  ///
  /// In en, this message translates to:
  /// **'Good'**
  String get goodCondition;

  /// No description provided for @notSpecified.
  ///
  /// In en, this message translates to:
  /// **'Not specified'**
  String get notSpecified;

  /// No description provided for @twoHoursAgo.
  ///
  /// In en, this message translates to:
  /// **'2 hours ago'**
  String get twoHoursAgo;

  /// No description provided for @sellerInfoOnly.
  ///
  /// In en, this message translates to:
  /// **'Based only on information provided by sellers.'**
  String get sellerInfoOnly;

  /// No description provided for @viewCanon.
  ///
  /// In en, this message translates to:
  /// **'View Canon →'**
  String get viewCanon;

  /// No description provided for @viewNikon.
  ///
  /// In en, this message translates to:
  /// **'View Nikon →'**
  String get viewNikon;

  /// No description provided for @aiEmptyTitle.
  ///
  /// In en, this message translates to:
  /// **'No matching listings'**
  String get aiEmptyTitle;

  /// No description provided for @aiEmptyDescription.
  ///
  /// In en, this message translates to:
  /// **'Try a wider area, a higher price range, or a shorter product description.'**
  String get aiEmptyDescription;

  /// No description provided for @adjustRequest.
  ///
  /// In en, this message translates to:
  /// **'Adjust request'**
  String get adjustRequest;

  /// No description provided for @aiErrorTitle.
  ///
  /// In en, this message translates to:
  /// **'Unable to answer right now'**
  String get aiErrorTitle;

  /// No description provided for @aiErrorDescription.
  ///
  /// In en, this message translates to:
  /// **'Your conversation is preserved. You can retry without entering it again.'**
  String get aiErrorDescription;

  /// No description provided for @retry.
  ///
  /// In en, this message translates to:
  /// **'Retry'**
  String get retry;

  /// No description provided for @featureApiPending.
  ///
  /// In en, this message translates to:
  /// **'{action} will be connected in the API phase.'**
  String featureApiPending(String action);

  /// No description provided for @createListing.
  ///
  /// In en, this message translates to:
  /// **'Create listing'**
  String get createListing;

  /// No description provided for @editListing.
  ///
  /// In en, this message translates to:
  /// **'Edit listing'**
  String get editListing;

  /// No description provided for @close.
  ///
  /// In en, this message translates to:
  /// **'Close'**
  String get close;

  /// No description provided for @back.
  ///
  /// In en, this message translates to:
  /// **'Back'**
  String get back;

  /// No description provided for @stepCount.
  ///
  /// In en, this message translates to:
  /// **'{current}/{total}'**
  String stepCount(int current, int total);

  /// No description provided for @productPhotosCount.
  ///
  /// In en, this message translates to:
  /// **'Product photos · {count}/10'**
  String productPhotosCount(int count);

  /// No description provided for @addPhotos.
  ///
  /// In en, this message translates to:
  /// **'Add photos'**
  String get addPhotos;

  /// No description provided for @firstPhotoHint.
  ///
  /// In en, this message translates to:
  /// **'The first photo is the cover · Hold and drag to reorder'**
  String get firstPhotoHint;

  /// No description provided for @productName.
  ///
  /// In en, this message translates to:
  /// **'Product name'**
  String get productName;

  /// No description provided for @category.
  ///
  /// In en, this message translates to:
  /// **'Category'**
  String get category;

  /// No description provided for @electronicsCamera.
  ///
  /// In en, this message translates to:
  /// **'Electronics › Camera'**
  String get electronicsCamera;

  /// No description provided for @newCondition.
  ///
  /// In en, this message translates to:
  /// **'New'**
  String get newCondition;

  /// No description provided for @usedCondition.
  ///
  /// In en, this message translates to:
  /// **'Used'**
  String get usedCondition;

  /// No description provided for @photoTip.
  ///
  /// In en, this message translates to:
  /// **'Tip: clear photos from multiple angles make your listing more trustworthy.'**
  String get photoTip;

  /// No description provided for @salePrice.
  ///
  /// In en, this message translates to:
  /// **'Sale price'**
  String get salePrice;

  /// No description provided for @priceVndHint.
  ///
  /// In en, this message translates to:
  /// **'Enter price in VND'**
  String get priceVndHint;

  /// No description provided for @negotiable.
  ///
  /// In en, this message translates to:
  /// **'Negotiable'**
  String get negotiable;

  /// No description provided for @description.
  ///
  /// In en, this message translates to:
  /// **'Description'**
  String get description;

  /// No description provided for @location.
  ///
  /// In en, this message translates to:
  /// **'Location'**
  String get location;

  /// No description provided for @contactPreference.
  ///
  /// In en, this message translates to:
  /// **'Preferred contact'**
  String get contactPreference;

  /// No description provided for @phone.
  ///
  /// In en, this message translates to:
  /// **'Phone'**
  String get phone;

  /// No description provided for @directArrangementNote.
  ///
  /// In en, this message translates to:
  /// **'Buyers and sellers arrange delivery and payment themselves.'**
  String get directArrangementNote;

  /// No description provided for @continueAction.
  ///
  /// In en, this message translates to:
  /// **'Continue'**
  String get continueAction;

  /// No description provided for @preview.
  ///
  /// In en, this message translates to:
  /// **'Preview'**
  String get preview;

  /// No description provided for @publishListing.
  ///
  /// In en, this message translates to:
  /// **'Publish listing'**
  String get publishListing;

  /// No description provided for @boostListing.
  ///
  /// In en, this message translates to:
  /// **'Boost listing'**
  String get boostListing;

  /// No description provided for @boostVisibilityTitle.
  ///
  /// In en, this message translates to:
  /// **'Increase visibility'**
  String get boostVisibilityTitle;

  /// No description provided for @boostVisibilityDescription.
  ///
  /// In en, this message translates to:
  /// **'Your listing is prioritized during the selected period. This does not guarantee a buyer.'**
  String get boostVisibilityDescription;

  /// No description provided for @selectBoostDuration.
  ///
  /// In en, this message translates to:
  /// **'Choose boost duration'**
  String get selectBoostDuration;

  /// No description provided for @boost24Hours.
  ///
  /// In en, this message translates to:
  /// **'Boost for 24 hours'**
  String get boost24Hours;

  /// No description provided for @boost3Days.
  ///
  /// In en, this message translates to:
  /// **'Boost for 3 days'**
  String get boost3Days;

  /// No description provided for @boost7Days.
  ///
  /// In en, this message translates to:
  /// **'Boost for 7 days'**
  String get boost7Days;

  /// No description provided for @visible24Hours.
  ///
  /// In en, this message translates to:
  /// **'Priority visibility for 24 hours'**
  String get visible24Hours;

  /// No description provided for @visible3Days.
  ///
  /// In en, this message translates to:
  /// **'Continuous priority visibility for 3 days'**
  String get visible3Days;

  /// No description provided for @visible7Days.
  ///
  /// In en, this message translates to:
  /// **'Continuous priority visibility for 7 days'**
  String get visible7Days;

  /// No description provided for @boostPrice24.
  ///
  /// In en, this message translates to:
  /// **'19,000 đ'**
  String get boostPrice24;

  /// No description provided for @boostPrice3Days.
  ///
  /// In en, this message translates to:
  /// **'49,000 đ'**
  String get boostPrice3Days;

  /// No description provided for @boostPrice7Days.
  ///
  /// In en, this message translates to:
  /// **'99,000 đ'**
  String get boostPrice7Days;

  /// No description provided for @boostDemoPriceNote.
  ///
  /// In en, this message translates to:
  /// **'Demo service price · official pricing will be confirmed later.'**
  String get boostDemoPriceNote;

  /// No description provided for @confirmPromotionService.
  ///
  /// In en, this message translates to:
  /// **'Confirm promotion service'**
  String get confirmPromotionService;

  /// No description provided for @currentListing.
  ///
  /// In en, this message translates to:
  /// **'Current listing'**
  String get currentListing;

  /// No description provided for @listingVisibilityStatus.
  ///
  /// In en, this message translates to:
  /// **'Visible · Current listing'**
  String get listingVisibilityStatus;

  /// No description provided for @boostPackage.
  ///
  /// In en, this message translates to:
  /// **'Boost package'**
  String get boostPackage;

  /// No description provided for @duration.
  ///
  /// In en, this message translates to:
  /// **'Duration'**
  String get duration;

  /// No description provided for @serviceFee.
  ///
  /// In en, this message translates to:
  /// **'Service fee'**
  String get serviceFee;

  /// No description provided for @totalServiceFee.
  ///
  /// In en, this message translates to:
  /// **'Total service fee'**
  String get totalServiceFee;

  /// No description provided for @threeDays.
  ///
  /// In en, this message translates to:
  /// **'3 days'**
  String get threeDays;

  /// No description provided for @seventyTwoHours.
  ///
  /// In en, this message translates to:
  /// **'72 hours'**
  String get seventyTwoHours;

  /// No description provided for @restoreServiceFee.
  ///
  /// In en, this message translates to:
  /// **'ReStore service fee'**
  String get restoreServiceFee;

  /// No description provided for @boostServiceBoundary.
  ///
  /// In en, this message translates to:
  /// **'You are paying to promote your listing, not paying for the product. ReStore does not collect buyer-seller payments.'**
  String get boostServiceBoundary;

  /// No description provided for @continuePayment.
  ///
  /// In en, this message translates to:
  /// **'Continue to payment'**
  String get continuePayment;

  /// No description provided for @servicePayment.
  ///
  /// In en, this message translates to:
  /// **'Service payment'**
  String get servicePayment;

  /// No description provided for @vnpay.
  ///
  /// In en, this message translates to:
  /// **'VNPay'**
  String get vnpay;

  /// No description provided for @vnpayDescription.
  ///
  /// In en, this message translates to:
  /// **'Pay the listing promotion fee through VNPay'**
  String get vnpayDescription;

  /// No description provided for @confirmPayment.
  ///
  /// In en, this message translates to:
  /// **'Confirm payment'**
  String get confirmPayment;

  /// No description provided for @paymentResult.
  ///
  /// In en, this message translates to:
  /// **'Payment result'**
  String get paymentResult;

  /// No description provided for @paymentSuccess.
  ///
  /// In en, this message translates to:
  /// **'Payment successful'**
  String get paymentSuccess;

  /// No description provided for @boostActivatedDescription.
  ///
  /// In en, this message translates to:
  /// **'Your listing was boosted successfully'**
  String get boostActivatedDescription;

  /// No description provided for @transactionDetails.
  ///
  /// In en, this message translates to:
  /// **'Transaction details'**
  String get transactionDetails;

  /// No description provided for @transactionCode.
  ///
  /// In en, this message translates to:
  /// **'Transaction code'**
  String get transactionCode;

  /// No description provided for @transactionCodeValue.
  ///
  /// In en, this message translates to:
  /// **'RST-BST-260925-0842'**
  String get transactionCodeValue;

  /// No description provided for @amount.
  ///
  /// In en, this message translates to:
  /// **'Amount'**
  String get amount;

  /// No description provided for @boostPeriod.
  ///
  /// In en, this message translates to:
  /// **'Boost period'**
  String get boostPeriod;

  /// No description provided for @paymentMethod.
  ///
  /// In en, this message translates to:
  /// **'Payment method'**
  String get paymentMethod;

  /// No description provided for @viewListing.
  ///
  /// In en, this message translates to:
  /// **'View listing'**
  String get viewListing;

  /// No description provided for @backToManageListings.
  ///
  /// In en, this message translates to:
  /// **'Back to manage listings'**
  String get backToManageListings;

  /// No description provided for @activeBoost.
  ///
  /// In en, this message translates to:
  /// **'Boost active'**
  String get activeBoost;

  /// No description provided for @activeBoostDescription.
  ///
  /// In en, this message translates to:
  /// **'This listing is being prioritized until the promotion ends.'**
  String get activeBoostDescription;

  /// No description provided for @expiredBoost.
  ///
  /// In en, this message translates to:
  /// **'Boost expired'**
  String get expiredBoost;

  /// No description provided for @expiredBoostDescription.
  ///
  /// In en, this message translates to:
  /// **'The promotion ended. Your listing remains publicly visible.'**
  String get expiredBoostDescription;

  /// No description provided for @boostUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Boost unavailable'**
  String get boostUnavailable;

  /// No description provided for @boostUnavailableDescription.
  ///
  /// In en, this message translates to:
  /// **'Only active, approved listings can be boosted.'**
  String get boostUnavailableDescription;

  /// No description provided for @boostAgain.
  ///
  /// In en, this message translates to:
  /// **'Boost again'**
  String get boostAgain;

  /// No description provided for @boostPaymentFailed.
  ///
  /// In en, this message translates to:
  /// **'Payment failed'**
  String get boostPaymentFailed;

  /// No description provided for @boostPaymentCancelled.
  ///
  /// In en, this message translates to:
  /// **'Payment cancelled'**
  String get boostPaymentCancelled;

  /// No description provided for @boostPaymentPending.
  ///
  /// In en, this message translates to:
  /// **'Payment verification pending'**
  String get boostPaymentPending;

  /// No description provided for @tryPaymentAgain.
  ///
  /// In en, this message translates to:
  /// **'Try payment again'**
  String get tryPaymentAgain;

  /// No description provided for @manageListings.
  ///
  /// In en, this message translates to:
  /// **'Manage listings'**
  String get manageListings;

  /// No description provided for @feedsTitle.
  ///
  /// In en, this message translates to:
  /// **'Feeds'**
  String get feedsTitle;

  /// No description provided for @feedsComingSoon.
  ///
  /// In en, this message translates to:
  /// **'Feeds are coming soon'**
  String get feedsComingSoon;

  /// No description provided for @newListing.
  ///
  /// In en, this message translates to:
  /// **'New listing'**
  String get newListing;

  /// No description provided for @visibleStatus.
  ///
  /// In en, this message translates to:
  /// **'Visible'**
  String get visibleStatus;

  /// No description provided for @pendingStatus.
  ///
  /// In en, this message translates to:
  /// **'Pending'**
  String get pendingStatus;

  /// No description provided for @hiddenStatus.
  ///
  /// In en, this message translates to:
  /// **'Hidden'**
  String get hiddenStatus;

  /// No description provided for @soldStatus.
  ///
  /// In en, this message translates to:
  /// **'Sold'**
  String get soldStatus;

  /// No description provided for @listingStatusCount.
  ///
  /// In en, this message translates to:
  /// **'{count} {status}'**
  String listingStatusCount(int count, String status);

  /// No description provided for @editAction.
  ///
  /// In en, this message translates to:
  /// **'Edit'**
  String get editAction;

  /// No description provided for @hideListing.
  ///
  /// In en, this message translates to:
  /// **'Hide'**
  String get hideListing;

  /// No description provided for @markAsSold.
  ///
  /// In en, this message translates to:
  /// **'Mark as sold'**
  String get markAsSold;

  /// No description provided for @deleteListing.
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get deleteListing;

  /// No description provided for @showAgain.
  ///
  /// In en, this message translates to:
  /// **'Show again'**
  String get showAgain;

  /// No description provided for @pendingStatusNote.
  ///
  /// In en, this message translates to:
  /// **'This listing is being reviewed before it becomes visible.'**
  String get pendingStatusNote;

  /// No description provided for @hiddenStatusNote.
  ///
  /// In en, this message translates to:
  /// **'This listing is hidden and buyers cannot find it in search results.'**
  String get hiddenStatusNote;

  /// No description provided for @soldStatusNote.
  ///
  /// In en, this message translates to:
  /// **'Sold listings no longer appear in search results.'**
  String get soldStatusNote;

  /// No description provided for @markSoldTitle.
  ///
  /// In en, this message translates to:
  /// **'Mark listing as sold?'**
  String get markSoldTitle;

  /// No description provided for @markSoldDescription.
  ///
  /// In en, this message translates to:
  /// **'The listing will no longer be available to buyers.'**
  String get markSoldDescription;

  /// No description provided for @platformNoOrderPayment.
  ///
  /// In en, this message translates to:
  /// **'This action does not create an order or transaction. ReStore does not process payment.'**
  String get platformNoOrderPayment;

  /// No description provided for @cancel.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get cancel;

  /// No description provided for @homeTitle.
  ///
  /// In en, this message translates to:
  /// **'Home'**
  String get homeTitle;

  /// No description provided for @messagesTitle.
  ///
  /// In en, this message translates to:
  /// **'Messages'**
  String get messagesTitle;

  /// No description provided for @listingDetailTitle.
  ///
  /// In en, this message translates to:
  /// **'Listing details'**
  String get listingDetailTitle;

  /// No description provided for @listingPreviewTitle.
  ///
  /// In en, this message translates to:
  /// **'Listing preview'**
  String get listingPreviewTitle;

  /// No description provided for @galleryPosition.
  ///
  /// In en, this message translates to:
  /// **'{current} / {total}'**
  String galleryPosition(int current, int total);

  /// No description provided for @listingLocationMeta.
  ///
  /// In en, this message translates to:
  /// **'⌖ District 1, Ho Chi Minh City · Posted 2 hours ago'**
  String get listingLocationMeta;

  /// No description provided for @usedGoodCondition.
  ///
  /// In en, this message translates to:
  /// **'Used · Good condition'**
  String get usedGoodCondition;

  /// No description provided for @productDescription.
  ///
  /// In en, this message translates to:
  /// **'Product description'**
  String get productDescription;

  /// No description provided for @canonDescription.
  ///
  /// In en, this message translates to:
  /// **'Canon AE-1 works well with an accurate light meter. Includes an FD 50mm f/1.8 lens, strap, and leather case. Available to inspect in District 1.'**
  String get canonDescription;

  /// No description provided for @sellerRatingMeta.
  ///
  /// In en, this message translates to:
  /// **'★ 4.9 · 48 ratings · Quick response'**
  String get sellerRatingMeta;

  /// No description provided for @similarListings.
  ///
  /// In en, this message translates to:
  /// **'Similar listings'**
  String get similarListings;

  /// No description provided for @seeMore.
  ///
  /// In en, this message translates to:
  /// **'See more ›'**
  String get seeMore;

  /// No description provided for @makeOffer.
  ///
  /// In en, this message translates to:
  /// **'Make offer'**
  String get makeOffer;

  /// No description provided for @chooseCategoryTitle.
  ///
  /// In en, this message translates to:
  /// **'Choose category'**
  String get chooseCategoryTitle;

  /// No description provided for @chooseCategorySubtitle.
  ///
  /// In en, this message translates to:
  /// **'What do you want to sell?'**
  String get chooseCategorySubtitle;

  /// No description provided for @categoryElectronicsTitle.
  ///
  /// In en, this message translates to:
  /// **'Electronics'**
  String get categoryElectronicsTitle;

  /// No description provided for @categoryElectronicsDesc.
  ///
  /// In en, this message translates to:
  /// **'Laptops, Cameras, Headphones,...'**
  String get categoryElectronicsDesc;

  /// No description provided for @categoryVehiclesTitle.
  ///
  /// In en, this message translates to:
  /// **'Vehicles'**
  String get categoryVehiclesTitle;

  /// No description provided for @categoryVehiclesDesc.
  ///
  /// In en, this message translates to:
  /// **'Motorbikes, Bicycles, Cars, Parts,...'**
  String get categoryVehiclesDesc;

  /// No description provided for @categoryFashionTitle.
  ///
  /// In en, this message translates to:
  /// **'Fashion'**
  String get categoryFashionTitle;

  /// No description provided for @categoryFashionDesc.
  ///
  /// In en, this message translates to:
  /// **'Clothes, Shoes, Bags,...'**
  String get categoryFashionDesc;

  /// No description provided for @categoryHomeTitle.
  ///
  /// In en, this message translates to:
  /// **'Household'**
  String get categoryHomeTitle;

  /// No description provided for @categoryHomeDesc.
  ///
  /// In en, this message translates to:
  /// **'Furniture, Lighting, Kitchenware, Decor,...'**
  String get categoryHomeDesc;

  /// No description provided for @step1Title.
  ///
  /// In en, this message translates to:
  /// **'Photos & Product'**
  String get step1Title;

  /// No description provided for @productPhotosInfo.
  ///
  /// In en, this message translates to:
  /// **'Product photos · {count}/10'**
  String productPhotosInfo(int count);

  /// No description provided for @coverImageHint.
  ///
  /// In en, this message translates to:
  /// **'First photo is cover · Tap a photo to set as cover'**
  String get coverImageHint;

  /// No description provided for @productNameLabel.
  ///
  /// In en, this message translates to:
  /// **'Product name'**
  String get productNameLabel;

  /// No description provided for @productNameMinLengthError.
  ///
  /// In en, this message translates to:
  /// **'Product name must be at least 5 characters'**
  String get productNameMinLengthError;

  /// No description provided for @categoryLabel.
  ///
  /// In en, this message translates to:
  /// **'Category'**
  String get categoryLabel;

  /// No description provided for @conditionLabel.
  ///
  /// In en, this message translates to:
  /// **'Condition'**
  String get conditionLabel;

  /// No description provided for @continueBtn.
  ///
  /// In en, this message translates to:
  /// **'Continue'**
  String get continueBtn;

  /// No description provided for @completeListingTitle.
  ///
  /// In en, this message translates to:
  /// **'Complete listing'**
  String get completeListingTitle;

  /// No description provided for @saveDraft.
  ///
  /// In en, this message translates to:
  /// **'Save draft'**
  String get saveDraft;

  /// No description provided for @draftSaved.
  ///
  /// In en, this message translates to:
  /// **'Draft saved'**
  String get draftSaved;

  /// No description provided for @listingPhotosLabel.
  ///
  /// In en, this message translates to:
  /// **'Photos (up to {max} photos)'**
  String listingPhotosLabel(int max);

  /// No description provided for @photoCount.
  ///
  /// In en, this message translates to:
  /// **'{count}/{max}'**
  String photoCount(int count, int max);

  /// No description provided for @coverPhotoBadge.
  ///
  /// In en, this message translates to:
  /// **'Cover'**
  String get coverPhotoBadge;

  /// No description provided for @photosRequiredError.
  ///
  /// In en, this message translates to:
  /// **'Please add at least 1 photo'**
  String get photosRequiredError;

  /// No description provided for @detailedDescriptionLabel.
  ///
  /// In en, this message translates to:
  /// **'Detailed description'**
  String get detailedDescriptionLabel;

  /// No description provided for @listingDescriptionHint.
  ///
  /// In en, this message translates to:
  /// **'- Condition, how long it has been used\n- Included accessories, minor defects if any\n- Reason for selling, delivery method'**
  String get listingDescriptionHint;

  /// No description provided for @characterCount.
  ///
  /// In en, this message translates to:
  /// **'{count}/{max} characters'**
  String characterCount(int count, int max);

  /// No description provided for @descriptionMinLengthError.
  ///
  /// In en, this message translates to:
  /// **'Description must be at least {min} characters'**
  String descriptionMinLengthError(int min);

  /// No description provided for @listingTitleLabel.
  ///
  /// In en, this message translates to:
  /// **'Listing title'**
  String get listingTitleLabel;

  /// No description provided for @listingTitleHint.
  ///
  /// In en, this message translates to:
  /// **'e.g. Piaggio Vespa Sprint 2024 15,000 km'**
  String get listingTitleHint;

  /// No description provided for @listingTitleMinLengthError.
  ///
  /// In en, this message translates to:
  /// **'Title must be at least {min} characters'**
  String listingTitleMinLengthError(int min);

  /// No description provided for @priceRequiredError.
  ///
  /// In en, this message translates to:
  /// **'Please enter a sale price'**
  String get priceRequiredError;

  /// No description provided for @addressLabel.
  ///
  /// In en, this message translates to:
  /// **'Address'**
  String get addressLabel;

  /// No description provided for @youAreLabel.
  ///
  /// In en, this message translates to:
  /// **'You are'**
  String get youAreLabel;

  /// No description provided for @sellerPersonal.
  ///
  /// In en, this message translates to:
  /// **'Personal'**
  String get sellerPersonal;

  /// No description provided for @sellerBusiness.
  ///
  /// In en, this message translates to:
  /// **'Business'**
  String get sellerBusiness;

  /// No description provided for @detailedInfoTitle.
  ///
  /// In en, this message translates to:
  /// **'Detailed information'**
  String get detailedInfoTitle;

  /// No description provided for @categoryWithName.
  ///
  /// In en, this message translates to:
  /// **'Category: {name}'**
  String categoryWithName(String name);

  /// No description provided for @fieldRequiredError.
  ///
  /// In en, this message translates to:
  /// **'Please fill in this field'**
  String get fieldRequiredError;

  /// No description provided for @fieldSelectRequiredError.
  ///
  /// In en, this message translates to:
  /// **'Please select an option'**
  String get fieldSelectRequiredError;

  /// No description provided for @missingRequiredFields.
  ///
  /// In en, this message translates to:
  /// **'Please complete all required fields'**
  String get missingRequiredFields;

  /// No description provided for @listingSubmitted.
  ///
  /// In en, this message translates to:
  /// **'Your listing has been submitted and is waiting for review'**
  String get listingSubmitted;

  /// No description provided for @previewNotice.
  ///
  /// In en, this message translates to:
  /// **'This is how buyers will see your listing'**
  String get previewNotice;

  /// No description provided for @noPhotosYet.
  ///
  /// In en, this message translates to:
  /// **'No photos yet'**
  String get noPhotosYet;

  /// No description provided for @stepBasicInfoTitle.
  ///
  /// In en, this message translates to:
  /// **'Photos, description & price'**
  String get stepBasicInfoTitle;

  /// No description provided for @takePhoto.
  ///
  /// In en, this message translates to:
  /// **'Take a photo'**
  String get takePhoto;

  /// No description provided for @chooseFromGallery.
  ///
  /// In en, this message translates to:
  /// **'Choose from gallery'**
  String get chooseFromGallery;

  /// No description provided for @photoLimitReached.
  ///
  /// In en, this message translates to:
  /// **'You can add up to {max} photos'**
  String photoLimitReached(int max);

  /// No description provided for @photoPickFailed.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t open your photos. Please check the app\'s photo and camera permissions.'**
  String get photoPickFailed;

  /// No description provided for @draftSaveFailed.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t save the draft, please try again'**
  String get draftSaveFailed;

  /// No description provided for @publishFailed.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t publish the listing, please try again'**
  String get publishFailed;

  /// No description provided for @tradeTypeLabel.
  ///
  /// In en, this message translates to:
  /// **'Trade type'**
  String get tradeTypeLabel;

  /// No description provided for @tradeSell.
  ///
  /// In en, this message translates to:
  /// **'Sell'**
  String get tradeSell;

  /// No description provided for @tradeExchange.
  ///
  /// In en, this message translates to:
  /// **'Exchange'**
  String get tradeExchange;

  /// No description provided for @tradeSellOrExchange.
  ///
  /// In en, this message translates to:
  /// **'Both'**
  String get tradeSellOrExchange;

  /// No description provided for @tradeExchangeAccepted.
  ///
  /// In en, this message translates to:
  /// **'Open to exchange'**
  String get tradeExchangeAccepted;

  /// No description provided for @exchangeWishLabel.
  ///
  /// In en, this message translates to:
  /// **'Want to exchange for'**
  String get exchangeWishLabel;

  /// No description provided for @exchangeWishHint.
  ///
  /// In en, this message translates to:
  /// **'e.g. iPhone 13 or a tablet'**
  String get exchangeWishHint;

  /// No description provided for @selectAddressHint.
  ///
  /// In en, this message translates to:
  /// **'Choose an area'**
  String get selectAddressHint;

  /// No description provided for @stepShortCategory.
  ///
  /// In en, this message translates to:
  /// **'Category'**
  String get stepShortCategory;

  /// No description provided for @stepShortBasicInfo.
  ///
  /// In en, this message translates to:
  /// **'Basics'**
  String get stepShortBasicInfo;

  /// No description provided for @stepShortDetails.
  ///
  /// In en, this message translates to:
  /// **'Details'**
  String get stepShortDetails;

  /// No description provided for @stepProgressLabel.
  ///
  /// In en, this message translates to:
  /// **'Step {current}/{total}'**
  String stepProgressLabel(int current, int total);

  /// No description provided for @nextStepLabel.
  ///
  /// In en, this message translates to:
  /// **'Next: {name}'**
  String nextStepLabel(String name);

  /// No description provided for @conditionSectionTitle.
  ///
  /// In en, this message translates to:
  /// **'Item condition'**
  String get conditionSectionTitle;

  /// No description provided for @conditionNew.
  ///
  /// In en, this message translates to:
  /// **'New'**
  String get conditionNew;

  /// No description provided for @conditionLikeNew.
  ///
  /// In en, this message translates to:
  /// **'Like new'**
  String get conditionLikeNew;

  /// No description provided for @conditionUsedGood.
  ///
  /// In en, this message translates to:
  /// **'Used - good'**
  String get conditionUsedGood;

  /// No description provided for @conditionUsedFair.
  ///
  /// In en, this message translates to:
  /// **'Used - fair'**
  String get conditionUsedFair;

  /// No description provided for @conditionForParts.
  ///
  /// In en, this message translates to:
  /// **'For parts / not working'**
  String get conditionForParts;

  /// No description provided for @conditionNewDesc.
  ///
  /// In en, this message translates to:
  /// **'Never used, original packaging'**
  String get conditionNewDesc;

  /// No description provided for @conditionLikeNewDesc.
  ///
  /// In en, this message translates to:
  /// **'Barely used, no visible marks'**
  String get conditionLikeNewDesc;

  /// No description provided for @conditionUsedGoodDesc.
  ///
  /// In en, this message translates to:
  /// **'Works well, minor signs of use'**
  String get conditionUsedGoodDesc;

  /// No description provided for @conditionUsedFairDesc.
  ///
  /// In en, this message translates to:
  /// **'Usable, visible wear or minor faults'**
  String get conditionUsedFairDesc;

  /// No description provided for @conditionForPartsDesc.
  ///
  /// In en, this message translates to:
  /// **'Does not work properly'**
  String get conditionForPartsDesc;

  /// No description provided for @categoryAttributesTitle.
  ///
  /// In en, this message translates to:
  /// **'Category details'**
  String get categoryAttributesTitle;

  /// No description provided for @categoryAttributesHint.
  ///
  /// In en, this message translates to:
  /// **'Fields below depend on the category'**
  String get categoryAttributesHint;

  /// No description provided for @selectOptionHint.
  ///
  /// In en, this message translates to:
  /// **'Select'**
  String get selectOptionHint;

  /// No description provided for @numberRangeError.
  ///
  /// In en, this message translates to:
  /// **'Value must be between {min} and {max}'**
  String numberRangeError(String min, String max);

  /// No description provided for @yes.
  ///
  /// In en, this message translates to:
  /// **'Yes'**
  String get yes;

  /// No description provided for @no.
  ///
  /// In en, this message translates to:
  /// **'No'**
  String get no;

  /// No description provided for @loadCategoriesFailedTitle.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t load categories'**
  String get loadCategoriesFailedTitle;

  /// No description provided for @loadCategoriesFailedMessage.
  ///
  /// In en, this message translates to:
  /// **'Check your connection and try again'**
  String get loadCategoriesFailedMessage;

  /// No description provided for @negotiableHint.
  ///
  /// In en, this message translates to:
  /// **'Buyers can make offers in chat'**
  String get negotiableHint;

  /// No description provided for @addressNearbyHint.
  ///
  /// In en, this message translates to:
  /// **'Helps nearby buyers find your listing'**
  String get addressNearbyHint;

  /// No description provided for @privateStreetAddress.
  ///
  /// In en, this message translates to:
  /// **'{street} (private)'**
  String privateStreetAddress(String street);

  /// No description provided for @addressSheetTitle.
  ///
  /// In en, this message translates to:
  /// **'Item location'**
  String get addressSheetTitle;

  /// No description provided for @useCurrentLocation.
  ///
  /// In en, this message translates to:
  /// **'Use my current location'**
  String get useCurrentLocation;

  /// No description provided for @useCurrentLocationHint.
  ///
  /// In en, this message translates to:
  /// **'Fill in province and ward automatically'**
  String get useCurrentLocationHint;

  /// No description provided for @locatingLabel.
  ///
  /// In en, this message translates to:
  /// **'Getting your location...'**
  String get locatingLabel;

  /// No description provided for @locationDetected.
  ///
  /// In en, this message translates to:
  /// **'Location detected'**
  String get locationDetected;

  /// No description provided for @orChooseManually.
  ///
  /// In en, this message translates to:
  /// **'or choose manually'**
  String get orChooseManually;

  /// No description provided for @provinceLabel.
  ///
  /// In en, this message translates to:
  /// **'Province/City'**
  String get provinceLabel;

  /// No description provided for @selectProvinceHint.
  ///
  /// In en, this message translates to:
  /// **'Select province/city'**
  String get selectProvinceHint;

  /// No description provided for @wardLabel.
  ///
  /// In en, this message translates to:
  /// **'Ward/Commune'**
  String get wardLabel;

  /// No description provided for @selectWardHint.
  ///
  /// In en, this message translates to:
  /// **'Select ward/commune'**
  String get selectWardHint;

  /// No description provided for @selectProvinceFirst.
  ///
  /// In en, this message translates to:
  /// **'Select a province first'**
  String get selectProvinceFirst;

  /// No description provided for @streetAddressLabel.
  ///
  /// In en, this message translates to:
  /// **'House number, street'**
  String get streetAddressLabel;

  /// No description provided for @streetAddressHint.
  ///
  /// In en, this message translates to:
  /// **'e.g. 12 Nguyen Hue'**
  String get streetAddressHint;

  /// No description provided for @streetAddressHelper.
  ///
  /// In en, this message translates to:
  /// **'Optional, never shown publicly'**
  String get streetAddressHelper;

  /// No description provided for @streetSuggestionsTitle.
  ///
  /// In en, this message translates to:
  /// **'Suggested addresses'**
  String get streetSuggestionsTitle;

  /// No description provided for @addressPrivacyNote.
  ///
  /// In en, this message translates to:
  /// **'Buyers only see the ward and province. Your location is used to show listings near you.'**
  String get addressPrivacyNote;

  /// No description provided for @confirmAddress.
  ///
  /// In en, this message translates to:
  /// **'Confirm address'**
  String get confirmAddress;

  /// No description provided for @loadingLocations.
  ///
  /// In en, this message translates to:
  /// **'Loading...'**
  String get loadingLocations;

  /// No description provided for @loadLocationsFailed.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t load the list, tap to retry'**
  String get loadLocationsFailed;

  /// No description provided for @locationServiceDisabled.
  ///
  /// In en, this message translates to:
  /// **'Turn on location services to continue'**
  String get locationServiceDisabled;

  /// No description provided for @locationPermissionDenied.
  ///
  /// In en, this message translates to:
  /// **'Location permission was denied'**
  String get locationPermissionDenied;

  /// No description provided for @locationPermissionDeniedForever.
  ///
  /// In en, this message translates to:
  /// **'Location access is blocked, enable it in Settings'**
  String get locationPermissionDeniedForever;

  /// No description provided for @locationUnavailable.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t get your location, please choose manually'**
  String get locationUnavailable;

  /// No description provided for @locationOutOfCoverage.
  ///
  /// In en, this message translates to:
  /// **'Your location didn’t match any ward. Please choose it manually below.'**
  String get locationOutOfCoverage;

  /// No description provided for @searchOptionHint.
  ///
  /// In en, this message translates to:
  /// **'Search'**
  String get searchOptionHint;

  /// No description provided for @noMatchingOptions.
  ///
  /// In en, this message translates to:
  /// **'No matching results'**
  String get noMatchingOptions;

  /// No description provided for @locationOutsideVietnamTitle.
  ///
  /// In en, this message translates to:
  /// **'Looks like you’re outside Vietnam'**
  String get locationOutsideVietnamTitle;

  /// No description provided for @locationOutsideVietnamBody.
  ///
  /// In en, this message translates to:
  /// **'ReStore only supports addresses in Vietnam for now. Please pick your province and ward below.'**
  String get locationOutsideVietnamBody;

  /// No description provided for @locationOutOfCoverageTitle.
  ///
  /// In en, this message translates to:
  /// **'We don’t recognise this area yet'**
  String get locationOutOfCoverageTitle;

  /// No description provided for @aiBubbleTooltip.
  ///
  /// In en, this message translates to:
  /// **'Chat with ReStore AI'**
  String get aiBubbleTooltip;

  /// No description provided for @unreadMessagesCount.
  ///
  /// In en, this message translates to:
  /// **'{count} unread messages'**
  String unreadMessagesCount(int count);

  /// No description provided for @homeGreeting.
  ///
  /// In en, this message translates to:
  /// **'Hi there 👋'**
  String get homeGreeting;

  /// No description provided for @homeHeadline.
  ///
  /// In en, this message translates to:
  /// **'What are you hunting for today?'**
  String get homeHeadline;

  /// No description provided for @homeSearchHint.
  ///
  /// In en, this message translates to:
  /// **'Search pre-loved and swap items...'**
  String get homeSearchHint;

  /// No description provided for @homeChangeArea.
  ///
  /// In en, this message translates to:
  /// **'Change area'**
  String get homeChangeArea;

  /// No description provided for @homeAreaLocating.
  ///
  /// In en, this message translates to:
  /// **'Locating...'**
  String get homeAreaLocating;

  /// No description provided for @homeForYouTitle.
  ///
  /// In en, this message translates to:
  /// **'Picked for you'**
  String get homeForYouTitle;

  /// No description provided for @homeLatestTitle.
  ///
  /// In en, this message translates to:
  /// **'Fresh listings'**
  String get homeLatestTitle;

  /// No description provided for @homeSeeAll.
  ///
  /// In en, this message translates to:
  /// **'See all'**
  String get homeSeeAll;

  /// No description provided for @homeFeaturedTag.
  ///
  /// In en, this message translates to:
  /// **'Featured'**
  String get homeFeaturedTag;

  /// No description provided for @homeExchangeTag.
  ///
  /// In en, this message translates to:
  /// **'Swappable'**
  String get homeExchangeTag;

  /// No description provided for @homeExchangeOnly.
  ///
  /// In en, this message translates to:
  /// **'Swap only'**
  String get homeExchangeOnly;

  /// No description provided for @homeSaveListing.
  ///
  /// In en, this message translates to:
  /// **'Save listing'**
  String get homeSaveListing;

  /// No description provided for @homeUnsaveListing.
  ///
  /// In en, this message translates to:
  /// **'Remove from saved'**
  String get homeUnsaveListing;

  /// No description provided for @homeLoadErrorTitle.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t load the home page'**
  String get homeLoadErrorTitle;

  /// No description provided for @homeLoadErrorBody.
  ///
  /// In en, this message translates to:
  /// **'Check your connection and try again.'**
  String get homeLoadErrorBody;

  /// No description provided for @timeJustNow.
  ///
  /// In en, this message translates to:
  /// **'Just now'**
  String get timeJustNow;

  /// No description provided for @timeMinutesAgo.
  ///
  /// In en, this message translates to:
  /// **'{count} min ago'**
  String timeMinutesAgo(int count);

  /// No description provided for @timeHoursAgo.
  ///
  /// In en, this message translates to:
  /// **'{count} h ago'**
  String timeHoursAgo(int count);

  /// No description provided for @timeDaysAgo.
  ///
  /// In en, this message translates to:
  /// **'{count} d ago'**
  String timeDaysAgo(int count);

  /// No description provided for @featureComingSoon.
  ///
  /// In en, this message translates to:
  /// **'This feature is coming soon'**
  String get featureComingSoon;

  /// No description provided for @homeGreetingName.
  ///
  /// In en, this message translates to:
  /// **'Hi there, {name} 👋'**
  String homeGreetingName(String name);

  /// No description provided for @homeLatestEmpty.
  ///
  /// In en, this message translates to:
  /// **'No listings here yet'**
  String get homeLatestEmpty;

  /// No description provided for @homeEndOfList.
  ///
  /// In en, this message translates to:
  /// **'You\'re all caught up'**
  String get homeEndOfList;

  /// No description provided for @homeQuickNearby.
  ///
  /// In en, this message translates to:
  /// **'Near me'**
  String get homeQuickNearby;

  /// No description provided for @homeQuickNearbyDesc.
  ///
  /// In en, this message translates to:
  /// **'Within 5 km'**
  String get homeQuickNearbyDesc;

  /// No description provided for @homeQuickWanted.
  ///
  /// In en, this message translates to:
  /// **'Wanted alerts'**
  String get homeQuickWanted;

  /// No description provided for @homeQuickWantedDesc.
  ///
  /// In en, this message translates to:
  /// **'Get notified when listed'**
  String get homeQuickWantedDesc;

  /// No description provided for @homeQuickTrustedShops.
  ///
  /// In en, this message translates to:
  /// **'Trusted shops'**
  String get homeQuickTrustedShops;

  /// No description provided for @homeQuickTrustedShopsDesc.
  ///
  /// In en, this message translates to:
  /// **'Verified and top rated'**
  String get homeQuickTrustedShopsDesc;

  /// No description provided for @homeQuickFollowing.
  ///
  /// In en, this message translates to:
  /// **'Following'**
  String get homeQuickFollowing;

  /// No description provided for @homeQuickFollowingDesc.
  ///
  /// In en, this message translates to:
  /// **'Shops and people you follow'**
  String get homeQuickFollowingDesc;

  /// No description provided for @homeBannerTooltip.
  ///
  /// In en, this message translates to:
  /// **'Promotion banner'**
  String get homeBannerTooltip;

  /// No description provided for @productDetailTitle.
  ///
  /// In en, this message translates to:
  /// **'Product details'**
  String get productDetailTitle;

  /// No description provided for @productLoadErrorTitle.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t load this listing'**
  String get productLoadErrorTitle;

  /// No description provided for @productLoadErrorBody.
  ///
  /// In en, this message translates to:
  /// **'The listing may have been removed, or your connection is unstable. Please try again.'**
  String get productLoadErrorBody;

  /// No description provided for @productViewCount.
  ///
  /// In en, this message translates to:
  /// **'{count} views'**
  String productViewCount(int count);

  /// No description provided for @productUnavailableHint.
  ///
  /// In en, this message translates to:
  /// **'This item can no longer be bought.'**
  String get productUnavailableHint;

  /// No description provided for @listingStatusDraft.
  ///
  /// In en, this message translates to:
  /// **'Draft'**
  String get listingStatusDraft;

  /// No description provided for @listingStatusPending.
  ///
  /// In en, this message translates to:
  /// **'Pending review'**
  String get listingStatusPending;

  /// No description provided for @listingStatusAvailable.
  ///
  /// In en, this message translates to:
  /// **'Available'**
  String get listingStatusAvailable;

  /// No description provided for @listingStatusReserved.
  ///
  /// In en, this message translates to:
  /// **'Reserved'**
  String get listingStatusReserved;

  /// No description provided for @listingStatusSold.
  ///
  /// In en, this message translates to:
  /// **'Sold'**
  String get listingStatusSold;

  /// No description provided for @listingStatusExchanged.
  ///
  /// In en, this message translates to:
  /// **'Exchanged'**
  String get listingStatusExchanged;

  /// No description provided for @listingStatusExpired.
  ///
  /// In en, this message translates to:
  /// **'Expired'**
  String get listingStatusExpired;

  /// No description provided for @listingStatusRejected.
  ///
  /// In en, this message translates to:
  /// **'Rejected'**
  String get listingStatusRejected;

  /// No description provided for @listingStatusHidden.
  ///
  /// In en, this message translates to:
  /// **'Hidden'**
  String get listingStatusHidden;

  /// No description provided for @productSellerTitle.
  ///
  /// In en, this message translates to:
  /// **'Seller'**
  String get productSellerTitle;

  /// No description provided for @productSellerVerified.
  ///
  /// In en, this message translates to:
  /// **'Verified'**
  String get productSellerVerified;

  /// No description provided for @productSellerNoReviews.
  ///
  /// In en, this message translates to:
  /// **'No reviews yet'**
  String get productSellerNoReviews;

  /// No description provided for @productSellerJoined.
  ///
  /// In en, this message translates to:
  /// **'Joined {date}'**
  String productSellerJoined(String date);

  /// No description provided for @productSellerListings.
  ///
  /// In en, this message translates to:
  /// **'{count} listings'**
  String productSellerListings(int count);

  /// No description provided for @productSellerProfile.
  ///
  /// In en, this message translates to:
  /// **'View profile'**
  String get productSellerProfile;

  /// No description provided for @productReadMore.
  ///
  /// In en, this message translates to:
  /// **'Show more'**
  String get productReadMore;

  /// No description provided for @productReadLess.
  ///
  /// In en, this message translates to:
  /// **'Show less'**
  String get productReadLess;

  /// No description provided for @productSafetyTitle.
  ///
  /// In en, this message translates to:
  /// **'Shop safely'**
  String get productSafetyTitle;

  /// No description provided for @productSafetyBody.
  ///
  /// In en, this message translates to:
  /// **'Meet in a public place, check the item before paying and never send a deposit to someone you don\'t know.'**
  String get productSafetyBody;

  /// No description provided for @productReport.
  ///
  /// In en, this message translates to:
  /// **'Report listing'**
  String get productReport;

  /// No description provided for @productChat.
  ///
  /// In en, this message translates to:
  /// **'Chat'**
  String get productChat;

  /// No description provided for @productMakeOffer.
  ///
  /// In en, this message translates to:
  /// **'Make offer'**
  String get productMakeOffer;

  /// No description provided for @productBuyNow.
  ///
  /// In en, this message translates to:
  /// **'Buy now'**
  String get productBuyNow;

  /// No description provided for @productProposeExchange.
  ///
  /// In en, this message translates to:
  /// **'Propose a swap'**
  String get productProposeExchange;

  /// No description provided for @productEditListing.
  ///
  /// In en, this message translates to:
  /// **'Edit listing'**
  String get productEditListing;

  /// No description provided for @productBoost.
  ///
  /// In en, this message translates to:
  /// **'Boost'**
  String get productBoost;

  /// No description provided for @productOfferTitle.
  ///
  /// In en, this message translates to:
  /// **'Make an offer'**
  String get productOfferTitle;

  /// No description provided for @productOfferSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Listed at {price}'**
  String productOfferSubtitle(String price);

  /// No description provided for @productOfferAmountLabel.
  ///
  /// In en, this message translates to:
  /// **'Your offer'**
  String get productOfferAmountLabel;

  /// No description provided for @productOfferAmountHint.
  ///
  /// In en, this message translates to:
  /// **'Enter an amount'**
  String get productOfferAmountHint;

  /// No description provided for @productOfferInvalid.
  ///
  /// In en, this message translates to:
  /// **'Enter an amount greater than 0'**
  String get productOfferInvalid;

  /// No description provided for @productOfferTooHigh.
  ///
  /// In en, this message translates to:
  /// **'Your offer can be at most twice the asking price'**
  String get productOfferTooHigh;

  /// No description provided for @productOfferSubmit.
  ///
  /// In en, this message translates to:
  /// **'Send offer'**
  String get productOfferSubmit;

  /// No description provided for @productOfferSent.
  ///
  /// In en, this message translates to:
  /// **'Offer sent. Continue the conversation with the seller here.'**
  String get productOfferSent;

  /// No description provided for @productOfferBelow.
  ///
  /// In en, this message translates to:
  /// **'{percent} below the asking price (-{difference})'**
  String productOfferBelow(String percent, String difference);

  /// No description provided for @productOfferAbove.
  ///
  /// In en, this message translates to:
  /// **'{percent} above the asking price (+{difference})'**
  String productOfferAbove(String percent, String difference);

  /// No description provided for @productOfferEqual.
  ///
  /// In en, this message translates to:
  /// **'Same as the asking price'**
  String get productOfferEqual;

  /// No description provided for @productLiveTitle.
  ///
  /// In en, this message translates to:
  /// **'Listing just updated'**
  String get productLiveTitle;

  /// No description provided for @productLiveUnavailable.
  ///
  /// In en, this message translates to:
  /// **'This item is now {status} and can no longer be ordered.'**
  String productLiveUnavailable(String status);

  /// No description provided for @productLiveAvailable.
  ///
  /// In en, this message translates to:
  /// **'This item is available again.'**
  String get productLiveAvailable;

  /// No description provided for @productLivePrice.
  ///
  /// In en, this message translates to:
  /// **'The seller changed the price from {previous} to {current}.'**
  String productLivePrice(String previous, String current);

  /// No description provided for @productLivePriceGeneric.
  ///
  /// In en, this message translates to:
  /// **'The seller updated the price, please review before sending.'**
  String get productLivePriceGeneric;

  /// No description provided for @productLiveInfo.
  ///
  /// In en, this message translates to:
  /// **'The seller just edited this listing.'**
  String get productLiveInfo;

  /// No description provided for @productLiveIndicator.
  ///
  /// In en, this message translates to:
  /// **'Live updates on'**
  String get productLiveIndicator;

  /// No description provided for @productBuyTitle.
  ///
  /// In en, this message translates to:
  /// **'Request to buy'**
  String get productBuyTitle;

  /// No description provided for @productBuySubtitle.
  ///
  /// In en, this message translates to:
  /// **'The seller confirms and arranges the handover with you in chat.'**
  String get productBuySubtitle;

  /// No description provided for @productBuyPriceLabel.
  ///
  /// In en, this message translates to:
  /// **'Price'**
  String get productBuyPriceLabel;

  /// No description provided for @productBuyNoteLabel.
  ///
  /// In en, this message translates to:
  /// **'Note for the seller'**
  String get productBuyNoteLabel;

  /// No description provided for @productBuyNoteHint.
  ///
  /// In en, this message translates to:
  /// **'e.g. I can pick it up this evening'**
  String get productBuyNoteHint;

  /// No description provided for @productBuySubmit.
  ///
  /// In en, this message translates to:
  /// **'Send request'**
  String get productBuySubmit;

  /// No description provided for @productBuySent.
  ///
  /// In en, this message translates to:
  /// **'Purchase request sent. The seller will reply in chat.'**
  String get productBuySent;

  /// No description provided for @productActionFailed.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t send. Please try again.'**
  String get productActionFailed;

  /// No description provided for @galleryOpenFullscreen.
  ///
  /// In en, this message translates to:
  /// **'View photos full screen'**
  String get galleryOpenFullscreen;

  /// No description provided for @nearbyTitle.
  ///
  /// In en, this message translates to:
  /// **'Near me'**
  String get nearbyTitle;

  /// No description provided for @nearbySubtitle.
  ///
  /// In en, this message translates to:
  /// **'Pre-loved finds around you, meet up and grab them'**
  String get nearbySubtitle;

  /// No description provided for @nearbyCurrentLocation.
  ///
  /// In en, this message translates to:
  /// **'Current location'**
  String get nearbyCurrentLocation;

  /// No description provided for @nearbyLocating.
  ///
  /// In en, this message translates to:
  /// **'Finding your location...'**
  String get nearbyLocating;

  /// No description provided for @nearbyChangeLocation.
  ///
  /// In en, this message translates to:
  /// **'Change'**
  String get nearbyChangeLocation;

  /// No description provided for @nearbyRelocate.
  ///
  /// In en, this message translates to:
  /// **'Update location'**
  String get nearbyRelocate;

  /// No description provided for @nearbyFilters.
  ///
  /// In en, this message translates to:
  /// **'Filters'**
  String get nearbyFilters;

  /// No description provided for @nearbyRadiusChip.
  ///
  /// In en, this message translates to:
  /// **'Within {distance}'**
  String nearbyRadiusChip(String distance);

  /// No description provided for @nearbyRadiusTitle.
  ///
  /// In en, this message translates to:
  /// **'Search radius'**
  String get nearbyRadiusTitle;

  /// No description provided for @nearbyRadiusOption.
  ///
  /// In en, this message translates to:
  /// **'Within {distance}'**
  String nearbyRadiusOption(String distance);

  /// No description provided for @listingDealBuy.
  ///
  /// In en, this message translates to:
  /// **'Buy now'**
  String get listingDealBuy;

  /// No description provided for @listingDealExchange.
  ///
  /// In en, this message translates to:
  /// **'Swap'**
  String get listingDealExchange;

  /// No description provided for @listingSortTitle.
  ///
  /// In en, this message translates to:
  /// **'Sort by'**
  String get listingSortTitle;

  /// No description provided for @listingSortNearest.
  ///
  /// In en, this message translates to:
  /// **'Nearest'**
  String get listingSortNearest;

  /// No description provided for @listingSortNewest.
  ///
  /// In en, this message translates to:
  /// **'Newest'**
  String get listingSortNewest;

  /// No description provided for @listingSortPriceLow.
  ///
  /// In en, this message translates to:
  /// **'Price: low to high'**
  String get listingSortPriceLow;

  /// No description provided for @listingSortPriceHigh.
  ///
  /// In en, this message translates to:
  /// **'Price: high to low'**
  String get listingSortPriceHigh;

  /// No description provided for @nearbyFallbackTitle.
  ///
  /// In en, this message translates to:
  /// **'Showing listings around your default area'**
  String get nearbyFallbackTitle;

  /// No description provided for @nearbyUseMyLocation.
  ///
  /// In en, this message translates to:
  /// **'Use my location'**
  String get nearbyUseMyLocation;

  /// No description provided for @nearbyOpenSettings.
  ///
  /// In en, this message translates to:
  /// **'Open Settings'**
  String get nearbyOpenSettings;

  /// No description provided for @nearbyEmptyTitle.
  ///
  /// In en, this message translates to:
  /// **'Nothing nearby yet'**
  String get nearbyEmptyTitle;

  /// No description provided for @nearbyEmptyBody.
  ///
  /// In en, this message translates to:
  /// **'Try a wider radius or fewer filters.'**
  String get nearbyEmptyBody;

  /// No description provided for @nearbyExpandRadius.
  ///
  /// In en, this message translates to:
  /// **'Expand to {distance}'**
  String nearbyExpandRadius(String distance);

  /// No description provided for @nearbyLoadErrorTitle.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t load nearby listings'**
  String get nearbyLoadErrorTitle;

  /// No description provided for @nearbyLoadErrorBody.
  ///
  /// In en, this message translates to:
  /// **'Check your connection and try again.'**
  String get nearbyLoadErrorBody;

  /// No description provided for @nearbyEndOfList.
  ///
  /// In en, this message translates to:
  /// **'You\'ve seen everything nearby'**
  String get nearbyEndOfList;

  /// No description provided for @distanceMeters.
  ///
  /// In en, this message translates to:
  /// **'{meters} m'**
  String distanceMeters(int meters);

  /// No description provided for @distanceKm.
  ///
  /// In en, this message translates to:
  /// **'{km} km'**
  String distanceKm(String km);

  /// No description provided for @listingSortRelevance.
  ///
  /// In en, this message translates to:
  /// **'Most relevant'**
  String get listingSortRelevance;

  /// No description provided for @searchNearMe.
  ///
  /// In en, this message translates to:
  /// **'Near me'**
  String get searchNearMe;

  /// No description provided for @searchNearMeSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Browse pre-loved items around you'**
  String get searchNearMeSubtitle;

  /// No description provided for @searchTipsTitle.
  ///
  /// In en, this message translates to:
  /// **'Quick search ideas'**
  String get searchTipsTitle;

  /// No description provided for @searchHistoryTitle.
  ///
  /// In en, this message translates to:
  /// **'Recent searches'**
  String get searchHistoryTitle;

  /// No description provided for @searchClearHistory.
  ///
  /// In en, this message translates to:
  /// **'Clear all'**
  String get searchClearHistory;

  /// No description provided for @searchRemoveHistory.
  ///
  /// In en, this message translates to:
  /// **'Remove from list'**
  String get searchRemoveHistory;

  /// No description provided for @searchFillQuery.
  ///
  /// In en, this message translates to:
  /// **'Use in search box'**
  String get searchFillQuery;

  /// No description provided for @searchClearInput.
  ///
  /// In en, this message translates to:
  /// **'Clear'**
  String get searchClearInput;

  /// No description provided for @searchForQuery.
  ///
  /// In en, this message translates to:
  /// **'Search “{query}”'**
  String searchForQuery(String query);

  /// No description provided for @searchEmptyTitle.
  ///
  /// In en, this message translates to:
  /// **'No results for “{query}”'**
  String searchEmptyTitle(String query);

  /// No description provided for @searchEmptyBody.
  ///
  /// In en, this message translates to:
  /// **'Try a shorter or different keyword, or remove some filters.'**
  String get searchEmptyBody;

  /// No description provided for @searchTryAnother.
  ///
  /// In en, this message translates to:
  /// **'Change keyword'**
  String get searchTryAnother;

  /// No description provided for @searchLoadErrorTitle.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t load results'**
  String get searchLoadErrorTitle;

  /// No description provided for @searchLoadErrorBody.
  ///
  /// In en, this message translates to:
  /// **'Check your connection and try again.'**
  String get searchLoadErrorBody;

  /// No description provided for @searchEndOfList.
  ///
  /// In en, this message translates to:
  /// **'You\'ve seen all results'**
  String get searchEndOfList;

  /// No description provided for @areaSearchHint.
  ///
  /// In en, this message translates to:
  /// **'Search ward or province...'**
  String get areaSearchHint;

  /// No description provided for @areaMyLocationSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Use your current GPS location'**
  String get areaMyLocationSubtitle;

  /// No description provided for @areaRecentTitle.
  ///
  /// In en, this message translates to:
  /// **'Recently chosen areas'**
  String get areaRecentTitle;

  /// No description provided for @areaWholeProvince.
  ///
  /// In en, this message translates to:
  /// **'Whole province / city'**
  String get areaWholeProvince;

  /// No description provided for @areaNoResultsTitle.
  ///
  /// In en, this message translates to:
  /// **'No matching area'**
  String get areaNoResultsTitle;

  /// No description provided for @areaNoResultsBody.
  ///
  /// In en, this message translates to:
  /// **'Try another ward or province name.'**
  String get areaNoResultsBody;

  /// No description provided for @areaSearchErrorTitle.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t search areas'**
  String get areaSearchErrorTitle;

  /// No description provided for @listingFilterTitle.
  ///
  /// In en, this message translates to:
  /// **'Filters'**
  String get listingFilterTitle;

  /// No description provided for @listingFilterCategory.
  ///
  /// In en, this message translates to:
  /// **'Category'**
  String get listingFilterCategory;

  /// No description provided for @listingFilterAllCategories.
  ///
  /// In en, this message translates to:
  /// **'All'**
  String get listingFilterAllCategories;

  /// No description provided for @listingFilterCategoryError.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t load categories'**
  String get listingFilterCategoryError;

  /// No description provided for @listingFilterPrice.
  ///
  /// In en, this message translates to:
  /// **'Price range'**
  String get listingFilterPrice;

  /// No description provided for @listingFilterPriceMin.
  ///
  /// In en, this message translates to:
  /// **'Min price'**
  String get listingFilterPriceMin;

  /// No description provided for @listingFilterPriceMax.
  ///
  /// In en, this message translates to:
  /// **'Max price'**
  String get listingFilterPriceMax;

  /// No description provided for @listingFilterPriceAny.
  ///
  /// In en, this message translates to:
  /// **'Any'**
  String get listingFilterPriceAny;

  /// No description provided for @listingFilterPriceHelper.
  ///
  /// In en, this message translates to:
  /// **'Exchange-only listings (no price) are hidden when filtering by price.'**
  String get listingFilterPriceHelper;

  /// No description provided for @listingFilterPriceInvalid.
  ///
  /// In en, this message translates to:
  /// **'Min price is higher than max price.'**
  String get listingFilterPriceInvalid;

  /// No description provided for @listingFilterPriceUnder.
  ///
  /// In en, this message translates to:
  /// **'Under {price}'**
  String listingFilterPriceUnder(String price);

  /// No description provided for @listingFilterPriceOver.
  ///
  /// In en, this message translates to:
  /// **'Over {price}'**
  String listingFilterPriceOver(String price);

  /// No description provided for @listingFilterPriceBetween.
  ///
  /// In en, this message translates to:
  /// **'{min} – {max}'**
  String listingFilterPriceBetween(String min, String max);

  /// No description provided for @listingFilterCondition.
  ///
  /// In en, this message translates to:
  /// **'Condition'**
  String get listingFilterCondition;

  /// No description provided for @listingFilterDeal.
  ///
  /// In en, this message translates to:
  /// **'Deal type'**
  String get listingFilterDeal;

  /// No description provided for @listingFilterDistance.
  ///
  /// In en, this message translates to:
  /// **'Distance'**
  String get listingFilterDistance;

  /// No description provided for @listingFilterReset.
  ///
  /// In en, this message translates to:
  /// **'Clear all'**
  String get listingFilterReset;

  /// No description provided for @listingFilterApply.
  ///
  /// In en, this message translates to:
  /// **'Apply'**
  String get listingFilterApply;

  /// No description provided for @listingFilterApplyCount.
  ///
  /// In en, this message translates to:
  /// **'Apply ({count})'**
  String listingFilterApplyCount(int count);

  /// No description provided for @priceThousands.
  ///
  /// In en, this message translates to:
  /// **'{value}K'**
  String priceThousands(String value);

  /// No description provided for @priceMillions.
  ///
  /// In en, this message translates to:
  /// **'{value}M'**
  String priceMillions(String value);

  /// No description provided for @categoryDetailSearch.
  ///
  /// In en, this message translates to:
  /// **'Search'**
  String get categoryDetailSearch;

  /// No description provided for @categoryDetailEmptyTitle.
  ///
  /// In en, this message translates to:
  /// **'No listings in this category yet'**
  String get categoryDetailEmptyTitle;

  /// No description provided for @categoryDetailEmptyBody.
  ///
  /// In en, this message translates to:
  /// **'Be the first to post something in this category.'**
  String get categoryDetailEmptyBody;

  /// No description provided for @categoryDetailPostListing.
  ///
  /// In en, this message translates to:
  /// **'Post a listing'**
  String get categoryDetailPostListing;

  /// No description provided for @categoryDetailFilteredEmptyTitle.
  ///
  /// In en, this message translates to:
  /// **'No listings match your filters'**
  String get categoryDetailFilteredEmptyTitle;

  /// No description provided for @categoryDetailFilteredEmptyBody.
  ///
  /// In en, this message translates to:
  /// **'Try removing some filters to see more listings.'**
  String get categoryDetailFilteredEmptyBody;

  /// No description provided for @categoryDetailLoadErrorTitle.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t load this category'**
  String get categoryDetailLoadErrorTitle;

  /// No description provided for @categoryDetailLoadErrorBody.
  ///
  /// In en, this message translates to:
  /// **'Check your connection and try again.'**
  String get categoryDetailLoadErrorBody;

  /// No description provided for @categoryDetailEndOfList.
  ///
  /// In en, this message translates to:
  /// **'You\'ve seen every listing in this category'**
  String get categoryDetailEndOfList;

  /// No description provided for @wantedAlertTitle.
  ///
  /// In en, this message translates to:
  /// **'Wanted alerts'**
  String get wantedAlertTitle;

  /// No description provided for @wantedAlertSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Reserve what you need, get notified when it is posted'**
  String get wantedAlertSubtitle;

  /// No description provided for @wantedAlertActiveCount.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =1{1 active alert} other{{count} active alerts}}'**
  String wantedAlertActiveCount(int count);

  /// No description provided for @wantedAlertCreate.
  ///
  /// In en, this message translates to:
  /// **'Create alert'**
  String get wantedAlertCreate;

  /// No description provided for @wantedAlertNew.
  ///
  /// In en, this message translates to:
  /// **'New alert'**
  String get wantedAlertNew;

  /// No description provided for @wantedAlertEmptyTitle.
  ///
  /// In en, this message translates to:
  /// **'No alerts yet'**
  String get wantedAlertEmptyTitle;

  /// No description provided for @wantedAlertEmptyBody.
  ///
  /// In en, this message translates to:
  /// **'Tell us what you are looking for and ReStore will notify you as soon as something similar is posted.'**
  String get wantedAlertEmptyBody;

  /// No description provided for @wantedAlertLoadErrorTitle.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t load your alerts'**
  String get wantedAlertLoadErrorTitle;

  /// No description provided for @wantedAlertLoadErrorBody.
  ///
  /// In en, this message translates to:
  /// **'Check your connection and try again.'**
  String get wantedAlertLoadErrorBody;

  /// No description provided for @wantedAlertNewMatches.
  ///
  /// In en, this message translates to:
  /// **'{count} new'**
  String wantedAlertNewMatches(int count);

  /// No description provided for @wantedAlertMatchCount.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =1{1 match} other{{count} matches}}'**
  String wantedAlertMatchCount(int count);

  /// No description provided for @wantedAlertNoMatchYet.
  ///
  /// In en, this message translates to:
  /// **'No matches yet'**
  String get wantedAlertNoMatchYet;

  /// No description provided for @wantedAlertLastMatched.
  ///
  /// In en, this message translates to:
  /// **'Last match {time}'**
  String wantedAlertLastMatched(String time);

  /// No description provided for @wantedAlertCreatedAt.
  ///
  /// In en, this message translates to:
  /// **'Created {time}'**
  String wantedAlertCreatedAt(String time);

  /// No description provided for @wantedAlertWatching.
  ///
  /// In en, this message translates to:
  /// **'Watching'**
  String get wantedAlertWatching;

  /// No description provided for @wantedAlertAnyCategory.
  ///
  /// In en, this message translates to:
  /// **'Any category'**
  String get wantedAlertAnyCategory;

  /// No description provided for @wantedAlertNationwide.
  ///
  /// In en, this message translates to:
  /// **'Nationwide'**
  String get wantedAlertNationwide;

  /// No description provided for @wantedAlertAnyPrice.
  ///
  /// In en, this message translates to:
  /// **'Any price'**
  String get wantedAlertAnyPrice;

  /// No description provided for @wantedAlertAnyCondition.
  ///
  /// In en, this message translates to:
  /// **'Any condition'**
  String get wantedAlertAnyCondition;

  /// No description provided for @wantedAlertAnyDeal.
  ///
  /// In en, this message translates to:
  /// **'Buy or exchange'**
  String get wantedAlertAnyDeal;

  /// No description provided for @wantedAlertPriceFrom.
  ///
  /// In en, this message translates to:
  /// **'From {price}'**
  String wantedAlertPriceFrom(String price);

  /// No description provided for @wantedAlertPriceUpTo.
  ///
  /// In en, this message translates to:
  /// **'Up to {price}'**
  String wantedAlertPriceUpTo(String price);

  /// No description provided for @wantedAlertPriceRange.
  ///
  /// In en, this message translates to:
  /// **'{min} – {max}'**
  String wantedAlertPriceRange(String min, String max);

  /// No description provided for @wantedAlertDelete.
  ///
  /// In en, this message translates to:
  /// **'Delete alert'**
  String get wantedAlertDelete;

  /// No description provided for @wantedAlertDeleteTitle.
  ///
  /// In en, this message translates to:
  /// **'Delete this alert?'**
  String get wantedAlertDeleteTitle;

  /// No description provided for @wantedAlertDeleteBody.
  ///
  /// In en, this message translates to:
  /// **'ReStore will stop notifying you about “{keywords}”. You can create it again anytime.'**
  String wantedAlertDeleteBody(String keywords);

  /// No description provided for @wantedAlertKeep.
  ///
  /// In en, this message translates to:
  /// **'Keep'**
  String get wantedAlertKeep;

  /// No description provided for @wantedAlertDeleted.
  ///
  /// In en, this message translates to:
  /// **'Alert deleted. You won\'t get new matches for it anymore.'**
  String get wantedAlertDeleted;

  /// No description provided for @wantedAlertDeleteError.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t delete the alert. Please try again.'**
  String get wantedAlertDeleteError;

  /// No description provided for @wantedAlertSearchHint.
  ///
  /// In en, this message translates to:
  /// **'What are you looking for?'**
  String get wantedAlertSearchHint;

  /// No description provided for @wantedAlertIntroTitle.
  ///
  /// In en, this message translates to:
  /// **'Search first, get alerted later'**
  String get wantedAlertIntroTitle;

  /// No description provided for @wantedAlertIntroStep1.
  ///
  /// In en, this message translates to:
  /// **'Type what you need and ReStore shows similar listings right away.'**
  String get wantedAlertIntroStep1;

  /// No description provided for @wantedAlertIntroStep2.
  ///
  /// In en, this message translates to:
  /// **'Found a good one? Open it now, no need to wait.'**
  String get wantedAlertIntroStep2;

  /// No description provided for @wantedAlertIntroStep3.
  ///
  /// In en, this message translates to:
  /// **'Nothing yet? Create an alert and get a link as soon as a similar listing appears.'**
  String get wantedAlertIntroStep3;

  /// No description provided for @wantedAlertSkipToCompose.
  ///
  /// In en, this message translates to:
  /// **'Skip, write the alert'**
  String get wantedAlertSkipToCompose;

  /// No description provided for @wantedAlertSuggestionsTitle.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =1{1 similar listing available} other{{count} similar listings available}}'**
  String wantedAlertSuggestionsTitle(int count);

  /// No description provided for @wantedAlertSuggestionsHint.
  ///
  /// In en, this message translates to:
  /// **'None of these? Create an alert to hear about new ones.'**
  String get wantedAlertSuggestionsHint;

  /// No description provided for @wantedAlertSuggestionsEmptyTitle.
  ///
  /// In en, this message translates to:
  /// **'Nothing similar yet'**
  String get wantedAlertSuggestionsEmptyTitle;

  /// No description provided for @wantedAlertSuggestionsEmptyBody.
  ///
  /// In en, this message translates to:
  /// **'Create an alert and ReStore will tell you as soon as someone posts it.'**
  String get wantedAlertSuggestionsEmptyBody;

  /// No description provided for @wantedAlertSuggestionsErrorTitle.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t load suggestions'**
  String get wantedAlertSuggestionsErrorTitle;

  /// No description provided for @wantedAlertSuggestionsErrorBody.
  ///
  /// In en, this message translates to:
  /// **'You can still create the alert now.'**
  String get wantedAlertSuggestionsErrorBody;

  /// No description provided for @wantedAlertMatchPercent.
  ///
  /// In en, this message translates to:
  /// **'{percent}% match'**
  String wantedAlertMatchPercent(int percent);

  /// No description provided for @wantedAlertNotRightCta.
  ///
  /// In en, this message translates to:
  /// **'Not it? Create an alert'**
  String get wantedAlertNotRightCta;

  /// No description provided for @wantedAlertComposeTitle.
  ///
  /// In en, this message translates to:
  /// **'Set up your alert'**
  String get wantedAlertComposeTitle;

  /// No description provided for @wantedAlertComposeSubtitle.
  ///
  /// In en, this message translates to:
  /// **'When a similar listing is posted, ReStore sends you a link to it.'**
  String get wantedAlertComposeSubtitle;

  /// No description provided for @wantedAlertKeywordsLabel.
  ///
  /// In en, this message translates to:
  /// **'What you want'**
  String get wantedAlertKeywordsLabel;

  /// No description provided for @wantedAlertKeywordsHint.
  ///
  /// In en, this message translates to:
  /// **'e.g. Canon AE-1 film camera'**
  String get wantedAlertKeywordsHint;

  /// No description provided for @wantedAlertKeywordsHelper.
  ///
  /// In en, this message translates to:
  /// **'Name, brand or model. It doesn\'t have to be exact, similar listings count too.'**
  String get wantedAlertKeywordsHelper;

  /// No description provided for @wantedAlertKeywordsError.
  ///
  /// In en, this message translates to:
  /// **'Enter at least {min} characters'**
  String wantedAlertKeywordsError(int min);

  /// No description provided for @wantedAlertCriteriaTitle.
  ///
  /// In en, this message translates to:
  /// **'Criteria (optional)'**
  String get wantedAlertCriteriaTitle;

  /// No description provided for @wantedAlertCriteriaCategory.
  ///
  /// In en, this message translates to:
  /// **'Category'**
  String get wantedAlertCriteriaCategory;

  /// No description provided for @wantedAlertCriteriaPrice.
  ///
  /// In en, this message translates to:
  /// **'Price range'**
  String get wantedAlertCriteriaPrice;

  /// No description provided for @wantedAlertCriteriaCondition.
  ///
  /// In en, this message translates to:
  /// **'Condition'**
  String get wantedAlertCriteriaCondition;

  /// No description provided for @wantedAlertCriteriaDeal.
  ///
  /// In en, this message translates to:
  /// **'Deal type'**
  String get wantedAlertCriteriaDeal;

  /// No description provided for @wantedAlertCriteriaArea.
  ///
  /// In en, this message translates to:
  /// **'Area'**
  String get wantedAlertCriteriaArea;

  /// No description provided for @wantedAlertEditCriteria.
  ///
  /// In en, this message translates to:
  /// **'Edit criteria'**
  String get wantedAlertEditCriteria;

  /// No description provided for @wantedAlertLevelTitle.
  ///
  /// In en, this message translates to:
  /// **'How close'**
  String get wantedAlertLevelTitle;

  /// No description provided for @wantedAlertLevelBroad.
  ///
  /// In en, this message translates to:
  /// **'Broad'**
  String get wantedAlertLevelBroad;

  /// No description provided for @wantedAlertLevelBalanced.
  ///
  /// In en, this message translates to:
  /// **'Balanced'**
  String get wantedAlertLevelBalanced;

  /// No description provided for @wantedAlertLevelStrict.
  ///
  /// In en, this message translates to:
  /// **'Close'**
  String get wantedAlertLevelStrict;

  /// No description provided for @wantedAlertLevelBroadDesc.
  ///
  /// In en, this message translates to:
  /// **'Includes loosely similar listings, so you get more alerts.'**
  String get wantedAlertLevelBroadDesc;

  /// No description provided for @wantedAlertLevelBalancedDesc.
  ///
  /// In en, this message translates to:
  /// **'Most keywords must match, small typos are fine.'**
  String get wantedAlertLevelBalancedDesc;

  /// No description provided for @wantedAlertLevelStrictDesc.
  ///
  /// In en, this message translates to:
  /// **'Only listings that are almost exactly what you typed.'**
  String get wantedAlertLevelStrictDesc;

  /// No description provided for @wantedAlertPreviewTitle.
  ///
  /// In en, this message translates to:
  /// **'Listings matching right now'**
  String get wantedAlertPreviewTitle;

  /// No description provided for @wantedAlertPreviewEmpty.
  ///
  /// In en, this message translates to:
  /// **'Nothing matches right now. You\'ll be notified when something is posted.'**
  String get wantedAlertPreviewEmpty;

  /// No description provided for @wantedAlertPreviewNeedKeywords.
  ///
  /// In en, this message translates to:
  /// **'Enter what you want to preview matching listings.'**
  String get wantedAlertPreviewNeedKeywords;

  /// No description provided for @wantedAlertSave.
  ///
  /// In en, this message translates to:
  /// **'Turn on alert'**
  String get wantedAlertSave;

  /// No description provided for @wantedAlertCreated.
  ///
  /// In en, this message translates to:
  /// **'Alert on for “{keywords}”. ReStore will notify you when something similar is posted.'**
  String wantedAlertCreated(String keywords);

  /// No description provided for @wantedAlertCreateError.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t create the alert. Please try again.'**
  String get wantedAlertCreateError;

  /// No description provided for @wantedAlertNewTag.
  ///
  /// In en, this message translates to:
  /// **'New'**
  String get wantedAlertNewTag;

  /// No description provided for @wantedAlertMatchesTitle.
  ///
  /// In en, this message translates to:
  /// **'Matched listings'**
  String get wantedAlertMatchesTitle;

  /// No description provided for @wantedAlertMatchesEmptyTitle.
  ///
  /// In en, this message translates to:
  /// **'No matches yet'**
  String get wantedAlertMatchesEmptyTitle;

  /// No description provided for @wantedAlertMatchesEmptyBody.
  ///
  /// In en, this message translates to:
  /// **'When someone posts something similar, ReStore notifies you and it shows up here.'**
  String get wantedAlertMatchesEmptyBody;

  /// No description provided for @wantedAlertEndOfList.
  ///
  /// In en, this message translates to:
  /// **'You\'ve seen every match'**
  String get wantedAlertEndOfList;

  /// No description provided for @wantedAlertPromptTitle.
  ///
  /// In en, this message translates to:
  /// **'Not finding it?'**
  String get wantedAlertPromptTitle;

  /// No description provided for @wantedAlertPromptBody.
  ///
  /// In en, this message translates to:
  /// **'Set an alert for “{query}” and ReStore will tell you when something similar is posted.'**
  String wantedAlertPromptBody(String query);

  /// No description provided for @areaNationwide.
  ///
  /// In en, this message translates to:
  /// **'Nationwide'**
  String get areaNationwide;

  /// No description provided for @areaNationwideSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Any area, listings from anywhere'**
  String get areaNationwideSubtitle;

  /// No description provided for @trustedShopsTitle.
  ///
  /// In en, this message translates to:
  /// **'Trusted shops'**
  String get trustedShopsTitle;

  /// No description provided for @trustedShopsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Genuine stores verified by ReStore'**
  String get trustedShopsSubtitle;

  /// No description provided for @trustedShopsAllCategories.
  ///
  /// In en, this message translates to:
  /// **'All'**
  String get trustedShopsAllCategories;

  /// No description provided for @trustedShopsOfficialTitle.
  ///
  /// In en, this message translates to:
  /// **'Official brands'**
  String get trustedShopsOfficialTitle;

  /// No description provided for @trustedShopsCertifiedTitle.
  ///
  /// In en, this message translates to:
  /// **'ReStore certified'**
  String get trustedShopsCertifiedTitle;

  /// No description provided for @trustedShopsShowcaseTitle.
  ///
  /// In en, this message translates to:
  /// **'Shop by brand'**
  String get trustedShopsShowcaseTitle;

  /// No description provided for @trustedShopsShowcaseSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Picks from the most followed shops'**
  String get trustedShopsShowcaseSubtitle;

  /// No description provided for @trustedShopsViewShop.
  ///
  /// In en, this message translates to:
  /// **'View shop'**
  String get trustedShopsViewShop;

  /// No description provided for @trustedShopsAllProductsTitle.
  ///
  /// In en, this message translates to:
  /// **'All products'**
  String get trustedShopsAllProductsTitle;

  /// No description provided for @trustedShopsAllProductsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'From every verified shop'**
  String get trustedShopsAllProductsSubtitle;

  /// No description provided for @trustedShopsEndOfList.
  ///
  /// In en, this message translates to:
  /// **'You\'ve seen every product from trusted shops'**
  String get trustedShopsEndOfList;

  /// No description provided for @trustedShopsEmptyTitle.
  ///
  /// In en, this message translates to:
  /// **'No trusted shops here yet'**
  String get trustedShopsEmptyTitle;

  /// No description provided for @trustedShopsEmptyBody.
  ///
  /// In en, this message translates to:
  /// **'Verified shops in this category will show up here.'**
  String get trustedShopsEmptyBody;

  /// No description provided for @trustedShopsLoadErrorTitle.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t load trusted shops'**
  String get trustedShopsLoadErrorTitle;

  /// No description provided for @trustedShopsLoadErrorBody.
  ///
  /// In en, this message translates to:
  /// **'Check your connection and try again.'**
  String get trustedShopsLoadErrorBody;

  /// No description provided for @trustedShopsFamousTitle.
  ///
  /// In en, this message translates to:
  /// **'Famous brands'**
  String get trustedShopsFamousTitle;

  /// No description provided for @trustedShopsFamousSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Official stores of big-name brands'**
  String get trustedShopsFamousSubtitle;

  /// No description provided for @trustedShopsDealsTitle.
  ///
  /// In en, this message translates to:
  /// **'Luxury for less'**
  String get trustedShopsDealsTitle;

  /// No description provided for @trustedShopsDealsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Genuine brand products, now on sale'**
  String get trustedShopsDealsSubtitle;

  /// No description provided for @trustedShopsDealsUpTo.
  ///
  /// In en, this message translates to:
  /// **'Up to -{percent}%'**
  String trustedShopsDealsUpTo(int percent);

  /// No description provided for @trustedShopsNewReleasesTitle.
  ///
  /// In en, this message translates to:
  /// **'Hot new releases'**
  String get trustedShopsNewReleasesTitle;

  /// No description provided for @trustedShopsNewReleasesSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Fresh launches from famous brands'**
  String get trustedShopsNewReleasesSubtitle;

  /// No description provided for @trustedShopsNewReleaseTag.
  ///
  /// In en, this message translates to:
  /// **'Just launched'**
  String get trustedShopsNewReleaseTag;

  /// No description provided for @trustedShopsLaunchedDaysAgo.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =0{Launched today} =1{Launched yesterday} other{Launched {count} days ago}}'**
  String trustedShopsLaunchedDaysAgo(int count);

  /// No description provided for @trustedShopsNewShopsTitle.
  ///
  /// In en, this message translates to:
  /// **'New stores'**
  String get trustedShopsNewShopsTitle;

  /// No description provided for @trustedShopsNewShopsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Shops ReStore verified recently'**
  String get trustedShopsNewShopsSubtitle;

  /// No description provided for @trustedShopsNavFamous.
  ///
  /// In en, this message translates to:
  /// **'Brands'**
  String get trustedShopsNavFamous;

  /// No description provided for @trustedShopsNavDeals.
  ///
  /// In en, this message translates to:
  /// **'Deals'**
  String get trustedShopsNavDeals;

  /// No description provided for @trustedShopsNavNewReleases.
  ///
  /// In en, this message translates to:
  /// **'New releases'**
  String get trustedShopsNavNewReleases;

  /// No description provided for @trustedShopsNavNewShops.
  ///
  /// In en, this message translates to:
  /// **'New stores'**
  String get trustedShopsNavNewShops;

  /// No description provided for @trustedShopsNavShowcases.
  ///
  /// In en, this message translates to:
  /// **'By brand'**
  String get trustedShopsNavShowcases;

  /// No description provided for @trustedShopsNavAll.
  ///
  /// In en, this message translates to:
  /// **'All products'**
  String get trustedShopsNavAll;

  /// No description provided for @trustedShopsSeeAll.
  ///
  /// In en, this message translates to:
  /// **'See all'**
  String get trustedShopsSeeAll;

  /// No description provided for @trustedShopsOnSaleFilter.
  ///
  /// In en, this message translates to:
  /// **'On sale'**
  String get trustedShopsOnSaleFilter;

  /// No description provided for @shopDetailEventsTitle.
  ///
  /// In en, this message translates to:
  /// **'Shop events'**
  String get shopDetailEventsTitle;

  /// No description provided for @shopDetailEventsSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Promotions approved by ReStore'**
  String get shopDetailEventsSubtitle;

  /// No description provided for @shopVerificationOfficial.
  ///
  /// In en, this message translates to:
  /// **'Official'**
  String get shopVerificationOfficial;

  /// No description provided for @shopVerificationCertified.
  ///
  /// In en, this message translates to:
  /// **'Certified'**
  String get shopVerificationCertified;

  /// No description provided for @shopVerificationOfficialDesc.
  ///
  /// In en, this message translates to:
  /// **'The brand\'s own store or its authorised distributor, selling genuine goods with brand warranty.'**
  String get shopVerificationOfficialDesc;

  /// No description provided for @shopVerificationCertifiedDesc.
  ///
  /// In en, this message translates to:
  /// **'ReStore checked this shop\'s business licence, address and trading history before certifying it.'**
  String get shopVerificationCertifiedDesc;

  /// No description provided for @shopVerificationSheetTitle.
  ///
  /// In en, this message translates to:
  /// **'About verified shops'**
  String get shopVerificationSheetTitle;

  /// No description provided for @shopVerificationSheetSubtitle.
  ///
  /// In en, this message translates to:
  /// **'Only shops that pass one of these checks appear in Trusted shops'**
  String get shopVerificationSheetSubtitle;

  /// No description provided for @shopVerificationSheetNote.
  ///
  /// In en, this message translates to:
  /// **'ReStore reviews verified shops regularly and removes the badge if a shop breaks the rules or gets repeated complaints.'**
  String get shopVerificationSheetNote;

  /// No description provided for @shopCertificateTitle.
  ///
  /// In en, this message translates to:
  /// **'Shop certificate'**
  String get shopCertificateTitle;

  /// No description provided for @shopCertificateCode.
  ///
  /// In en, this message translates to:
  /// **'Certificate no.'**
  String get shopCertificateCode;

  /// No description provided for @shopVerifiedSince.
  ///
  /// In en, this message translates to:
  /// **'Verified on'**
  String get shopVerifiedSince;

  /// No description provided for @shopVerifiedSinceShort.
  ///
  /// In en, this message translates to:
  /// **'Verified {date}'**
  String shopVerifiedSinceShort(String date);

  /// No description provided for @shopFollow.
  ///
  /// In en, this message translates to:
  /// **'Follow'**
  String get shopFollow;

  /// No description provided for @shopFollowing.
  ///
  /// In en, this message translates to:
  /// **'Following'**
  String get shopFollowing;

  /// No description provided for @shopFollowerCount.
  ///
  /// In en, this message translates to:
  /// **'{count} followers'**
  String shopFollowerCount(String count);

  /// No description provided for @shopListingCount.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =1{1 product} other{{count} products}}'**
  String shopListingCount(int count);

  /// No description provided for @shopRatingCount.
  ///
  /// In en, this message translates to:
  /// **'{count} reviews'**
  String shopRatingCount(String count);

  /// No description provided for @shopFollowersLabel.
  ///
  /// In en, this message translates to:
  /// **'Followers'**
  String get shopFollowersLabel;

  /// No description provided for @shopProductsLabel.
  ///
  /// In en, this message translates to:
  /// **'Products'**
  String get shopProductsLabel;

  /// No description provided for @shopDescriptionMore.
  ///
  /// In en, this message translates to:
  /// **'Show more'**
  String get shopDescriptionMore;

  /// No description provided for @shopDescriptionLess.
  ///
  /// In en, this message translates to:
  /// **'Show less'**
  String get shopDescriptionLess;

  /// No description provided for @shopDetailProductsTitle.
  ///
  /// In en, this message translates to:
  /// **'Products for sale'**
  String get shopDetailProductsTitle;

  /// No description provided for @shopDetailEmptyTitle.
  ///
  /// In en, this message translates to:
  /// **'No products yet'**
  String get shopDetailEmptyTitle;

  /// No description provided for @shopDetailEmptyBody.
  ///
  /// In en, this message translates to:
  /// **'Follow this shop to hear about new products first.'**
  String get shopDetailEmptyBody;

  /// No description provided for @shopDetailEndOfList.
  ///
  /// In en, this message translates to:
  /// **'You\'ve seen every product from this shop'**
  String get shopDetailEndOfList;

  /// No description provided for @shopDetailLoadErrorTitle.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t load this shop'**
  String get shopDetailLoadErrorTitle;

  /// No description provided for @shopDetailLoadErrorBody.
  ///
  /// In en, this message translates to:
  /// **'Check your connection and try again.'**
  String get shopDetailLoadErrorBody;

  /// No description provided for @postingQuotaPersonalTitle.
  ///
  /// In en, this message translates to:
  /// **'Personal account'**
  String get postingQuotaPersonalTitle;

  /// No description provided for @postingQuotaBannerMessage.
  ///
  /// In en, this message translates to:
  /// **'Free listings per category: {min} to {max} active at a time. Each listing stays up for {days} days.'**
  String postingQuotaBannerMessage(int min, int max, int days);

  /// No description provided for @postingRulesAction.
  ///
  /// In en, this message translates to:
  /// **'View rules'**
  String get postingRulesAction;

  /// No description provided for @postingQuotaUsage.
  ///
  /// In en, this message translates to:
  /// **'{used}/{limit} used'**
  String postingQuotaUsage(int used, int limit);

  /// No description provided for @postingQuotaFull.
  ///
  /// In en, this message translates to:
  /// **'Limit of {limit} reached'**
  String postingQuotaFull(int limit);

  /// No description provided for @postingQuotaLastSlot.
  ///
  /// In en, this message translates to:
  /// **'1 slot left'**
  String get postingQuotaLastSlot;

  /// No description provided for @postingQuotaRemainingInCategory.
  ///
  /// In en, this message translates to:
  /// **'{remaining}/{limit} slots left in this category'**
  String postingQuotaRemainingInCategory(int remaining, int limit);

  /// No description provided for @postingLimitTitle.
  ///
  /// In en, this message translates to:
  /// **'Category limit reached'**
  String get postingLimitTitle;

  /// No description provided for @postingLimitMessage.
  ///
  /// In en, this message translates to:
  /// **'Personal accounts can have up to {limit} active listings in {category}. Free up a slot to post a new one.'**
  String postingLimitMessage(int limit, String category);

  /// No description provided for @postingLimitWaysTitle.
  ///
  /// In en, this message translates to:
  /// **'How to free a slot'**
  String get postingLimitWaysTitle;

  /// No description provided for @postingLimitTipSold.
  ///
  /// In en, this message translates to:
  /// **'Mark items you have sold as Sold'**
  String get postingLimitTipSold;

  /// No description provided for @postingLimitTipHide.
  ///
  /// In en, this message translates to:
  /// **'Hide listings you no longer want to sell'**
  String get postingLimitTipHide;

  /// No description provided for @postingLimitTipExpire.
  ///
  /// In en, this message translates to:
  /// **'Listings expire after {days} days and free their slot'**
  String postingLimitTipExpire(int days);

  /// No description provided for @manageMyListings.
  ///
  /// In en, this message translates to:
  /// **'Manage my listings'**
  String get manageMyListings;

  /// No description provided for @chooseAnotherCategory.
  ///
  /// In en, this message translates to:
  /// **'Other category'**
  String get chooseAnotherCategory;

  /// No description provided for @postingRulesTitle.
  ///
  /// In en, this message translates to:
  /// **'Posting rules'**
  String get postingRulesTitle;

  /// No description provided for @postingRulesSubtitle.
  ///
  /// In en, this message translates to:
  /// **'For personal sellers'**
  String get postingRulesSubtitle;

  /// No description provided for @postingRuleLimit.
  ///
  /// In en, this message translates to:
  /// **'{min} to {max} free active listings per category, depending on the category. High-value items such as phones and vehicles get 1.'**
  String postingRuleLimit(int min, int max);

  /// No description provided for @postingRuleCounted.
  ///
  /// In en, this message translates to:
  /// **'Only active and pending listings count. Sold, hidden or expired listings do not.'**
  String get postingRuleCounted;

  /// No description provided for @postingRuleDuration.
  ///
  /// In en, this message translates to:
  /// **'Each listing is shown for {days} days after it is approved.'**
  String postingRuleDuration(int days);

  /// No description provided for @postingRuleFree.
  ///
  /// In en, this message translates to:
  /// **'Posting is free. Every listing is reviewed before it goes live.'**
  String get postingRuleFree;

  /// No description provided for @postingRulePersonalUse.
  ///
  /// In en, this message translates to:
  /// **'Personal accounts are for selling your own used items. If you post many items regularly like a business, ReStore may move you to a business account.'**
  String get postingRulePersonalUse;

  /// No description provided for @postingRuleBusiness.
  ///
  /// In en, this message translates to:
  /// **'Business plan (coming soon): up to {limit} listings per category. Shop plan: your own shop page.'**
  String postingRuleBusiness(int limit);

  /// No description provided for @homeGreetingPro.
  ///
  /// In en, this message translates to:
  /// **'Hi pro seller {name} 👋'**
  String homeGreetingPro(String name);

  /// No description provided for @homeGreetingShop.
  ///
  /// In en, this message translates to:
  /// **'Hi shop owner {name} 👋'**
  String homeGreetingShop(String name);

  /// No description provided for @planPersonal.
  ///
  /// In en, this message translates to:
  /// **'Personal'**
  String get planPersonal;

  /// No description provided for @planPro.
  ///
  /// In en, this message translates to:
  /// **'Pro seller'**
  String get planPro;

  /// No description provided for @planShop.
  ///
  /// In en, this message translates to:
  /// **'Shop'**
  String get planShop;

  /// No description provided for @devPlanTag.
  ///
  /// In en, this message translates to:
  /// **'TEST'**
  String get devPlanTag;

  /// No description provided for @devPlanSwitchTooltip.
  ///
  /// In en, this message translates to:
  /// **'Switch plan for testing (mock data only)'**
  String get devPlanSwitchTooltip;

  /// No description provided for @trustedShopsFamousEyebrow.
  ///
  /// In en, this message translates to:
  /// **'Official'**
  String get trustedShopsFamousEyebrow;

  /// No description provided for @trustedShopsDealsEyebrow.
  ///
  /// In en, this message translates to:
  /// **'On sale'**
  String get trustedShopsDealsEyebrow;

  /// No description provided for @trustedShopsNewReleasesEyebrow.
  ///
  /// In en, this message translates to:
  /// **'Just launched'**
  String get trustedShopsNewReleasesEyebrow;

  /// No description provided for @trustedShopsNewShopsEyebrow.
  ///
  /// In en, this message translates to:
  /// **'Newly verified'**
  String get trustedShopsNewShopsEyebrow;

  /// No description provided for @trustedShopsShowcaseEyebrow.
  ///
  /// In en, this message translates to:
  /// **'By brand'**
  String get trustedShopsShowcaseEyebrow;

  /// No description provided for @trustedShopsAllProductsEyebrow.
  ///
  /// In en, this message translates to:
  /// **'Explore'**
  String get trustedShopsAllProductsEyebrow;

  /// No description provided for @feedsComposePrompt.
  ///
  /// In en, this message translates to:
  /// **'What\'s on your mind? Share an item or ask the community'**
  String get feedsComposePrompt;

  /// No description provided for @postAudienceTitle.
  ///
  /// In en, this message translates to:
  /// **'Who can see this post?'**
  String get postAudienceTitle;

  /// No description provided for @postAudienceEveryone.
  ///
  /// In en, this message translates to:
  /// **'Everyone'**
  String get postAudienceEveryone;

  /// No description provided for @postAudienceEveryoneDesc.
  ///
  /// In en, this message translates to:
  /// **'Anyone on ReStore can see it'**
  String get postAudienceEveryoneDesc;

  /// No description provided for @postAudienceFollowers.
  ///
  /// In en, this message translates to:
  /// **'Followers'**
  String get postAudienceFollowers;

  /// No description provided for @postAudienceFollowersDesc.
  ///
  /// In en, this message translates to:
  /// **'Only people who follow you'**
  String get postAudienceFollowersDesc;

  /// No description provided for @postAudienceOnlyMe.
  ///
  /// In en, this message translates to:
  /// **'Only me'**
  String get postAudienceOnlyMe;

  /// No description provided for @postAudienceOnlyMeDesc.
  ///
  /// In en, this message translates to:
  /// **'Saved privately on your page'**
  String get postAudienceOnlyMeDesc;

  /// No description provided for @postComposerSubmit.
  ///
  /// In en, this message translates to:
  /// **'Post'**
  String get postComposerSubmit;

  /// No description provided for @postComposerHint.
  ///
  /// In en, this message translates to:
  /// **'Share an item, a buying tip or ask the community...'**
  String get postComposerHint;

  /// No description provided for @postComposerRemovePhoto.
  ///
  /// In en, this message translates to:
  /// **'Remove photo'**
  String get postComposerRemovePhoto;

  /// No description provided for @postComposerCover.
  ///
  /// In en, this message translates to:
  /// **'Cover'**
  String get postComposerCover;

  /// No description provided for @postComposerListingTag.
  ///
  /// In en, this message translates to:
  /// **'Your listing'**
  String get postComposerListingTag;

  /// No description provided for @postComposerRemoveAttachment.
  ///
  /// In en, this message translates to:
  /// **'Remove'**
  String get postComposerRemoveAttachment;

  /// No description provided for @postComposerWithOne.
  ///
  /// In en, this message translates to:
  /// **'With {name}'**
  String postComposerWithOne(String name);

  /// No description provided for @postComposerWithMany.
  ///
  /// In en, this message translates to:
  /// **'With {name} and {count} others'**
  String postComposerWithMany(String name, int count);

  /// No description provided for @postComposerBackground.
  ///
  /// In en, this message translates to:
  /// **'Background colour'**
  String get postComposerBackground;

  /// No description provided for @postComposerBackgroundDisabled.
  ///
  /// In en, this message translates to:
  /// **'Background colours are for short posts without photos'**
  String get postComposerBackgroundDisabled;

  /// No description provided for @postComposerNoBackground.
  ///
  /// In en, this message translates to:
  /// **'No background'**
  String get postComposerNoBackground;

  /// No description provided for @postComposerAttachListing.
  ///
  /// In en, this message translates to:
  /// **'Attach listing'**
  String get postComposerAttachListing;

  /// No description provided for @postComposerAttachListingHint.
  ///
  /// In en, this message translates to:
  /// **'Show one of your listings in this post'**
  String get postComposerAttachListingHint;

  /// No description provided for @postComposerTopic.
  ///
  /// In en, this message translates to:
  /// **'Topic'**
  String get postComposerTopic;

  /// No description provided for @postComposerTopicHint.
  ///
  /// In en, this message translates to:
  /// **'Helps the right people find your post'**
  String get postComposerTopicHint;

  /// No description provided for @postComposerTagFriends.
  ///
  /// In en, this message translates to:
  /// **'Tag people'**
  String get postComposerTagFriends;

  /// No description provided for @postComposerTagFriendsHint.
  ///
  /// In en, this message translates to:
  /// **'People you follow'**
  String get postComposerTagFriendsHint;

  /// No description provided for @postComposerTaggedCount.
  ///
  /// In en, this message translates to:
  /// **'{count} tagged'**
  String postComposerTaggedCount(int count);

  /// No description provided for @postComposerEmoji.
  ///
  /// In en, this message translates to:
  /// **'Emoji'**
  String get postComposerEmoji;

  /// No description provided for @postComposerPhoto.
  ///
  /// In en, this message translates to:
  /// **'Photos'**
  String get postComposerPhoto;

  /// No description provided for @postComposerVideo.
  ///
  /// In en, this message translates to:
  /// **'Video'**
  String get postComposerVideo;

  /// No description provided for @postComposerLink.
  ///
  /// In en, this message translates to:
  /// **'Link'**
  String get postComposerLink;

  /// No description provided for @postComposerLinkHint.
  ///
  /// In en, this message translates to:
  /// **'Paste a web link to share'**
  String get postComposerLinkHint;

  /// No description provided for @postComposerLinkInvalid.
  ///
  /// In en, this message translates to:
  /// **'This link doesn\'t look right'**
  String get postComposerLinkInvalid;

  /// No description provided for @postComposerLocation.
  ///
  /// In en, this message translates to:
  /// **'Location'**
  String get postComposerLocation;

  /// No description provided for @postComposerTakePhoto.
  ///
  /// In en, this message translates to:
  /// **'Take photo'**
  String get postComposerTakePhoto;

  /// No description provided for @postComposerOpenGallery.
  ///
  /// In en, this message translates to:
  /// **'Gallery'**
  String get postComposerOpenGallery;

  /// No description provided for @postComposerDone.
  ///
  /// In en, this message translates to:
  /// **'Done'**
  String get postComposerDone;

  /// No description provided for @postComposerLoadError.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t load post options, trying again'**
  String get postComposerLoadError;

  /// No description provided for @postComposerDiscardTitle.
  ///
  /// In en, this message translates to:
  /// **'Discard this post?'**
  String get postComposerDiscardTitle;

  /// No description provided for @postComposerDiscardMessage.
  ///
  /// In en, this message translates to:
  /// **'What you\'ve written won\'t be saved'**
  String get postComposerDiscardMessage;

  /// No description provided for @postComposerKeepEditing.
  ///
  /// In en, this message translates to:
  /// **'Keep writing'**
  String get postComposerKeepEditing;

  /// No description provided for @postComposerDiscard.
  ///
  /// In en, this message translates to:
  /// **'Discard post'**
  String get postComposerDiscard;

  /// No description provided for @postComposerPhotoLimit.
  ///
  /// In en, this message translates to:
  /// **'You can add up to {count} photos'**
  String postComposerPhotoLimit(int count);

  /// No description provided for @postComposerPhotoPermission.
  ///
  /// In en, this message translates to:
  /// **'ReStore needs photo access. Please allow it in Settings.'**
  String get postComposerPhotoPermission;

  /// No description provided for @postComposerNoListings.
  ///
  /// In en, this message translates to:
  /// **'You have no active listings to attach yet'**
  String get postComposerNoListings;

  /// No description provided for @postComposerError.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t publish your post, please try again'**
  String get postComposerError;

  /// No description provided for @postComposerPosted.
  ///
  /// In en, this message translates to:
  /// **'Your post is live on the feed'**
  String get postComposerPosted;

  /// No description provided for @authSessionExpired.
  ///
  /// In en, this message translates to:
  /// **'Your session has expired. Please sign in again.'**
  String get authSessionExpired;

  /// No description provided for @draftsTitle.
  ///
  /// In en, this message translates to:
  /// **'Drafts'**
  String get draftsTitle;

  /// No description provided for @draftsBannerTitle.
  ///
  /// In en, this message translates to:
  /// **'Continue a draft'**
  String get draftsBannerTitle;

  /// No description provided for @draftsBannerMessage.
  ///
  /// In en, this message translates to:
  /// **'Unpublished listings: {count}'**
  String draftsBannerMessage(String count);

  /// No description provided for @draftsBannerAction.
  ///
  /// In en, this message translates to:
  /// **'View'**
  String get draftsBannerAction;

  /// No description provided for @draftUntitled.
  ///
  /// In en, this message translates to:
  /// **'Untitled'**
  String get draftUntitled;

  /// No description provided for @draftNoCategory.
  ///
  /// In en, this message translates to:
  /// **'No category yet'**
  String get draftNoCategory;

  /// No description provided for @draftEditedAt.
  ///
  /// In en, this message translates to:
  /// **'Edited {time}'**
  String draftEditedAt(String time);

  /// No description provided for @draftPhotoCount.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =1{1 photo} other{{count} photos}}'**
  String draftPhotoCount(int count);

  /// No description provided for @draftsEmptyTitle.
  ///
  /// In en, this message translates to:
  /// **'No drafts yet'**
  String get draftsEmptyTitle;

  /// No description provided for @draftsEmptyMessage.
  ///
  /// In en, this message translates to:
  /// **'While posting, tap Save draft to finish it later.'**
  String get draftsEmptyMessage;

  /// No description provided for @draftsLoadFailedTitle.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t load drafts'**
  String get draftsLoadFailedTitle;

  /// No description provided for @draftsLoadFailedMessage.
  ///
  /// In en, this message translates to:
  /// **'Check your connection and try again.'**
  String get draftsLoadFailedMessage;

  /// No description provided for @draftOpenFailed.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t open this draft. It may have been published or deleted'**
  String get draftOpenFailed;

  /// No description provided for @draftDeleteTitle.
  ///
  /// In en, this message translates to:
  /// **'Delete draft?'**
  String get draftDeleteTitle;

  /// No description provided for @draftDeleteMessage.
  ///
  /// In en, this message translates to:
  /// **'The draft and its uploaded photos will be deleted permanently.'**
  String get draftDeleteMessage;

  /// No description provided for @draftDeleteConfirm.
  ///
  /// In en, this message translates to:
  /// **'Delete draft'**
  String get draftDeleteConfirm;

  /// No description provided for @draftDeleted.
  ///
  /// In en, this message translates to:
  /// **'Draft deleted'**
  String get draftDeleted;

  /// No description provided for @draftDeletedNamed.
  ///
  /// In en, this message translates to:
  /// **'Deleted draft “{title}”'**
  String draftDeletedNamed(String title);

  /// No description provided for @draftDeleteFailed.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t delete the draft, please try again'**
  String get draftDeleteFailed;

  /// No description provided for @leaveDraftTitle.
  ///
  /// In en, this message translates to:
  /// **'Save before leaving?'**
  String get leaveDraftTitle;

  /// No description provided for @leaveDraftMessage.
  ///
  /// In en, this message translates to:
  /// **'You have unsaved changes. Save a draft to finish it later.'**
  String get leaveDraftMessage;

  /// No description provided for @leaveDraftSave.
  ///
  /// In en, this message translates to:
  /// **'Save draft and leave'**
  String get leaveDraftSave;

  /// No description provided for @leaveDraftDiscard.
  ///
  /// In en, this message translates to:
  /// **'Leave without saving'**
  String get leaveDraftDiscard;

  /// No description provided for @draftLimitTitle.
  ///
  /// In en, this message translates to:
  /// **'{limit} drafts reached'**
  String draftLimitTitle(int limit);

  /// No description provided for @draftLimitTitleUnknown.
  ///
  /// In en, this message translates to:
  /// **'Draft limit reached'**
  String get draftLimitTitleUnknown;

  /// No description provided for @draftLimitMessage.
  ///
  /// In en, this message translates to:
  /// **'Your account can keep up to {limit} drafts. Publish or delete an old draft to save this one.'**
  String draftLimitMessage(int limit);

  /// No description provided for @draftLimitMessageUnknown.
  ///
  /// In en, this message translates to:
  /// **'Your account has reached its draft limit. Publish or delete an old draft to save this one.'**
  String get draftLimitMessageUnknown;

  /// No description provided for @draftLimitViewDrafts.
  ///
  /// In en, this message translates to:
  /// **'View drafts'**
  String get draftLimitViewDrafts;

  /// No description provided for @draftsQuota.
  ///
  /// In en, this message translates to:
  /// **'{used}/{limit} drafts'**
  String draftsQuota(int used, int limit);

  /// No description provided for @listingImageTooLarge.
  ///
  /// In en, this message translates to:
  /// **'A photo is too large (max 5 MB). Remove it or pick another one.'**
  String get listingImageTooLarge;

  /// No description provided for @listingImageUnsupported.
  ///
  /// In en, this message translates to:
  /// **'A photo has an unsupported format (JPEG, PNG or WebP only). Remove it or pick another one.'**
  String get listingImageUnsupported;

  /// No description provided for @listingImageMissing.
  ///
  /// In en, this message translates to:
  /// **'{count, plural, =1{1 photo is no longer on this device and was removed} other{{count} photos are no longer on this device and were removed}}. Pick them again, then save.'**
  String listingImageMissing(int count);

  /// No description provided for @listingSaveNetworkError.
  ///
  /// In en, this message translates to:
  /// **'Couldn\'t reach the server. What was saved is kept, please try again.'**
  String get listingSaveNetworkError;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) =>
      <String>['en', 'vi'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'en':
      return AppLocalizationsEn();
    case 'vi':
      return AppLocalizationsVi();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.',
  );
}
