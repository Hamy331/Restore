import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';
import 'package:restore/core/constants/app_icons.dart';

import '../../../core/constants/app_colors.dart';
import '../../../core/ui/responsive/responsive_content.dart';
import '../../../l10n/app_localizations.dart';
import '../../auth/bloc/auth_bloc.dart';
import '../../auth/bloc/auth_event.dart';
import '../../auth/bloc/auth_context.dart';
import 'package:restore/data/models/user_model.dart';

class AccountView extends StatelessWidget {
  const AccountView({super.key});

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    // Trang này chỉ vào được khi đã đăng nhập (router chặn khách)
    final user = context.watchUser();
    if (user == null) return const SizedBox.shrink();
    return SafeArea(
      bottom: false,
      child: Column(
        children: [
          ResponsiveContent(
            maxWidth: 720,
            child: SizedBox(
              height: 56,
              child: Row(
                children: [
                  Text(
                    l10n.accountTitle,
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    tooltip: l10n.settingsTitle,
                    onPressed: () => context.push('/settings'),
                    icon: const Icon(AppIcons.settings),
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: ColoredBox(
              color: AppColors.background,
              child: SingleChildScrollView(
                // Chừa chỗ cho thanh điều hướng kính nổi phía dưới
                padding: EdgeInsets.only(
                  top: 12,
                  bottom: 12 + MediaQuery.paddingOf(context).bottom,
                ),
                child: ResponsiveContent(
                  maxWidth: 720,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _IdentityCard(
                        user: user,
                        onEdit: () => context.push('/account/edit'),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: _MetricCard(
                              value: 3.toString(),
                              label: l10n.activeListings,
                              onTap: () => context.go('/manage-listings'),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: _MetricCard(
                              value: 12.toString(),
                              label: l10n.soldListings,
                              onTap: () => context.go('/manage-listings'),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(
                        l10n.myAccount,
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textSecondary,
                        ),
                      ),
                      const SizedBox(height: 7),
                      _AccountItem(
                        icon: AppIcons.favorite,
                        label: l10n.savedListings,
                        trailing: 4.toString(),
                        onTap: () => context.push('/favorites'),
                      ),
                      _AccountItem(
                        icon: AppIcons.star,
                        label: l10n.reviews,
                        trailing: 48.toString(),
                        onTap: () => context.push('/seller/${user.id}/reviews'),
                      ),
                      _AccountItem(
                        icon: AppIcons.notification,
                        label: l10n.notifications,
                        trailing: l10n.newCount(2),
                        onTap: () => context.push('/notifications'),
                      ),
                      _AccountItem(
                        icon: AppIcons.location,
                        label: l10n.addressArea,
                        onTap: () => context.push('/account/edit'),
                      ),
                      _AccountItem(
                        icon: AppIcons.sparkle,
                        label: l10n.restoreAi,
                        onTap: () => context.push('/ai-assistant'),
                      ),
                      _AccountItem(
                        icon: AppIcons.settings,
                        label: l10n.settingsTitle,
                        onTap: () => context.push('/settings'),
                      ),
                      _AccountItem(
                        icon: AppIcons.help,
                        label: l10n.help,
                        onTap: () => context.push('/settings'),
                      ),
                      _AccountItem(
                        icon: AppIcons.logout,
                        label: l10n.logout,
                        onTap: () => context.read<AuthBloc>().add(LoggedOut()),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _IdentityCard extends StatelessWidget {
  const _IdentityCard({required this.user, required this.onEdit});

  final UserModel user;
  final VoidCallback onEdit;

  /// Chữ cái đầu của chữ đầu và chữ cuối họ tên (VD "Nguyễn Minh Anh" → "NA")
  String get _initials {
    final words = user.fullName.trim().split(RegExp(r'\s+'));
    final first = words.first.isEmpty ? user.email : words.first;
    final last = words.length > 1 ? words.last : '';
    return '${first.characters.first}${last.isEmpty ? '' : last.characters.first}'
        .toUpperCase();
  }

  /// Che số điện thoại, giữ 3 số đầu và 4 số cuối (VD "090 ••• 1234")
  static String _maskPhone(String phone) {
    final digits = phone.replaceAll(RegExp(r'\D'), '');
    if (digits.length < 7) return phone;
    return '${digits.substring(0, 3)} ••• ${digits.substring(digits.length - 4)}';
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 32,
            backgroundColor: AppColors.infoBg,
            foregroundImage: user.avatarUrl == null
                ? null
                : NetworkImage(user.avatarUrl!),
            child: Text(
              _initials,
              style: const TextStyle(
                color: Color(0xFF1E3A8A),
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  user.fullName.isEmpty ? user.username : user.fullName,
                  style: const TextStyle(
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                if (user.createdAt case final createdAt?) ...[
                  const SizedBox(height: 3),
                  Text(
                    l10n.memberSince(createdAt.year.toString()),
                    style: const TextStyle(
                      fontSize: 11,
                      color: AppColors.textSecondary,
                    ),
                  ),
                ],
                const SizedBox(height: 3),
                Text(
                  user.phone == null ? user.email : _maskPhone(user.phone!),
                  style: const TextStyle(
                    fontSize: 11,
                    color: AppColors.textSecondary,
                  ),
                ),
                InkWell(
                  onTap: onEdit,
                  child: Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: Text(
                      '${l10n.editProfile}  ›',
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppColors.primaryDark,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  const _MetricCard({
    required this.value,
    required this.label,
    required this.onTap,
  });

  final String value;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(9),
    child: Ink(
      height: 68,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(9),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            value,
            style: const TextStyle(
              fontSize: 20,
              height: 1,
              fontWeight: FontWeight.w700,
              color: AppColors.primaryDark,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 12, height: 1.1),
          ),
        ],
      ),
    ),
  );
}

class _AccountItem extends StatelessWidget {
  const _AccountItem({
    required this.icon,
    required this.label,
    required this.onTap,
    this.trailing,
  });

  final IconData icon;
  final String label;
  final String? trailing;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Ink(
        height: 44,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          children: [
            Icon(icon, size: 21, color: AppColors.textSecondary),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                label,
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
            if (trailing != null)
              Text(
                trailing!,
                style: const TextStyle(
                  fontSize: 11,
                  color: AppColors.primaryDark,
                ),
              ),
            const SizedBox(width: 10),
            const Icon(
              AppIcons.chevronRight,
              size: 19,
              color: AppColors.textSecondary,
            ),
          ],
        ),
      ),
    ),
  );
}
