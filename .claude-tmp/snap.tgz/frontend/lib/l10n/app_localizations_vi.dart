// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Vietnamese (`vi`).
class AppLocalizationsVi extends AppLocalizations {
  AppLocalizationsVi([String locale = 'vi']) : super(locale);

  @override
  String get feedForYou => 'Dành cho bạn';

  @override
  String get feedFollowing => 'Đang theo dõi';

  @override
  String get feedCompose => 'Bạn muốn chia sẻ điều gì?';

  @override
  String get feedFollow => 'Theo dõi';

  @override
  String get feedUnfollow => 'Bỏ theo dõi';

  @override
  String get feedPost => 'Đăng bài';

  @override
  String get feedNewPost => 'Tạo bài cộng đồng';

  @override
  String get feedTextHint => 'Bạn muốn chia sẻ điều gì?';

  @override
  String get feedAddPhoto => 'Thêm ảnh';

  @override
  String get feedTakePhoto => 'Chụp ảnh';

  @override
  String get feedRemovePhoto => 'Bỏ ảnh';

  @override
  String get feedComments => 'Bình luận';

  @override
  String get feedCommentHint => 'Viết bình luận…';

  @override
  String get feedSend => 'Gửi bình luận';

  @override
  String get feedLike => 'Thích';

  @override
  String get feedUnlike => 'Bỏ thích';

  @override
  String get feedEmpty => 'Chưa có bài viết';

  @override
  String get feedFollowingEmpty =>
      'Theo dõi tác giả để xem bài viết của họ tại đây.';

  @override
  String get feedLoadError => 'Không tải được bảng tin.';

  @override
  String get feedActionError =>
      'Không thực hiện được thao tác. Vui lòng thử lại.';

  @override
  String get feedPublishError => 'Không đăng được bài viết. Vui lòng thử lại.';

  @override
  String get feedPhotoError => 'Không chọn được ảnh. Vui lòng thử lại.';

  @override
  String get feedYourName => 'Bạn';

  @override
  String get feedNoComments => 'Hãy là người đầu tiên bình luận.';

  @override
  String get feedNotifications => 'Tính năng thông báo đang được phát triển.';

  @override
  String get feedNow => 'Vừa xong';

  @override
  String feedMinutes(int count) {
    return '$count phút trước';
  }

  @override
  String feedHours(int count) {
    return '$count giờ trước';
  }

  @override
  String feedDays(int count) {
    return '$count ngày trước';
  }

  @override
  String feedLikes(int count) {
    return '$count lượt thích';
  }

  @override
  String feedCommentCount(int count) {
    return '$count bình luận';
  }

  @override
  String get settingsPageTitle => 'Cài đặt';

  @override
  String get settingsLanguage => 'Ngôn ngữ ứng dụng';

  @override
  String get settingsLanguageHint =>
      'Chọn ngôn ngữ giao diện. Bài viết người dùng giữ nguyên ngôn ngữ gốc.';

  @override
  String get settingsLanguageError => 'Không lưu được lựa chọn ngôn ngữ.';

  @override
  String get feedRequired => 'Thêm nội dung hoặc ảnh trước khi đăng.';

  @override
  String get feedDraftLimit => 'Tối đa 2.000 ký tự';

  @override
  String get feedDelete => 'Xóa bài viết';

  @override
  String get feedDeleteConfirm => 'Xóa bài viết này? Không thể hoàn tác.';

  @override
  String get feedDeleted => 'Đã xóa bài viết';

  @override
  String get feedReport => 'Báo cáo bài viết';

  @override
  String get feedReportTitle => 'Vì sao bạn báo cáo bài viết này?';

  @override
  String get feedReportSpam => 'Spam hoặc quảng cáo';

  @override
  String get feedReportScam => 'Lừa đảo';

  @override
  String get feedReportOffensive => 'Nội dung phản cảm';

  @override
  String get feedReportOther => 'Lý do khác';

  @override
  String get feedReported => 'Đã gửi báo cáo. Cảm ơn bạn!';

  @override
  String get feedViewProfile => 'Xem trang cá nhân';

  @override
  String get feedLoadMoreError => 'Không tải thêm được bài viết.';

  @override
  String get feedDiscardTitle => 'Bỏ bài viết?';

  @override
  String get feedDiscardBody => 'Nội dung bạn đã nhập sẽ bị mất.';

  @override
  String get feedDiscard => 'Bỏ';

  @override
  String get feedKeepEditing => 'Tiếp tục viết';

  @override
  String feedCharCount(int count) {
    return '$count/2.000';
  }

  @override
  String get feedCloseImage => 'Đóng ảnh';

  @override
  String get accEditPage => 'Chỉnh sửa trang';

  @override
  String get accMenu => 'Menu và cài đặt';

  @override
  String get accLoadError => 'Không tải được hồ sơ. Bấm để thử lại';

  @override
  String get accLoading => 'Đang tải…';

  @override
  String get accFollowing => 'Đang theo dõi';

  @override
  String get accFollowers => 'Người theo dõi';

  @override
  String get accListings => 'Tin đăng';

  @override
  String get accPosts => 'Bài viết';

  @override
  String get accAddBio => '＋  Thêm giới thiệu';

  @override
  String accRating(String rating, int count) {
    return '$rating ($count đánh giá)';
  }

  @override
  String get accNoRating => 'Chưa có đánh giá';

  @override
  String accTabVisible(int count) {
    return 'ĐANG HIỂN THỊ ($count)';
  }

  @override
  String accTabPending(int count) {
    return 'CHỜ DUYỆT ($count)';
  }

  @override
  String accTabHidden(int count) {
    return 'ĐÃ ẨN ($count)';
  }

  @override
  String get accEmptyVisible => 'Chưa có tin đang hiển thị';

  @override
  String get accEmptyPending => 'Chưa có tin chờ duyệt';

  @override
  String get accEmptyHidden => 'Chưa có tin đã ẩn';

  @override
  String get accPostListing => 'Đăng tin';

  @override
  String accPosted(String time) {
    return 'Đăng $time';
  }

  @override
  String accViews(int count) {
    return '$count lượt xem';
  }

  @override
  String get accHide => 'Ẩn tin';

  @override
  String get accShow => 'Hiện tin';

  @override
  String get accBoost => 'Đẩy tin';

  @override
  String get accLoadListingsError => 'Không tải được tin đăng.';

  @override
  String get accUpdateListingError => 'Không cập nhật được tin đăng.';

  @override
  String get accLogout => 'Đăng xuất';

  @override
  String get accLogoutConfirm => 'Đăng xuất khỏi ReStore?';

  @override
  String get accCloseMenu => 'Đóng menu';

  @override
  String get accEditTitle => 'Chỉnh sửa hồ sơ';

  @override
  String get accDisplayName => 'Tên hiển thị';

  @override
  String get accUsername => 'Tên người dùng';

  @override
  String get accBio => 'Giới thiệu';

  @override
  String get accSave => 'Lưu';

  @override
  String get accChangeAvatar => 'Đổi ảnh';

  @override
  String get accRemoveAvatar => 'Xóa ảnh';

  @override
  String get accNameRequired => 'Nhập tên hiển thị.';

  @override
  String get accUsernameInvalid =>
      '3–30 ký tự: chữ thường, số, dấu chấm hoặc gạch dưới.';

  @override
  String get accUsernameTaken => 'Tên người dùng đã được sử dụng.';

  @override
  String get accSaveError => 'Không lưu được hồ sơ. Vui lòng thử lại.';

  @override
  String get accAvatarUploadError =>
      'Không tải được ảnh lên. Vui lòng thử lại.';

  @override
  String get accUserNotFound => 'Không tìm thấy người dùng.';

  @override
  String get accFollowListEmpty => 'Chưa có ai';

  @override
  String get accComingSoon => 'Tính năng này đang được phát triển';

  @override
  String get accActivity => 'Hoạt động';

  @override
  String get accProPlan => 'Gói tài khoản';

  @override
  String get accCreateStore => 'Tạo cửa hàng';

  @override
  String get accCoins => 'Xu ReStore';

  @override
  String get accSaved => 'Đã lưu hồ sơ';

  @override
  String get accSavedSearches => 'Tìm kiếm đã lưu';

  @override
  String get accRecentlyViewed => 'Xem gần đây';

  @override
  String get accMyReviews => 'Đánh giá từ tôi';

  @override
  String get accTransactions => 'Lịch sử giao dịch';

  @override
  String get accStores => 'Cửa hàng / chuyên trang';

  @override
  String get accHelp => 'Trợ giúp';

  @override
  String get accFeedback => 'Đóng góp ý kiến';

  @override
  String get accEdit => 'Chỉnh sửa';

  @override
  String get accMoreOptions => 'Thêm tùy chọn';

  @override
  String get appName => 'ReStore';

  @override
  String get loginTitle => 'Đăng nhập vào tài khoản';

  @override
  String get email => 'Email';

  @override
  String get password => 'Mật khẩu';

  @override
  String get signIn => 'Đăng nhập';

  @override
  String get orSignInWith => 'Hoặc đăng nhập bằng';

  @override
  String get dontHaveAccount => 'Bạn chưa có tài khoản?';

  @override
  String get signUp => 'Đăng ký';

  @override
  String get successTitle => 'Thành công';

  @override
  String get errorTitle => 'Đã xảy ra lỗi';

  @override
  String get warningTitle => 'Cảnh báo';

  @override
  String get infoTitle => 'Thông tin';

  @override
  String get deviceNotSupported => 'Thiết bị không được hỗ trợ';

  @override
  String get deviceNotSupportedDesc =>
      'Ứng dụng ReStore hiện tại chỉ được thiết kế và tối ưu cho trải nghiệm trên màn hình điện thoại di động cầm tay.';

  @override
  String get loginSuccessMsg => 'Đăng nhập vào hệ thống thành công.';

  @override
  String get loginErrorMsg => 'Sai tài khoản hoặc mật khẩu.';

  @override
  String get verifyOtpTitle => 'Xác minh OTP';

  @override
  String get checkYourEmail => 'Kiểm tra email của bạn';

  @override
  String otpSentToEmail(String email) {
    return 'Mã OTP đã được gửi đến $email. Nhập 6 chữ số để tiếp tục.';
  }

  @override
  String otpValidFor(String time) {
    return 'Có thể gửi lại mã sau $time';
  }

  @override
  String get verifyEmailTitle => 'Xác minh email';

  @override
  String get enterVerificationCode => 'Nhập mã xác minh';

  @override
  String get verifyOtpButton => 'Xác minh OTP';

  @override
  String get verifyEmailButton => 'Xác minh email';

  @override
  String get resendOtp => 'Chưa nhận được mã? Gửi lại OTP';

  @override
  String get otpExpireInfo => 'Mã chỉ dùng một lần và hết hạn sau 5 phút.';

  @override
  String get emailVerifyInfo =>
      'Bạn có thể tiếp tục xem tin sau khi xác minh email.';

  @override
  String get invalidOtpError => 'Mã OTP không đúng. Kiểm tra và thử lại.';

  @override
  String get accountTitle => 'Tài khoản';

  @override
  String get settingsTitle => 'Cài đặt';

  @override
  String memberSince(String year) {
    return 'Thành viên từ $year';
  }

  @override
  String get editProfile => 'Chỉnh sửa hồ sơ';

  @override
  String get activeListings => 'Tin đang đăng';

  @override
  String get soldListings => 'Tin đã bán';

  @override
  String get myAccount => 'Tài khoản của tôi';

  @override
  String get savedListings => 'Tin đã lưu';

  @override
  String get reviews => 'Đánh giá';

  @override
  String get notifications => 'Thông báo';

  @override
  String get addressArea => 'Địa chỉ / Khu vực';

  @override
  String get restoreAi => 'ReStore AI';

  @override
  String get help => 'Trợ giúp';

  @override
  String get logout => 'Đăng xuất';

  @override
  String newCount(int count) {
    return '$count mới';
  }

  @override
  String get editProfileTitle => 'Chỉnh sửa hồ sơ';

  @override
  String get changeAvatar => 'Đổi ảnh đại diện';

  @override
  String get fullName => 'Họ và tên';

  @override
  String get phoneNumber => 'Số điện thoại';

  @override
  String get birthday => 'Ngày sinh';

  @override
  String get gender => 'Giới tính';

  @override
  String get male => 'Nam';

  @override
  String get female => 'Nữ';

  @override
  String get other => 'Khác';

  @override
  String get district1Hcm => 'Quận 1, TP. Hồ Chí Minh';

  @override
  String get thuDucHcm => 'Thủ Đức, TP. Hồ Chí Minh';

  @override
  String get district3Hcm => 'Quận 3, TP. Hồ Chí Minh';

  @override
  String get saveChanges => 'Lưu thay đổi';

  @override
  String get options => 'Tùy chọn';

  @override
  String get receiveNotifications => 'Nhận thông báo';

  @override
  String get privacy => 'Quyền riêng tư';

  @override
  String get changePassword => 'Đổi mật khẩu';

  @override
  String get helpSupport => 'Trợ giúp / Hỗ trợ';

  @override
  String get termsPolicies => 'Điều khoản & chính sách';

  @override
  String savedCount(int count) {
    return '$count tin đã lưu';
  }

  @override
  String get tapHeartToRemove => 'Chạm ♡ để bỏ lưu';

  @override
  String get emptySavedTitle => 'Chưa có tin đã lưu';

  @override
  String get emptySavedDescription =>
      'Lưu tin bạn quan tâm để xem lại nhanh hơn.';

  @override
  String get exploreProducts => 'Khám phá sản phẩm';

  @override
  String get today => 'Hôm nay';

  @override
  String get yesterday => 'Hôm qua';

  @override
  String get earlier => 'Trước đó';

  @override
  String get newMessage => 'Tin nhắn mới';

  @override
  String get newMessageDescription =>
      'Minh Anh vừa gửi thêm ảnh máy Canon AE-1.';

  @override
  String get newOffer => 'Đề nghị giá mới';

  @override
  String get newOfferDescription =>
      'Có đề nghị 2.200.000 đ cho tin Canon AE-1.';

  @override
  String get offerResponse => 'Phản hồi đề nghị';

  @override
  String get offerResponseDescription =>
      'Minh Anh đề nghị mức giá khác: 2.300.000 đ.';

  @override
  String get listingApproved => 'Tin đăng đã được duyệt';

  @override
  String get listingApprovedDescription =>
      'Tin Đèn bàn đồng vintage đang hiển thị.';

  @override
  String get listingNeedsEdit => 'Tin cần chỉnh sửa';

  @override
  String get listingNeedsEditDescription =>
      'Vui lòng bổ sung ảnh cho tin Ghế gỗ sồi.';

  @override
  String get listingSavedNotification => 'Tin của bạn được lưu';

  @override
  String get listingSavedDescription =>
      '3 người đã lưu tin Canon AE-1 của bạn.';

  @override
  String get sellerTitle => 'Người bán';

  @override
  String get sellerName => 'Minh Anh';

  @override
  String get sellerArea => 'Quận 1, TP. Hồ Chí Minh';

  @override
  String get sellerMemberSince => 'Thành viên từ 2022';

  @override
  String get ratingValue => '★ 4,9';

  @override
  String ratingCount(int count) {
    return '$count đánh giá';
  }

  @override
  String get sellingListings => 'Tin đang bán';

  @override
  String get chat => 'Chat';

  @override
  String get viewListings => 'Xem tin đăng';

  @override
  String listingCountShort(int count) {
    return '$count tin ›';
  }

  @override
  String get reportSeller => 'Báo cáo người bán';

  @override
  String get sellerRatingsTitle => 'Đánh giá người bán';

  @override
  String get communityReviews => 'Nhận xét từ cộng đồng';

  @override
  String reviewCount(int count) {
    return '$count nhận xét';
  }

  @override
  String get writeReview => 'Viết đánh giá';

  @override
  String get leaveReviewTitle => 'Viết đánh giá';

  @override
  String get sellerRoleArea => 'Người bán · Quận 1, TP.HCM';

  @override
  String get reviewQuestion => 'Bạn đánh giá người bán thế nào?';

  @override
  String starSelection(int count, String label) {
    return '$count sao · $label';
  }

  @override
  String get veryGood => 'Rất tốt';

  @override
  String get selected => 'Đã chọn';

  @override
  String get optionalReview => 'Nhận xét (không bắt buộc)';

  @override
  String get reviewHint => 'Chia sẻ trải nghiệm trao đổi của bạn...';

  @override
  String get reviewGuidance =>
      'Đánh giá giúp cộng đồng hiểu về người bán. Hãy chia sẻ trải nghiệm trao đổi của bạn.';

  @override
  String get submitReview => 'Gửi đánh giá';

  @override
  String get reportListing => 'Báo cáo tin đăng';

  @override
  String get reportUser => 'Báo cáo người dùng';

  @override
  String get report => 'Báo cáo';

  @override
  String get reportReason => 'Lý do báo cáo';

  @override
  String get inappropriateContent => 'Nội dung không phù hợp';

  @override
  String get suspectedFraud => 'Có dấu hiệu lừa đảo';

  @override
  String get prohibitedProduct => 'Sản phẩm bị cấm';

  @override
  String get misleadingInformation => 'Thông tin sai lệch';

  @override
  String get spam => 'Spam';

  @override
  String get otherReason => 'Lý do khác';

  @override
  String get optionalDescription => 'Mô tả thêm (không bắt buộc)';

  @override
  String get reportDescriptionHint => 'Thêm thông tin để chúng tôi kiểm tra...';

  @override
  String get submitReport => 'Gửi báo cáo';

  @override
  String get reportSuccessTitle => 'Đã gửi báo cáo';

  @override
  String get reportSuccessDescription =>
      'Cảm ơn bạn đã giúp ReStore an toàn hơn. Đội ngũ kiểm duyệt sẽ xem xét nội dung này.';

  @override
  String get goBack => 'Quay lại';

  @override
  String get reportedListingTitle => 'Máy ảnh Canon AE-1 + lens 50mm';

  @override
  String get reportedListingMeta => 'Tin đăng của Minh Anh · Quận 1';

  @override
  String get aiSampleCameraQuery => 'Tìm máy ảnh film dưới 4 triệu';

  @override
  String get aiSampleGamingQuery => 'Tìm laptop gaming dưới 15 triệu';

  @override
  String get aiSampleIphoneQuery => 'Tìm iPhone cũ dưới 10 triệu';

  @override
  String get aiSampleStudentLaptopQuery => 'Tìm laptop cho sinh viên';

  @override
  String get aiStartOver => 'Bắt đầu lại';

  @override
  String get aiEmptyStateMenu => 'Xem empty state';

  @override
  String get aiErrorStateMenu => 'Xem error state';

  @override
  String get aiInputHint => 'Hỏi về sản phẩm, giá, khu vực...';

  @override
  String get askRestoreAi => 'Hỏi ReStore AI';

  @override
  String get aiIntro =>
      'Mô tả món đồ bạn cần. AI sẽ tìm và so sánh các tin đăng phù hợp trên ReStore.';

  @override
  String get quickPrompts => 'Thử hỏi nhanh';

  @override
  String get sellerOwnsListings => 'Tin đăng là của người bán';

  @override
  String get sellerOwnsListingsDescription =>
      'Xem chi tiết tin và trao đổi trực tiếp với người bán khi bạn quan tâm.';

  @override
  String get continueConversation => 'Bạn có thể hỏi tiếp trong cùng hội thoại';

  @override
  String get continueConversationTips =>
      '• Giới hạn giá và khu vực\n• Chọn thương hiệu hoặc tình trạng\n• So sánh thông tin giữa các tin đăng';

  @override
  String get aiDefaultQuery => 'Tìm máy ảnh film dưới 4 triệu ở TP.HCM';

  @override
  String get aiResultsMessage =>
      'Mình tìm thấy 2 tin máy ảnh film phù hợp. Bạn có thể mở từng tin để xem thêm.';

  @override
  String get aiFilteredMessage =>
      'Mình đã cập nhật kết quả theo yêu cầu mới của bạn.';

  @override
  String get matchingListingsDemo => 'TIN ĐĂNG PHÙ HỢP · DỮ LIỆU MINH HỌA';

  @override
  String get canonListingTitle => 'Canon AE-1 + lens 50mm';

  @override
  String get canonPrice => '2.450.000 đ';

  @override
  String get canonLocationTime => 'Quận 1 · 2 giờ trước';

  @override
  String get nikonListingTitle => 'Máy ảnh Nikon FM2';

  @override
  String get nikonPrice => '3.800.000 đ';

  @override
  String get nikonLocationTime => 'Quận 10 · Hôm qua';

  @override
  String get sellerDataCaveat =>
      'Giá và tình trạng theo nội dung người bán cung cấp.';

  @override
  String get youCanAskNext => 'Bạn có thể hỏi tiếp:';

  @override
  String get canonOnly => 'Chỉ Canon thôi';

  @override
  String get compareTheseTwo => 'So sánh 2 máy này';

  @override
  String get comparisonMessage =>
      'Mình so sánh theo thông tin có trong hai tin đăng ReStore.';

  @override
  String get canonVsNikon => 'Canon AE-1 và Nikon FM2';

  @override
  String get listing => 'Tin đăng';

  @override
  String get price => 'Giá';

  @override
  String get condition => 'Tình trạng';

  @override
  String get area => 'Khu vực';

  @override
  String get posted => 'Đăng tin';

  @override
  String get goodCondition => 'Còn tốt';

  @override
  String get notSpecified => 'Chưa nêu';

  @override
  String get twoHoursAgo => '2 giờ trước';

  @override
  String get sellerInfoOnly => 'Chỉ dựa trên thông tin người bán đã cung cấp.';

  @override
  String get viewCanon => 'Xem Canon →';

  @override
  String get viewNikon => 'Xem Nikon →';

  @override
  String get aiEmptyTitle => 'Không tìm thấy tin phù hợp';

  @override
  String get aiEmptyDescription =>
      'Thử mở rộng khu vực, tăng khoảng giá hoặc mô tả sản phẩm ngắn gọn hơn.';

  @override
  String get adjustRequest => 'Điều chỉnh yêu cầu';

  @override
  String get aiErrorTitle => 'Chưa thể trả lời lúc này';

  @override
  String get aiErrorDescription =>
      'Nội dung cuộc trò chuyện vẫn được giữ. Bạn có thể thử lại mà không cần nhập lại từ đầu.';

  @override
  String get retry => 'Thử lại';

  @override
  String featureApiPending(String action) {
    return '$action sẽ được kết nối ở bước API.';
  }

  @override
  String get createListing => 'Đăng tin';

  @override
  String get editListing => 'Chỉnh sửa tin';

  @override
  String get close => 'Đóng';

  @override
  String get back => 'Quay lại';

  @override
  String stepCount(int current, int total) {
    return '$current/$total';
  }

  @override
  String productPhotosCount(int count) {
    return 'Ảnh sản phẩm · $count/10';
  }

  @override
  String get addPhotos => 'Thêm ảnh';

  @override
  String get firstPhotoHint => 'Ảnh đầu là ảnh bìa · Giữ và kéo để đổi thứ tự';

  @override
  String get productName => 'Tên sản phẩm';

  @override
  String get category => 'Danh mục';

  @override
  String get electronicsCamera => 'Điện tử › Máy ảnh';

  @override
  String get newCondition => 'Mới';

  @override
  String get usedCondition => 'Đã qua sử dụng';

  @override
  String get photoTip =>
      'Mẹo: ảnh rõ, nhiều góc chụp giúp tin đăng đáng tin hơn.';

  @override
  String get salePrice => 'Giá bán';

  @override
  String get priceVndHint => 'Nhập giá bằng VND';

  @override
  String get negotiable => 'Có thể thương lượng';

  @override
  String get description => 'Mô tả';

  @override
  String get location => 'Địa điểm';

  @override
  String get contactPreference => 'Ưu tiên liên hệ';

  @override
  String get phone => 'Điện thoại';

  @override
  String get directArrangementNote =>
      'Người mua và người bán tự thỏa thuận giao nhận, thanh toán.';

  @override
  String get continueAction => 'Tiếp tục';

  @override
  String get preview => 'Xem trước';

  @override
  String get publishListing => 'Đăng tin';

  @override
  String get boostListing => 'Đẩy tin';

  @override
  String get boostVisibilityTitle => 'Tăng khả năng hiển thị';

  @override
  String get boostVisibilityDescription =>
      'Tin đăng của bạn được ưu tiên hiển thị trong thời gian đã chọn. Không đảm bảo lượt xem hoặc bán được.';

  @override
  String get selectBoostDuration => 'Chọn thời gian đẩy tin';

  @override
  String get boost24Hours => 'Đẩy tin 24 giờ';

  @override
  String get boost3Days => 'Đẩy tin 3 ngày';

  @override
  String get boost7Days => 'Đẩy tin 7 ngày';

  @override
  String get visible24Hours => 'Hiển thị nổi bật trong 24 giờ';

  @override
  String get visible3Days => 'Duy trì hiển thị nổi bật 3 ngày';

  @override
  String get visible7Days => 'Duy trì hiển thị nổi bật 7 ngày';

  @override
  String get boostPrice24 => '19.000 đ';

  @override
  String get boostPrice3Days => '49.000 đ';

  @override
  String get boostPrice7Days => '99.000 đ';

  @override
  String get boostDemoPriceNote =>
      'Giá dịch vụ minh họa · bảng giá chính thức sẽ được xác nhận sau.';

  @override
  String get confirmPromotionService => 'Xác nhận dịch vụ quảng bá';

  @override
  String get currentListing => 'Tin của bạn';

  @override
  String get listingVisibilityStatus => 'Đang hiển thị · Tin của bạn';

  @override
  String get boostPackage => 'Gói đẩy tin';

  @override
  String get duration => 'Thời lượng';

  @override
  String get serviceFee => 'Phí dịch vụ';

  @override
  String get totalServiceFee => 'Tổng phí dịch vụ';

  @override
  String get threeDays => '3 ngày';

  @override
  String get seventyTwoHours => '72 giờ';

  @override
  String get restoreServiceFee => 'Phí dịch vụ ReStore';

  @override
  String get boostServiceBoundary =>
      'Bạn đang trả phí để quảng bá tin đăng, không thanh toán cho sản phẩm. ReStore không xử lý thanh toán mua bán.';

  @override
  String get continuePayment => 'Tiếp tục thanh toán';

  @override
  String get servicePayment => 'Thanh toán dịch vụ';

  @override
  String get vnpay => 'VNPay';

  @override
  String get vnpayDescription => 'Thanh toán phí quảng bá tin đăng qua VNPay';

  @override
  String get confirmPayment => 'Xác nhận thanh toán';

  @override
  String get paymentResult => 'Kết quả thanh toán';

  @override
  String get paymentSuccess => 'Thanh toán thành công';

  @override
  String get boostActivatedDescription => 'Tin của bạn đã được đẩy thành công';

  @override
  String get transactionDetails => 'Chi tiết giao dịch';

  @override
  String get transactionCode => 'Mã giao dịch';

  @override
  String get transactionCodeValue => 'RST-BST-260925-0842';

  @override
  String get amount => 'Số tiền';

  @override
  String get boostPeriod => 'Thời hạn đẩy tin';

  @override
  String get paymentMethod => 'Phương thức';

  @override
  String get viewListing => 'Xem tin';

  @override
  String get backToManageListings => 'Về trang quản lý tin';

  @override
  String get activeBoost => 'Đẩy tin đang hoạt động';

  @override
  String get activeBoostDescription =>
      'Tin này đang được ưu tiên hiển thị cho đến khi hết thời hạn.';

  @override
  String get expiredBoost => 'Đẩy tin đã hết hạn';

  @override
  String get expiredBoostDescription =>
      'Thời gian quảng bá đã kết thúc. Tin đăng vẫn tiếp tục hiển thị.';

  @override
  String get boostUnavailable => 'Không thể đẩy tin';

  @override
  String get boostUnavailableDescription =>
      'Chỉ tin đang hoạt động và đã được duyệt mới có thể đẩy.';

  @override
  String get boostAgain => 'Đẩy tin lại';

  @override
  String get boostPaymentFailed => 'Thanh toán không thành công';

  @override
  String get boostPaymentCancelled => 'Đã hủy thanh toán';

  @override
  String get boostPaymentPending => 'Đang xác nhận phí dịch vụ';

  @override
  String get tryPaymentAgain => 'Thử thanh toán lại';

  @override
  String get manageListings => 'Quản lý tin';

  @override
  String get feedsTitle => 'Bảng tin';

  @override
  String get feedsComingSoon => 'Bảng tin đang được phát triển';

  @override
  String get newListing => 'Đăng tin mới';

  @override
  String get visibleStatus => 'Đang hiển thị';

  @override
  String get pendingStatus => 'Chờ duyệt';

  @override
  String get hiddenStatus => 'Đã ẩn';

  @override
  String get soldStatus => 'Đã bán';

  @override
  String listingStatusCount(int count, String status) {
    return '$count $status';
  }

  @override
  String get editAction => 'Chỉnh sửa';

  @override
  String get hideListing => 'Ẩn tin';

  @override
  String get markAsSold => 'Đánh dấu đã bán';

  @override
  String get deleteListing => 'Xóa tin';

  @override
  String get showAgain => 'Hiện lại';

  @override
  String get pendingStatusNote => 'Tin đang được kiểm tra trước khi hiển thị.';

  @override
  String get hiddenStatusNote =>
      'Tin đang ẩn, người mua không thấy trong kết quả tìm kiếm.';

  @override
  String get soldStatusNote =>
      'Tin đã bán không còn hiển thị trong kết quả tìm kiếm.';

  @override
  String get markSoldTitle => 'Đánh dấu tin đã bán?';

  @override
  String get markSoldDescription => 'Tin sẽ không còn khả dụng với người mua.';

  @override
  String get platformNoOrderPayment =>
      'Thao tác này không tạo đơn hàng hay giao dịch. ReStore không xử lý thanh toán.';

  @override
  String get cancel => 'Hủy';

  @override
  String get homeTitle => 'Trang chủ';

  @override
  String get messagesTitle => 'Tin nhắn';

  @override
  String get listingDetailTitle => 'Chi tiết tin đăng';

  @override
  String get listingPreviewTitle => 'Xem trước tin đăng';

  @override
  String galleryPosition(int current, int total) {
    return '$current / $total';
  }

  @override
  String get listingLocationMeta =>
      '⌖ Quận 1, TP. Hồ Chí Minh · Đăng 2 giờ trước';

  @override
  String get usedGoodCondition => 'Đã qua sử dụng · Còn tốt';

  @override
  String get productDescription => 'Mô tả sản phẩm';

  @override
  String get canonDescription =>
      'Canon AE-1 hoạt động tốt, đo sáng chuẩn. Kèm lens FD 50mm f/1.8, dây đeo và bao da. Có thể xem máy trực tiếp tại Quận 1.';

  @override
  String get sellerRatingMeta => '★ 4,9 · 48 đánh giá · Phản hồi nhanh';

  @override
  String get similarListings => 'Tin tương tự';

  @override
  String get seeMore => 'Xem thêm ›';

  @override
  String get makeOffer => 'Trả giá';

  @override
  String get chooseCategoryTitle => 'Chọn danh mục';

  @override
  String get chooseCategorySubtitle => 'Bạn muốn đăng bán món đồ gì?';

  @override
  String get categoryElectronicsTitle => 'Đồ điện tử';

  @override
  String get categoryElectronicsDesc => 'Laptop, Máy ảnh, Tai nghe,...';

  @override
  String get categoryVehiclesTitle => 'Xe cộ';

  @override
  String get categoryVehiclesDesc => 'Xe máy, Xe đạp, Ô tô, Phụ tùng,...';

  @override
  String get categoryFashionTitle => 'Thời trang';

  @override
  String get categoryFashionDesc => 'Quần áo, Giày dép, Túi xách,...';

  @override
  String get categoryHomeTitle => 'Gia dụng';

  @override
  String get categoryHomeDesc => 'Nội thất, Đèn, Đồ bếp, Trang trí,...';

  @override
  String get step1Title => 'Ảnh & Sản phẩm';

  @override
  String productPhotosInfo(int count) {
    return 'Ảnh sản phẩm · $count/10';
  }

  @override
  String get coverImageHint =>
      'Ảnh đầu là ảnh bìa · Chạm vào ảnh để đặt làm bìa';

  @override
  String get productNameLabel => 'Tên sản phẩm';

  @override
  String get productNameMinLengthError => 'Tên sản phẩm tối thiểu 5 ký tự';

  @override
  String get categoryLabel => 'Danh mục';

  @override
  String get conditionLabel => 'Tình trạng';

  @override
  String get continueBtn => 'Tiếp tục';

  @override
  String get completeListingTitle => 'Hoàn thiện tin đăng';

  @override
  String get saveDraft => 'Lưu nháp';

  @override
  String get draftSaved => 'Đã lưu nháp';

  @override
  String listingPhotosLabel(int max) {
    return 'Hình ảnh (Tối đa $max ảnh)';
  }

  @override
  String photoCount(int count, int max) {
    return '$count/$max';
  }

  @override
  String get coverPhotoBadge => 'Bìa';

  @override
  String get photosRequiredError => 'Vui lòng thêm ít nhất 1 ảnh';

  @override
  String get detailedDescriptionLabel => 'Mô tả chi tiết';

  @override
  String get listingDescriptionHint =>
      '- Tình trạng, thời gian đã sử dụng\n- Phụ kiện đi kèm, lỗi nhỏ nếu có\n- Lý do bán, hình thức giao nhận';

  @override
  String characterCount(int count, int max) {
    return '$count/$max ký tự';
  }

  @override
  String descriptionMinLengthError(int min) {
    return 'Mô tả cần ít nhất $min ký tự';
  }

  @override
  String get listingTitleLabel => 'Tiêu đề tin đăng';

  @override
  String get listingTitleHint => 'VD: Piaggio Vespa Sprint 2024 15.000 km';

  @override
  String listingTitleMinLengthError(int min) {
    return 'Tiêu đề cần ít nhất $min ký tự';
  }

  @override
  String get priceRequiredError => 'Vui lòng nhập giá bán';

  @override
  String get addressLabel => 'Địa chỉ';

  @override
  String get youAreLabel => 'Bạn là';

  @override
  String get sellerPersonal => 'Cá nhân';

  @override
  String get sellerBusiness => 'Bán chuyên';

  @override
  String get detailedInfoTitle => 'Thông tin chi tiết';

  @override
  String categoryWithName(String name) {
    return 'Danh mục: $name';
  }

  @override
  String get fieldRequiredError => 'Vui lòng nhập thông tin này';

  @override
  String get fieldSelectRequiredError => 'Vui lòng chọn một giá trị';

  @override
  String get missingRequiredFields =>
      'Vui lòng điền đầy đủ các thông tin bắt buộc';

  @override
  String get listingSubmitted =>
      'Tin đăng của bạn đã được gửi và đang chờ duyệt';

  @override
  String get previewNotice => 'Đây là cách người mua sẽ thấy tin đăng của bạn';

  @override
  String get noPhotosYet => 'Chưa có ảnh';

  @override
  String get stepBasicInfoTitle => 'Ảnh, mô tả & giá bán';

  @override
  String get takePhoto => 'Chụp ảnh';

  @override
  String get chooseFromGallery => 'Chọn từ thư viện';

  @override
  String photoLimitReached(int max) {
    return 'Bạn chỉ có thể thêm tối đa $max ảnh';
  }

  @override
  String get photoPickFailed =>
      'Không thể mở ảnh. Vui lòng kiểm tra quyền truy cập ảnh và camera của ứng dụng.';

  @override
  String get draftSaveFailed => 'Lưu nháp thất bại, vui lòng thử lại';

  @override
  String get publishFailed => 'Đăng tin thất bại, vui lòng thử lại';

  @override
  String get tradeTypeLabel => 'Hình thức';

  @override
  String get tradeSell => 'Bán';

  @override
  String get tradeExchange => 'Trao đổi';

  @override
  String get tradeSellOrExchange => 'Cả hai';

  @override
  String get tradeExchangeAccepted => 'Nhận trao đổi';

  @override
  String get exchangeWishLabel => 'Muốn đổi lấy';

  @override
  String get exchangeWishHint => 'VD: iPhone 13 hoặc máy tính bảng';

  @override
  String get selectAddressHint => 'Chọn khu vực';

  @override
  String get stepShortCategory => 'Danh mục';

  @override
  String get stepShortBasicInfo => 'Thông tin';

  @override
  String get stepShortDetails => 'Chi tiết';

  @override
  String stepProgressLabel(int current, int total) {
    return 'Bước $current/$total';
  }

  @override
  String nextStepLabel(String name) {
    return 'Tiếp theo: $name';
  }

  @override
  String get conditionSectionTitle => 'Tình trạng sản phẩm';

  @override
  String get conditionNew => 'Mới';

  @override
  String get conditionLikeNew => 'Như mới';

  @override
  String get conditionUsedGood => 'Đã dùng - còn tốt';

  @override
  String get conditionUsedFair => 'Đã dùng - có hao mòn';

  @override
  String get conditionForParts => 'Hỏng / bán lấy linh kiện';

  @override
  String get conditionNewDesc => 'Chưa qua sử dụng, còn nguyên tem hộp';

  @override
  String get conditionLikeNewDesc => 'Dùng rất ít, không trầy xước';

  @override
  String get conditionUsedGoodDesc => 'Hoạt động tốt, có vài vết sử dụng nhỏ';

  @override
  String get conditionUsedFairDesc =>
      'Vẫn dùng được, có trầy xước hoặc lỗi nhỏ';

  @override
  String get conditionForPartsDesc => 'Không còn hoạt động bình thường';

  @override
  String get categoryAttributesTitle => 'Thông tin theo danh mục';

  @override
  String get categoryAttributesHint =>
      'Các trường bên dưới thay đổi theo danh mục';

  @override
  String get selectOptionHint => 'Chọn';

  @override
  String numberRangeError(String min, String max) {
    return 'Giá trị phải từ $min đến $max';
  }

  @override
  String get yes => 'Có';

  @override
  String get no => 'Không';

  @override
  String get loadCategoriesFailedTitle => 'Không tải được danh mục';

  @override
  String get loadCategoriesFailedMessage => 'Kiểm tra kết nối mạng rồi thử lại';

  @override
  String get negotiableHint => 'Người mua có thể trả giá khi nhắn tin';

  @override
  String get addressNearbyHint => 'Giúp người mua gần bạn tìm thấy tin';

  @override
  String privateStreetAddress(String street) {
    return '$street (không công khai)';
  }

  @override
  String get addressSheetTitle => 'Địa chỉ của món đồ';

  @override
  String get useCurrentLocation => 'Dùng vị trí hiện tại';

  @override
  String get useCurrentLocationHint => 'Tự điền tỉnh/thành và phường/xã';

  @override
  String get locatingLabel => 'Đang lấy vị trí...';

  @override
  String get locationDetected => 'Đã lấy vị trí của bạn';

  @override
  String get orChooseManually => 'hoặc chọn thủ công';

  @override
  String get provinceLabel => 'Tỉnh/Thành phố';

  @override
  String get selectProvinceHint => 'Chọn tỉnh/thành phố';

  @override
  String get wardLabel => 'Phường/Xã';

  @override
  String get selectWardHint => 'Chọn phường/xã';

  @override
  String get selectProvinceFirst => 'Chọn tỉnh/thành phố trước';

  @override
  String get streetAddressLabel => 'Số nhà, tên đường';

  @override
  String get streetAddressHint => 'VD: 12 Nguyễn Huệ';

  @override
  String get streetAddressHelper => 'Không bắt buộc, không hiển thị công khai';

  @override
  String get streetSuggestionsTitle => 'Gợi ý địa chỉ';

  @override
  String get addressPrivacyNote =>
      'Người mua chỉ thấy phường/xã và tỉnh/thành. Vị trí được dùng để gợi ý tin đăng gần bạn.';

  @override
  String get confirmAddress => 'Xác nhận địa chỉ';

  @override
  String get loadingLocations => 'Đang tải danh sách...';

  @override
  String get loadLocationsFailed => 'Không tải được danh sách, chạm để thử lại';

  @override
  String get locationServiceDisabled => 'Hãy bật định vị (GPS) để lấy vị trí';

  @override
  String get locationPermissionDenied => 'Bạn chưa cho phép truy cập vị trí';

  @override
  String get locationPermissionDeniedForever =>
      'Quyền vị trí đã bị chặn, hãy bật lại trong Cài đặt';

  @override
  String get locationUnavailable => 'Không lấy được vị trí, hãy chọn thủ công';

  @override
  String get locationOutOfCoverage =>
      'Vị trí của bạn chưa khớp với phường/xã nào. Bạn chọn thủ công ở bên dưới nhé.';

  @override
  String get searchOptionHint => 'Tìm kiếm (gõ không dấu cũng được)';

  @override
  String get noMatchingOptions => 'Không có kết quả phù hợp';

  @override
  String get locationOutsideVietnamTitle => 'Bạn đang ở ngoài Việt Nam?';

  @override
  String get locationOutsideVietnamBody =>
      'ReStore hiện chỉ hỗ trợ địa chỉ tại Việt Nam. Bạn chọn tỉnh/thành và phường/xã ở bên dưới nhé.';

  @override
  String get locationOutOfCoverageTitle => 'Chưa nhận ra khu vực này';

  @override
  String get aiBubbleTooltip => 'Chat với ReStore AI';

  @override
  String unreadMessagesCount(int count) {
    return '$count tin nhắn chưa đọc';
  }

  @override
  String get homeGreeting => 'Chào bạn 👋';

  @override
  String get homeHeadline => 'Hôm nay bạn muốn săn gì?';

  @override
  String get homeSearchHint => 'Tìm đồ cũ, đồ trao đổi...';

  @override
  String get homeChangeArea => 'Đổi khu vực';

  @override
  String get homeAreaLocating => 'Đang định vị...';

  @override
  String get homeForYouTitle => 'Dành cho bạn';

  @override
  String get homeLatestTitle => 'Tin đăng mới';

  @override
  String get homeSeeAll => 'Xem tất cả';

  @override
  String get homeFeaturedTag => 'Hot';

  @override
  String get homeExchangeTag => 'Đổi được';

  @override
  String get homeExchangeOnly => 'Chỉ trao đổi';

  @override
  String get homeSaveListing => 'Lưu tin';

  @override
  String get homeUnsaveListing => 'Bỏ lưu tin';

  @override
  String get homeLoadErrorTitle => 'Chưa tải được trang chủ';

  @override
  String get homeLoadErrorBody => 'Kiểm tra kết nối mạng rồi thử lại nhé.';

  @override
  String get timeJustNow => 'Vừa xong';

  @override
  String timeMinutesAgo(int count) {
    return '$count phút trước';
  }

  @override
  String timeHoursAgo(int count) {
    return '$count giờ trước';
  }

  @override
  String timeDaysAgo(int count) {
    return '$count ngày trước';
  }

  @override
  String get featureComingSoon => 'Tính năng này đang được phát triển';

  @override
  String homeGreetingName(String name) {
    return 'Chào $name 👋';
  }

  @override
  String get homeLatestEmpty => 'Chưa có tin nào ở mục này';

  @override
  String get homeEndOfList => 'Bạn đã xem hết tin rồi';

  @override
  String get homeQuickNearby => 'Gần bạn';

  @override
  String get homeQuickNearbyDesc => 'Quanh đây trong 5 km';

  @override
  String get homeQuickWanted => 'Báo khi có hàng';

  @override
  String get homeQuickWantedDesc => 'Đặt trước món bạn cần';

  @override
  String get homeQuickTrustedShops => 'Shop uy tín';

  @override
  String get homeQuickTrustedShopsDesc => 'Đã xác minh, đánh giá tốt';

  @override
  String get homeQuickFollowing => 'Đang theo dõi';

  @override
  String get homeQuickFollowingDesc => 'Shop và người bạn theo dõi';

  @override
  String get homeBannerTooltip => 'Banner khuyến mãi';

  @override
  String get productDetailTitle => 'Chi tiết sản phẩm';

  @override
  String get productLoadErrorTitle => 'Không tải được tin đăng';

  @override
  String get productLoadErrorBody =>
      'Tin có thể đã bị gỡ hoặc kết nối mạng chưa ổn định. Vui lòng thử lại.';

  @override
  String productViewCount(int count) {
    return '$count lượt xem';
  }

  @override
  String get productUnavailableHint => 'Sản phẩm này hiện không thể đặt mua.';

  @override
  String get listingStatusDraft => 'Bản nháp';

  @override
  String get listingStatusPending => 'Đang chờ duyệt';

  @override
  String get listingStatusAvailable => 'Đang bán';

  @override
  String get listingStatusReserved => 'Đã có người đặt';

  @override
  String get listingStatusSold => 'Đã bán';

  @override
  String get listingStatusExchanged => 'Đã trao đổi';

  @override
  String get listingStatusExpired => 'Đã hết hạn';

  @override
  String get listingStatusRejected => 'Bị từ chối';

  @override
  String get listingStatusHidden => 'Đã ẩn';

  @override
  String get productSellerTitle => 'Người bán';

  @override
  String get productSellerVerified => 'Đã xác minh';

  @override
  String get productSellerNoReviews => 'Chưa có đánh giá';

  @override
  String productSellerJoined(String date) {
    return 'Tham gia $date';
  }

  @override
  String productSellerListings(int count) {
    return '$count tin đang bán';
  }

  @override
  String get productSellerProfile => 'Xem trang';

  @override
  String get productReadMore => 'Xem thêm';

  @override
  String get productReadLess => 'Thu gọn';

  @override
  String get productSafetyTitle => 'Mua bán an toàn';

  @override
  String get productSafetyBody =>
      'Hẹn gặp ở nơi công cộng, kiểm tra hàng trước khi trả tiền và không chuyển tiền đặt cọc cho người lạ.';

  @override
  String get productReport => 'Báo cáo tin';

  @override
  String get productChat => 'Nhắn tin';

  @override
  String get productMakeOffer => 'Trả giá';

  @override
  String get productBuyNow => 'Mua ngay';

  @override
  String get productProposeExchange => 'Đề nghị đổi';

  @override
  String get productEditListing => 'Sửa tin';

  @override
  String get productBoost => 'Đẩy tin';

  @override
  String get productOfferTitle => 'Trả giá với người bán';

  @override
  String productOfferSubtitle(String price) {
    return 'Giá đang bán: $price';
  }

  @override
  String get productOfferAmountLabel => 'Giá bạn đề nghị';

  @override
  String get productOfferAmountHint => 'Nhập số tiền';

  @override
  String get productOfferInvalid => 'Nhập số tiền lớn hơn 0';

  @override
  String get productOfferTooHigh =>
      'Giá đề nghị không được vượt quá 2 lần giá đang bán';

  @override
  String get productOfferSubmit => 'Gửi đề nghị';

  @override
  String get productOfferSent =>
      'Đã gửi đề nghị, tiếp tục trao đổi với người bán tại đây.';

  @override
  String productOfferBelow(String percent, String difference) {
    return 'Thấp hơn giá gốc $percent (-$difference)';
  }

  @override
  String productOfferAbove(String percent, String difference) {
    return 'Cao hơn giá gốc $percent (+$difference)';
  }

  @override
  String get productOfferEqual => 'Bằng giá gốc';

  @override
  String get productLiveTitle => 'Tin vừa được cập nhật';

  @override
  String productLiveUnavailable(String status) {
    return 'Sản phẩm hiện $status, bạn không thể đặt mua nữa.';
  }

  @override
  String get productLiveAvailable => 'Sản phẩm vừa được mở bán trở lại.';

  @override
  String productLivePrice(String previous, String current) {
    return 'Người bán vừa đổi giá từ $previous thành $current.';
  }

  @override
  String get productLivePriceGeneric =>
      'Người bán vừa cập nhật giá, bạn xem lại trước khi gửi nhé.';

  @override
  String get productLiveInfo => 'Người bán vừa sửa thông tin tin đăng.';

  @override
  String get productLiveIndicator => 'Đang cập nhật trực tiếp';

  @override
  String get productBuyTitle => 'Yêu cầu mua';

  @override
  String get productBuySubtitle =>
      'Người bán sẽ xác nhận và hẹn giao nhận với bạn qua tin nhắn.';

  @override
  String get productBuyPriceLabel => 'Giá';

  @override
  String get productBuyNoteLabel => 'Lời nhắn cho người bán';

  @override
  String get productBuyNoteHint => 'VD: Mình có thể qua lấy vào tối nay';

  @override
  String get productBuySubmit => 'Gửi yêu cầu';

  @override
  String get productBuySent =>
      'Đã gửi yêu cầu mua, người bán sẽ phản hồi qua tin nhắn.';

  @override
  String get productActionFailed => 'Gửi chưa được, vui lòng thử lại.';

  @override
  String get galleryOpenFullscreen => 'Xem ảnh toàn màn hình';

  @override
  String get nearbyTitle => 'Gần bạn';

  @override
  String get nearbySubtitle => 'Đồ cũ quanh đây, hẹn gặp là có ngay';

  @override
  String get nearbyCurrentLocation => 'Vị trí hiện tại';

  @override
  String get nearbyLocating => 'Đang xác định vị trí...';

  @override
  String get nearbyChangeLocation => 'Đổi';

  @override
  String get nearbyRelocate => 'Cập nhật vị trí';

  @override
  String get nearbyFilters => 'Bộ lọc';

  @override
  String nearbyRadiusChip(String distance) {
    return 'Trong $distance';
  }

  @override
  String get nearbyRadiusTitle => 'Tìm trong bán kính';

  @override
  String nearbyRadiusOption(String distance) {
    return 'Trong vòng $distance';
  }

  @override
  String get listingDealBuy => 'Mua trực tiếp';

  @override
  String get listingDealExchange => 'Trao đổi';

  @override
  String get listingSortTitle => 'Sắp xếp theo';

  @override
  String get listingSortNearest => 'Gần nhất';

  @override
  String get listingSortNewest => 'Mới nhất';

  @override
  String get listingSortPriceLow => 'Giá thấp đến cao';

  @override
  String get listingSortPriceHigh => 'Giá cao đến thấp';

  @override
  String get nearbyFallbackTitle => 'Đang xem quanh khu vực mặc định';

  @override
  String get nearbyUseMyLocation => 'Dùng vị trí của tôi';

  @override
  String get nearbyOpenSettings => 'Mở Cài đặt';

  @override
  String get nearbyEmptyTitle => 'Chưa có tin nào quanh đây';

  @override
  String get nearbyEmptyBody => 'Thử mở rộng bán kính hoặc bỏ bớt bộ lọc nhé.';

  @override
  String nearbyExpandRadius(String distance) {
    return 'Mở rộng tới $distance';
  }

  @override
  String get nearbyLoadErrorTitle => 'Chưa tải được tin gần bạn';

  @override
  String get nearbyLoadErrorBody => 'Kiểm tra kết nối mạng rồi thử lại nhé.';

  @override
  String get nearbyEndOfList => 'Bạn đã xem hết tin quanh đây';

  @override
  String distanceMeters(int meters) {
    return '$meters m';
  }

  @override
  String distanceKm(String km) {
    return '$km km';
  }

  @override
  String get listingSortRelevance => 'Phù hợp nhất';

  @override
  String get searchNearMe => 'Gần tôi';

  @override
  String get searchNearMeSubtitle => 'Xem đồ cũ quanh vị trí của bạn';

  @override
  String get searchTipsTitle => 'Gợi ý tìm nhanh';

  @override
  String get searchHistoryTitle => 'Tìm kiếm gần đây';

  @override
  String get searchClearHistory => 'Xoá tất cả';

  @override
  String get searchRemoveHistory => 'Xoá khỏi danh sách';

  @override
  String get searchFillQuery => 'Đưa lên ô tìm kiếm';

  @override
  String get searchClearInput => 'Xoá nội dung';

  @override
  String searchForQuery(String query) {
    return 'Tìm “$query”';
  }

  @override
  String searchEmptyTitle(String query) {
    return 'Không tìm thấy “$query”';
  }

  @override
  String get searchEmptyBody =>
      'Thử từ khoá ngắn hơn, từ khoá khác hoặc bỏ bớt bộ lọc nhé.';

  @override
  String get searchTryAnother => 'Đổi từ khoá';

  @override
  String get searchLoadErrorTitle => 'Chưa tải được kết quả';

  @override
  String get searchLoadErrorBody => 'Kiểm tra kết nối mạng rồi thử lại nhé.';

  @override
  String get searchEndOfList => 'Bạn đã xem hết kết quả';

  @override
  String get areaSearchHint => 'Tìm phường/xã, tỉnh/thành...';

  @override
  String get areaMyLocationSubtitle => 'Dùng vị trí GPS hiện tại của bạn';

  @override
  String get areaRecentTitle => 'Khu vực đã chọn gần đây';

  @override
  String get areaWholeProvince => 'Toàn tỉnh/thành phố';

  @override
  String get areaNoResultsTitle => 'Không tìm thấy khu vực';

  @override
  String get areaNoResultsBody =>
      'Thử gõ tên phường/xã hoặc tỉnh/thành khác nhé.';

  @override
  String get areaSearchErrorTitle => 'Chưa tìm được khu vực';

  @override
  String get listingFilterTitle => 'Bộ lọc';

  @override
  String get listingFilterCategory => 'Danh mục';

  @override
  String get listingFilterAllCategories => 'Tất cả';

  @override
  String get listingFilterCategoryError => 'Chưa tải được danh mục';

  @override
  String get listingFilterPrice => 'Khoảng giá';

  @override
  String get listingFilterPriceMin => 'Giá thấp nhất';

  @override
  String get listingFilterPriceMax => 'Giá cao nhất';

  @override
  String get listingFilterPriceAny => 'Không giới hạn';

  @override
  String get listingFilterPriceHelper =>
      'Tin chỉ nhận trao đổi (không có giá) sẽ bị ẩn khi lọc theo giá.';

  @override
  String get listingFilterPriceInvalid =>
      'Giá thấp nhất đang lớn hơn giá cao nhất.';

  @override
  String listingFilterPriceUnder(String price) {
    return 'Dưới $price';
  }

  @override
  String listingFilterPriceOver(String price) {
    return 'Trên $price';
  }

  @override
  String listingFilterPriceBetween(String min, String max) {
    return '$min – $max';
  }

  @override
  String get listingFilterCondition => 'Tình trạng';

  @override
  String get listingFilterDeal => 'Hình thức';

  @override
  String get listingFilterDistance => 'Khoảng cách';

  @override
  String get listingFilterReset => 'Xoá bộ lọc';

  @override
  String get listingFilterApply => 'Áp dụng';

  @override
  String listingFilterApplyCount(int count) {
    return 'Áp dụng ($count)';
  }

  @override
  String priceThousands(String value) {
    return '$value nghìn';
  }

  @override
  String priceMillions(String value) {
    return '$value triệu';
  }

  @override
  String get categoryDetailSearch => 'Tìm kiếm';

  @override
  String get categoryDetailEmptyTitle => 'Danh mục này chưa có tin nào';

  @override
  String get categoryDetailEmptyBody =>
      'Hãy là người đầu tiên đăng món đồ thuộc danh mục này nhé.';

  @override
  String get categoryDetailPostListing => 'Đăng tin';

  @override
  String get categoryDetailFilteredEmptyTitle => 'Không có tin khớp bộ lọc';

  @override
  String get categoryDetailFilteredEmptyBody =>
      'Thử bỏ bớt bộ lọc để xem thêm tin nhé.';

  @override
  String get categoryDetailLoadErrorTitle => 'Chưa tải được danh mục';

  @override
  String get categoryDetailLoadErrorBody =>
      'Kiểm tra kết nối mạng rồi thử lại nhé.';

  @override
  String get categoryDetailEndOfList => 'Bạn đã xem hết tin trong danh mục này';

  @override
  String get wantedAlertTitle => 'Báo khi có hàng';

  @override
  String get wantedAlertSubtitle =>
      'Đặt trước món bạn cần, có tin giống là báo ngay';

  @override
  String wantedAlertActiveCount(int count) {
    return '$count thông báo đang bật';
  }

  @override
  String get wantedAlertCreate => 'Tạo thông báo';

  @override
  String get wantedAlertNew => 'Tạo thông báo mới';

  @override
  String get wantedAlertEmptyTitle => 'Chưa có thông báo nào';

  @override
  String get wantedAlertEmptyBody =>
      'Đặt trước món bạn đang tìm, ReStore sẽ báo ngay khi có người đăng món gần giống.';

  @override
  String get wantedAlertLoadErrorTitle => 'Chưa tải được thông báo';

  @override
  String get wantedAlertLoadErrorBody =>
      'Kiểm tra kết nối mạng rồi thử lại nhé.';

  @override
  String wantedAlertNewMatches(int count) {
    return '$count tin mới';
  }

  @override
  String wantedAlertMatchCount(int count) {
    return '$count tin khớp';
  }

  @override
  String get wantedAlertNoMatchYet => 'Chưa có tin khớp';

  @override
  String wantedAlertLastMatched(String time) {
    return 'Khớp gần nhất $time';
  }

  @override
  String wantedAlertCreatedAt(String time) {
    return 'Tạo $time';
  }

  @override
  String get wantedAlertWatching => 'Đang theo dõi';

  @override
  String get wantedAlertAnyCategory => 'Mọi danh mục';

  @override
  String get wantedAlertNationwide => 'Toàn quốc';

  @override
  String get wantedAlertAnyPrice => 'Mọi mức giá';

  @override
  String get wantedAlertAnyCondition => 'Mọi tình trạng';

  @override
  String get wantedAlertAnyDeal => 'Mua hoặc trao đổi';

  @override
  String wantedAlertPriceFrom(String price) {
    return 'Từ $price';
  }

  @override
  String wantedAlertPriceUpTo(String price) {
    return 'Đến $price';
  }

  @override
  String wantedAlertPriceRange(String min, String max) {
    return '$min – $max';
  }

  @override
  String get wantedAlertDelete => 'Xoá thông báo';

  @override
  String get wantedAlertDeleteTitle => 'Xoá thông báo này?';

  @override
  String wantedAlertDeleteBody(String keywords) {
    return 'ReStore sẽ ngừng báo tin mới cho “$keywords”. Bạn có thể tạo lại bất cứ lúc nào.';
  }

  @override
  String get wantedAlertKeep => 'Giữ lại';

  @override
  String get wantedAlertDeleted =>
      'Đã xoá thông báo, bạn sẽ không nhận tin mới cho món này nữa.';

  @override
  String get wantedAlertDeleteError => 'Chưa xoá được thông báo, thử lại nhé.';

  @override
  String get wantedAlertSearchHint => 'Bạn đang tìm món gì?';

  @override
  String get wantedAlertIntroTitle => 'Tìm trước, đặt báo sau';

  @override
  String get wantedAlertIntroStep1 =>
      'Gõ món bạn cần, ReStore tìm ngay tin đang có gần giống.';

  @override
  String get wantedAlertIntroStep2 =>
      'Thấy món ưng ý thì xem luôn, không cần chờ.';

  @override
  String get wantedAlertIntroStep3 =>
      'Chưa có? Tạo thông báo, có tin mới gần giống là ReStore báo kèm đường dẫn.';

  @override
  String get wantedAlertSkipToCompose => 'Bỏ qua, viết thông báo luôn';

  @override
  String wantedAlertSuggestionsTitle(int count) {
    return '$count tin đang có gần giống';
  }

  @override
  String get wantedAlertSuggestionsHint =>
      'Chưa ưng món nào? Tạo thông báo để được báo khi có tin mới.';

  @override
  String get wantedAlertSuggestionsEmptyTitle => 'Chưa có tin nào gần giống';

  @override
  String get wantedAlertSuggestionsEmptyBody =>
      'Tạo thông báo, ReStore sẽ báo ngay khi có người đăng món bạn cần.';

  @override
  String get wantedAlertSuggestionsErrorTitle => 'Chưa tải được tin gợi ý';

  @override
  String get wantedAlertSuggestionsErrorBody =>
      'Bạn vẫn có thể tạo thông báo ngay bây giờ.';

  @override
  String wantedAlertMatchPercent(int percent) {
    return 'Giống $percent%';
  }

  @override
  String get wantedAlertNotRightCta => 'Chưa ưng? Tạo thông báo';

  @override
  String get wantedAlertComposeTitle => 'Soạn thông báo';

  @override
  String get wantedAlertComposeSubtitle =>
      'Có tin mới gần giống, ReStore gửi thông báo kèm đường dẫn tới tin.';

  @override
  String get wantedAlertKeywordsLabel => 'Món bạn muốn tìm';

  @override
  String get wantedAlertKeywordsHint => 'VD: máy ảnh film Canon AE-1';

  @override
  String get wantedAlertKeywordsHelper =>
      'Gõ tên món, hãng, model. Không cần y hệt, tin gần giống cũng được báo.';

  @override
  String wantedAlertKeywordsError(int min) {
    return 'Nhập ít nhất $min ký tự';
  }

  @override
  String get wantedAlertCriteriaTitle => 'Tiêu chí (không bắt buộc)';

  @override
  String get wantedAlertCriteriaCategory => 'Danh mục';

  @override
  String get wantedAlertCriteriaPrice => 'Khoảng giá';

  @override
  String get wantedAlertCriteriaCondition => 'Tình trạng';

  @override
  String get wantedAlertCriteriaDeal => 'Hình thức';

  @override
  String get wantedAlertCriteriaArea => 'Khu vực';

  @override
  String get wantedAlertEditCriteria => 'Chỉnh tiêu chí';

  @override
  String get wantedAlertLevelTitle => 'Mức độ giống';

  @override
  String get wantedAlertLevelBroad => 'Rộng';

  @override
  String get wantedAlertLevelBalanced => 'Vừa';

  @override
  String get wantedAlertLevelStrict => 'Sát';

  @override
  String get wantedAlertLevelBroadDesc =>
      'Báo cả tin chỉ hơi giống, bạn sẽ nhận nhiều thông báo hơn.';

  @override
  String get wantedAlertLevelBalancedDesc =>
      'Phần lớn từ khoá phải khớp, gõ sai nhẹ vẫn nhận ra.';

  @override
  String get wantedAlertLevelStrictDesc =>
      'Chỉ báo tin gần như đúng món bạn nhập.';

  @override
  String get wantedAlertPreviewTitle => 'Tin đang có khớp thông báo';

  @override
  String get wantedAlertPreviewEmpty =>
      'Hiện chưa có tin nào khớp, bạn sẽ được báo khi có người đăng.';

  @override
  String get wantedAlertPreviewNeedKeywords =>
      'Nhập món bạn muốn tìm để xem trước tin khớp.';

  @override
  String get wantedAlertSave => 'Bật thông báo';

  @override
  String wantedAlertCreated(String keywords) {
    return 'Đã bật thông báo cho “$keywords”. Có tin gần giống, ReStore sẽ báo bạn ngay.';
  }

  @override
  String get wantedAlertCreateError => 'Chưa tạo được thông báo, thử lại nhé.';

  @override
  String get wantedAlertNewTag => 'Mới';

  @override
  String get wantedAlertMatchesTitle => 'Tin đã khớp';

  @override
  String get wantedAlertMatchesEmptyTitle => 'Chưa có tin khớp';

  @override
  String get wantedAlertMatchesEmptyBody =>
      'Khi có người đăng món gần giống, ReStore sẽ gửi thông báo và tin sẽ hiện ở đây.';

  @override
  String get wantedAlertEndOfList => 'Bạn đã xem hết tin khớp';

  @override
  String get wantedAlertPromptTitle => 'Chưa thấy món ưng ý?';

  @override
  String wantedAlertPromptBody(String query) {
    return 'Đặt báo cho “$query”, có tin mới gần giống là ReStore báo ngay.';
  }

  @override
  String get areaNationwide => 'Toàn quốc';

  @override
  String get areaNationwideSubtitle =>
      'Không giới hạn khu vực, tin ở đâu cũng báo';

  @override
  String get trustedShopsTitle => 'Shop uy tín';

  @override
  String get trustedShopsSubtitle => 'Gian hàng chính hãng đã xác minh';

  @override
  String get trustedShopsAllCategories => 'Tất cả';

  @override
  String get trustedShopsOfficialTitle => 'Thương hiệu chính hãng';

  @override
  String get trustedShopsCertifiedTitle => 'Shop được ReStore chứng nhận';

  @override
  String get trustedShopsShowcaseTitle => 'Sản phẩm theo nhãn hàng';

  @override
  String get trustedShopsShowcaseSubtitle =>
      'Nổi bật từ các shop được theo dõi nhiều nhất';

  @override
  String get trustedShopsViewShop => 'Xem shop';

  @override
  String get trustedShopsAllProductsTitle => 'Tất cả sản phẩm';

  @override
  String get trustedShopsAllProductsSubtitle => 'Từ mọi shop đã xác minh';

  @override
  String get trustedShopsEndOfList => 'Bạn đã xem hết sản phẩm của shop uy tín';

  @override
  String get trustedShopsEmptyTitle => 'Chưa có shop uy tín trong mục này';

  @override
  String get trustedShopsEmptyBody =>
      'Khi có shop được xác minh bán mặt hàng này, shop sẽ hiện ở đây.';

  @override
  String get trustedShopsLoadErrorTitle => 'Chưa tải được shop uy tín';

  @override
  String get trustedShopsLoadErrorBody =>
      'Kiểm tra kết nối mạng rồi thử lại nhé.';

  @override
  String get trustedShopsFamousTitle => 'Thương hiệu nổi tiếng';

  @override
  String get trustedShopsFamousSubtitle =>
      'Gian hàng chính hãng của các thương hiệu lớn';

  @override
  String get trustedShopsDealsTitle => 'Trải nghiệm hàng hiệu';

  @override
  String get trustedShopsDealsSubtitle => 'Hàng hiệu chính hãng đang giảm giá';

  @override
  String trustedShopsDealsUpTo(int percent) {
    return 'Giảm đến $percent%';
  }

  @override
  String get trustedShopsNewReleasesTitle => 'Siêu phẩm mới ra mắt';

  @override
  String get trustedShopsNewReleasesSubtitle =>
      'Sản phẩm vừa ra mắt từ các thương hiệu lớn';

  @override
  String get trustedShopsNewReleaseTag => 'Mới ra mắt';

  @override
  String trustedShopsLaunchedDaysAgo(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: 'Ra mắt $count ngày trước',
      zero: 'Ra mắt hôm nay',
    );
    return '$_temp0';
  }

  @override
  String get trustedShopsNewShopsTitle => 'Cửa hàng mới';

  @override
  String get trustedShopsNewShopsSubtitle => 'Shop vừa được ReStore xác minh';

  @override
  String get trustedShopsNavFamous => 'Thương hiệu';

  @override
  String get trustedShopsNavDeals => 'Giảm giá';

  @override
  String get trustedShopsNavNewReleases => 'Mới ra mắt';

  @override
  String get trustedShopsNavNewShops => 'Cửa hàng mới';

  @override
  String get trustedShopsNavShowcases => 'Theo nhãn hàng';

  @override
  String get trustedShopsNavAll => 'Tất cả sản phẩm';

  @override
  String get trustedShopsSeeAll => 'Xem tất cả';

  @override
  String get trustedShopsOnSaleFilter => 'Đang giảm giá';

  @override
  String get shopDetailEventsTitle => 'Sự kiện của shop';

  @override
  String get shopDetailEventsSubtitle => 'Ưu đãi đã được ReStore duyệt';

  @override
  String get shopVerificationOfficial => 'Chính hãng';

  @override
  String get shopVerificationCertified => 'Đã chứng nhận';

  @override
  String get shopVerificationOfficialDesc =>
      'Shop gốc của nhãn hàng hoặc nhà phân phối được uỷ quyền, hàng chính hãng có bảo hành.';

  @override
  String get shopVerificationCertifiedDesc =>
      'ReStore đã kiểm tra giấy phép kinh doanh, địa chỉ và lịch sử giao dịch trước khi cấp chứng nhận.';

  @override
  String get shopVerificationSheetTitle => 'Về shop đã xác minh';

  @override
  String get shopVerificationSheetSubtitle =>
      'Chỉ shop đạt một trong hai mức sau mới hiện ở Shop uy tín';

  @override
  String get shopVerificationSheetNote =>
      'ReStore rà soát định kỳ và thu hồi chứng nhận nếu shop vi phạm quy định hoặc bị khiếu nại nhiều lần.';

  @override
  String get shopCertificateTitle => 'Chứng nhận của shop';

  @override
  String get shopCertificateCode => 'Mã chứng nhận';

  @override
  String get shopVerifiedSince => 'Ngày xác minh';

  @override
  String shopVerifiedSinceShort(String date) {
    return 'Xác minh $date';
  }

  @override
  String get shopFollow => 'Theo dõi';

  @override
  String get shopFollowing => 'Đang theo dõi';

  @override
  String shopFollowerCount(String count) {
    return '$count theo dõi';
  }

  @override
  String shopListingCount(int count) {
    return '$count sản phẩm';
  }

  @override
  String shopRatingCount(String count) {
    return '$count đánh giá';
  }

  @override
  String get shopFollowersLabel => 'Người theo dõi';

  @override
  String get shopProductsLabel => 'Sản phẩm';

  @override
  String get shopDescriptionMore => 'Xem thêm';

  @override
  String get shopDescriptionLess => 'Thu gọn';

  @override
  String get shopDetailProductsTitle => 'Sản phẩm đang bán';

  @override
  String get shopDetailEmptyTitle => 'Shop chưa có sản phẩm';

  @override
  String get shopDetailEmptyBody =>
      'Theo dõi shop để biết ngay khi có sản phẩm mới.';

  @override
  String get shopDetailEndOfList => 'Bạn đã xem hết sản phẩm của shop';

  @override
  String get shopDetailLoadErrorTitle => 'Chưa tải được trang shop';

  @override
  String get shopDetailLoadErrorBody =>
      'Kiểm tra kết nối mạng rồi thử lại nhé.';

  @override
  String get postingQuotaPersonalTitle => 'Tài khoản cá nhân';

  @override
  String postingQuotaBannerMessage(int min, int max, int days) {
    return 'Mỗi chuyên mục được $min đến $max tin miễn phí đang hiển thị. Mỗi tin hiển thị $days ngày.';
  }

  @override
  String get postingRulesAction => 'Xem quy định';

  @override
  String postingQuotaUsage(int used, int limit) {
    return 'Đã đăng $used/$limit tin';
  }

  @override
  String postingQuotaFull(int limit) {
    return 'Đã đủ $limit tin';
  }

  @override
  String get postingQuotaLastSlot => 'Còn 1 lượt đăng';

  @override
  String postingQuotaRemainingInCategory(int remaining, int limit) {
    return 'Còn $remaining/$limit lượt đăng trong chuyên mục này';
  }

  @override
  String get postingLimitTitle => 'Chuyên mục đã đủ số tin';

  @override
  String postingLimitMessage(int limit, String category) {
    return 'Tài khoản cá nhân được đăng tối đa $limit tin đang hiển thị trong mục $category. Hãy giải phóng một suất để đăng tin mới.';
  }

  @override
  String get postingLimitWaysTitle => 'Cách giải phóng suất đăng';

  @override
  String get postingLimitTipSold => 'Đánh dấu “Đã bán” cho món đã bán xong';

  @override
  String get postingLimitTipHide => 'Ẩn tin bạn không còn muốn bán';

  @override
  String postingLimitTipExpire(int days) {
    return 'Tin hết hạn sau $days ngày cũng được trả lại suất';
  }

  @override
  String get manageMyListings => 'Quản lý tin đăng';

  @override
  String get chooseAnotherCategory => 'Chọn mục khác';

  @override
  String get postingRulesTitle => 'Quy định đăng tin';

  @override
  String get postingRulesSubtitle => 'Áp dụng cho người bán cá nhân';

  @override
  String postingRuleLimit(int min, int max) {
    return 'Mỗi chuyên mục được $min đến $max tin miễn phí đang hiển thị. Món giá trị cao như điện thoại, xe cộ chỉ được 1 tin.';
  }

  @override
  String get postingRuleCounted =>
      'Chỉ tính tin đang hiển thị và đang chờ duyệt. Tin đã bán, đã ẩn hoặc hết hạn không bị tính.';

  @override
  String postingRuleDuration(int days) {
    return 'Mỗi tin hiển thị $days ngày kể từ khi được duyệt.';
  }

  @override
  String get postingRuleFree =>
      'Đăng tin miễn phí. Mỗi tin được kiểm duyệt trước khi hiển thị.';

  @override
  String get postingRulePersonalUse =>
      'Tài khoản cá nhân dành cho việc bán đồ của chính bạn. Nếu đăng bán nhiều và thường xuyên như kinh doanh, ReStore có thể chuyển bạn sang tài khoản bán chuyên.';

  @override
  String postingRuleBusiness(int limit) {
    return 'Gói Bán chuyên (sắp ra mắt): tối đa $limit tin mỗi chuyên mục. Gói Cửa hàng có thêm trang cửa hàng riêng.';
  }

  @override
  String homeGreetingPro(String name) {
    return 'Chào nhà bán chuyên $name 👋';
  }

  @override
  String homeGreetingShop(String name) {
    return 'Chào chủ shop $name 👋';
  }

  @override
  String get planPersonal => 'Cá nhân';

  @override
  String get planPro => 'Bán chuyên';

  @override
  String get planShop => 'Cửa hàng';

  @override
  String get devPlanTag => 'TEST';

  @override
  String get devPlanSwitchTooltip =>
      'Đổi gói để test giao diện (chỉ đổi trong app)';

  @override
  String get quickMenuOpen => 'Mở menu nhanh';

  @override
  String get quickMenuClose => 'Đóng menu nhanh';

  @override
  String get quickActionPost => 'Đăng tin';

  @override
  String get quickActionPoster => 'Poster shop';

  @override
  String get quickActionBoost => 'Đẩy tin';

  @override
  String get quickActionStats => 'Thống kê';

  @override
  String get quickActionShopManage => 'Quản lý shop';

  @override
  String get trustedShopsFamousEyebrow => 'Chính hãng';

  @override
  String get trustedShopsDealsEyebrow => 'Đang giảm giá';

  @override
  String get trustedShopsNewReleasesEyebrow => 'Vừa ra mắt';

  @override
  String get trustedShopsNewShopsEyebrow => 'Mới xác minh';

  @override
  String get trustedShopsShowcaseEyebrow => 'Theo nhãn hàng';

  @override
  String get trustedShopsAllProductsEyebrow => 'Khám phá';

  @override
  String get feedsComposePrompt =>
      'Bạn đang nghĩ gì? Khoe món đồ hay hỏi cộng đồng';

  @override
  String get postAudienceTitle => 'Ai được xem bài này?';

  @override
  String get postAudienceEveryone => 'Mọi người';

  @override
  String get postAudienceEveryoneDesc => 'Ai trên ReStore cũng xem được';

  @override
  String get postAudienceFollowers => 'Người theo dõi';

  @override
  String get postAudienceFollowersDesc => 'Chỉ người đang theo dõi bạn';

  @override
  String get postAudienceOnlyMe => 'Chỉ mình tôi';

  @override
  String get postAudienceOnlyMeDesc => 'Lưu riêng trên trang của bạn';

  @override
  String get postComposerSubmit => 'Đăng';

  @override
  String get postComposerHint =>
      'Khoe món đồ, chia sẻ kinh nghiệm hay hỏi cộng đồng...';

  @override
  String get postComposerRemovePhoto => 'Bỏ ảnh';

  @override
  String get postComposerCover => 'Ảnh bìa';

  @override
  String get postComposerListingTag => 'Tin đăng của bạn';

  @override
  String get postComposerRemoveAttachment => 'Bỏ';

  @override
  String postComposerWithOne(String name) {
    return 'Cùng $name';
  }

  @override
  String postComposerWithMany(String name, int count) {
    return 'Cùng $name và $count người khác';
  }

  @override
  String get postComposerBackground => 'Nền màu';

  @override
  String get postComposerBackgroundDisabled =>
      'Nền màu chỉ dùng cho bài ngắn, chưa có ảnh';

  @override
  String get postComposerNoBackground => 'Không dùng nền';

  @override
  String get postComposerAttachListing => 'Gắn tin đăng';

  @override
  String get postComposerAttachListingHint =>
      'Hiện một tin đăng của bạn trong bài viết';

  @override
  String get postComposerTopic => 'Chủ đề';

  @override
  String get postComposerTopicHint => 'Giúp đúng người tìm thấy bài của bạn';

  @override
  String get postComposerTagFriends => 'Gắn thẻ';

  @override
  String get postComposerTagFriendsHint => 'Những người bạn đang theo dõi';

  @override
  String postComposerTaggedCount(int count) {
    return 'Đã gắn $count người';
  }

  @override
  String get postComposerEmoji => 'Biểu cảm';

  @override
  String get postComposerPhoto => 'Ảnh';

  @override
  String get postComposerVideo => 'Video';

  @override
  String get postComposerLink => 'Liên kết';

  @override
  String get postComposerLinkHint => 'Dán đường dẫn trang web muốn chia sẻ';

  @override
  String get postComposerLinkInvalid => 'Liên kết chưa đúng';

  @override
  String get postComposerLocation => 'Vị trí';

  @override
  String get postComposerTakePhoto => 'Chụp ảnh';

  @override
  String get postComposerOpenGallery => 'Thư viện';

  @override
  String get postComposerDone => 'Xong';

  @override
  String get postComposerLoadError =>
      'Chưa tải được tuỳ chọn bài viết, đang thử lại';

  @override
  String get postComposerDiscardTitle => 'Bỏ bài viết này?';

  @override
  String get postComposerDiscardMessage =>
      'Nội dung bạn vừa viết sẽ không được lưu';

  @override
  String get postComposerKeepEditing => 'Tiếp tục viết';

  @override
  String get postComposerDiscard => 'Bỏ bài viết';

  @override
  String postComposerPhotoLimit(int count) {
    return 'Mỗi bài tối đa $count ảnh';
  }

  @override
  String get postComposerPhotoPermission =>
      'ReStore cần quyền truy cập ảnh. Vui lòng bật trong Cài đặt.';

  @override
  String get postComposerNoListings =>
      'Bạn chưa có tin đăng nào đang hiển thị để gắn';

  @override
  String get postComposerError => 'Chưa đăng được bài, vui lòng thử lại';

  @override
  String get postComposerPosted => 'Bài viết đã lên Bảng tin';

  @override
  String get authSessionExpired =>
      'Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.';

  @override
  String get draftsTitle => 'Tin nháp';

  @override
  String get draftsBannerTitle => 'Soạn tiếp tin nháp';

  @override
  String draftsBannerMessage(String count) {
    return 'Bạn có $count tin chưa đăng';
  }

  @override
  String get draftsBannerAction => 'Xem';

  @override
  String get draftUntitled => 'Chưa có tiêu đề';

  @override
  String get draftNoCategory => 'Chưa chọn danh mục';

  @override
  String draftEditedAt(String time) {
    return 'Sửa lúc $time';
  }

  @override
  String draftPhotoCount(int count) {
    return '$count ảnh';
  }

  @override
  String get draftsEmptyTitle => 'Chưa có tin nháp';

  @override
  String get draftsEmptyMessage =>
      'Khi đăng tin, bấm Lưu nháp để soạn tiếp lúc khác.';

  @override
  String get draftsLoadFailedTitle => 'Không tải được tin nháp';

  @override
  String get draftsLoadFailedMessage => 'Kiểm tra kết nối mạng rồi thử lại.';

  @override
  String get draftOpenFailed =>
      'Không mở được tin nháp, có thể tin đã được đăng hoặc đã xóa';

  @override
  String get draftDeleteTitle => 'Xóa tin nháp?';

  @override
  String get draftDeleteMessage =>
      'Tin nháp và ảnh đã tải lên sẽ bị xóa, không khôi phục được.';

  @override
  String get draftDeleteConfirm => 'Xóa nháp';

  @override
  String get draftDeleted => 'Đã xóa tin nháp';

  @override
  String draftDeletedNamed(String title) {
    return 'Đã xóa tin nháp “$title”';
  }

  @override
  String get draftDeleteFailed => 'Xóa tin nháp thất bại, vui lòng thử lại';

  @override
  String get leaveDraftTitle => 'Lưu tin trước khi thoát?';

  @override
  String get leaveDraftMessage =>
      'Nội dung bạn vừa nhập chưa được lưu. Lưu nháp để soạn tiếp lúc khác.';

  @override
  String get leaveDraftSave => 'Lưu nháp và thoát';

  @override
  String get leaveDraftDiscard => 'Thoát, không lưu';

  @override
  String draftLimitTitle(int limit) {
    return 'Đã đủ $limit tin nháp';
  }

  @override
  String get draftLimitTitleUnknown => 'Đã đủ số tin nháp';

  @override
  String draftLimitMessage(int limit) {
    return 'Tài khoản của bạn giữ được tối đa $limit tin nháp. Hãy đăng hoặc xóa bớt tin nháp cũ để lưu tin này.';
  }

  @override
  String get draftLimitMessageUnknown =>
      'Tài khoản của bạn đã giữ đủ số tin nháp. Hãy đăng hoặc xóa bớt tin nháp cũ để lưu tin này.';

  @override
  String get draftLimitViewDrafts => 'Xem tin nháp';

  @override
  String draftsQuota(int used, int limit) {
    return 'Đang giữ $used/$limit tin nháp';
  }

  @override
  String get listingImageTooLarge =>
      'Có ảnh quá lớn (tối đa 5 MB). Hãy bỏ ảnh đó hoặc chọn ảnh khác.';

  @override
  String get listingImageUnsupported =>
      'Có ảnh không đúng định dạng (chỉ nhận JPEG, PNG, WebP). Hãy bỏ ảnh đó hoặc chọn ảnh khác.';

  @override
  String listingImageMissing(int count) {
    return '$count ảnh không còn trên máy nên đã được bỏ ra. Hãy chọn lại ảnh rồi lưu lại.';
  }

  @override
  String get listingSaveNetworkError =>
      'Không kết nối được máy chủ. Phần đã lưu được giữ lại, bạn thử lại nhé.';

  @override
  String get feedReply => 'Trả lời';

  @override
  String get feedHideReplies => 'Ẩn trả lời';

  @override
  String feedViewReplies(int count) {
    return 'Xem $count trả lời';
  }

  @override
  String feedReplyTo(String name) {
    return 'Đang trả lời $name';
  }

  @override
  String get feedCancelReply => 'Hủy trả lời';

  @override
  String get feedMoreComments => 'Xem thêm bình luận';

  @override
  String get creditTitle => 'Xu ReStore';

  @override
  String get creditAvailable => 'Số xu có thể dùng';

  @override
  String creditPoints(int count, String amount) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$amount xu',
    );
    return '$_temp0';
  }

  @override
  String get creditUnit => 'xu';

  @override
  String get creditPaidLabel => 'Xu nạp';

  @override
  String get creditBonusLabel => 'Xu tặng';

  @override
  String get creditHeldLabel => 'Đang giữ';

  @override
  String creditBonusExpiry(String date) {
    return 'Xu tặng bắt đầu hết hạn ngày $date.';
  }

  @override
  String get creditHeldHint =>
      'Xu đang giữ là của tin chờ duyệt, tin bị từ chối thì xu trả lại ví.';

  @override
  String get creditTopupAction => 'Nạp xu';

  @override
  String get creditUsesTitle => 'Dùng xu để';

  @override
  String get creditUsePostMore => 'Đăng thêm tin';

  @override
  String get creditUseBoost => 'Đẩy tin';

  @override
  String get creditUseUpgrade => 'Nâng gói';

  @override
  String get creditRecentTitle => 'Giao dịch gần đây';

  @override
  String get creditSeeAll => 'Xem tất cả';

  @override
  String get creditEmptyHistory => 'Chưa có giao dịch xu nào';

  @override
  String get creditLoadError => 'Không tải được ví xu';

  @override
  String get creditHistoryTitle => 'Lịch sử xu';

  @override
  String get creditFilterAll => 'Tất cả';

  @override
  String get creditFilterTopup => 'Nạp';

  @override
  String get creditFilterSpend => 'Đã dùng';

  @override
  String get creditFilterRefund => 'Hoàn';

  @override
  String get creditTxnTopup => 'Nạp xu';

  @override
  String get creditTxnBonus => 'Xu tặng kèm gói';

  @override
  String get creditTxnSpend => 'Dùng xu';

  @override
  String get creditTxnRefund => 'Hoàn xu';

  @override
  String get creditTxnExpire => 'Xu hết hạn';

  @override
  String get creditTxnAdjust => 'Điều chỉnh';

  @override
  String creditTxnOrder(String code) {
    return 'Đơn $code';
  }

  @override
  String get creditTopupTitle => 'Chọn gói nạp';

  @override
  String get creditRate => '1 xu = 1.000 đ. Gói lớn được tặng thêm xu.';

  @override
  String get creditPopular => 'Phổ biến';

  @override
  String creditBonusTag(String amount) {
    return 'tặng $amount xu';
  }

  @override
  String get creditNoBonus => 'Không kèm tặng';

  @override
  String get creditTerms =>
      'Xu chỉ dùng trong ReStore: không rút ra tiền, không chuyển cho người khác. Xu tặng được dùng trước và hết hạn sau 90 ngày.';

  @override
  String creditContinue(String price) {
    return 'Tiếp tục · $price';
  }

  @override
  String get creditConfirmTitle => 'Xác nhận nạp xu';

  @override
  String get creditSummaryPack => 'Gói nạp';

  @override
  String get creditSummaryReceive => 'Xu nhận';

  @override
  String get creditSummaryTotal => 'Tổng thanh toán';

  @override
  String creditReceiveWithBonus(String total, String bonus) {
    return '$total xu (gồm $bonus xu tặng)';
  }

  @override
  String get creditPayMethodTitle => 'Cách thanh toán';

  @override
  String get creditMethodZalopay => 'ZaloPay';

  @override
  String get creditMethodZalopayDesc =>
      'Ví ZaloPay, thẻ ATM nội địa hoặc thẻ quốc tế.';

  @override
  String get creditMethodVietqr => 'Chuyển khoản VietQR';

  @override
  String get creditMethodVietqrDesc =>
      'Quét mã bằng app ngân hàng, xu vào khi tiền về.';

  @override
  String get creditSandboxNote => 'Chế độ thử (sandbox): không trừ tiền thật.';

  @override
  String get creditAgree =>
      'Tôi đồng ý: xu không đổi lại thành tiền mặt, trừ khi thanh toán bị lỗi hoặc bị trừ hai lần.';

  @override
  String creditPayAction(String price) {
    return 'Thanh toán $price';
  }

  @override
  String get creditPayZalopayTitle => 'Thanh toán ZaloPay';

  @override
  String get creditPayBankTitle => 'Chuyển khoản';

  @override
  String get creditOrderCode => 'Mã đơn';

  @override
  String get creditGatewayNotConnected =>
      'Đang bỏ qua cổng ZaloPay (chế độ debug hoặc máy chủ chưa có khoá). Dùng các nút bên dưới để giả lập kết quả.';

  @override
  String get creditOpenGateway => 'Mở trang thanh toán ZaloPay';

  @override
  String get creditWaitingGateway =>
      'Thanh toán xong trên trang ZaloPay rồi quay lại đây, xu sẽ tự cập nhật.';

  @override
  String get creditSimulateTitle =>
      'Giả lập kết quả thanh toán (chỉ ở chế độ thử)';

  @override
  String get creditSimulateSuccess => 'Đã trả tiền';

  @override
  String get creditSimulateFail => 'Thất bại';

  @override
  String get creditScanQr => 'Quét bằng app ngân hàng bất kỳ';

  @override
  String get creditAccountNo => 'Số tài khoản';

  @override
  String get creditAccountName => 'Chủ tài khoản';

  @override
  String get creditTransferContent => 'Nội dung';

  @override
  String creditQrExpires(String time) {
    return 'Mã hết hạn lúc $time';
  }

  @override
  String get creditWaitingTransfer =>
      'Đang chờ tiền về. Giữ nguyên nội dung chuyển khoản để xu vào tự động.';

  @override
  String get creditVietQrUnavailable =>
      'Máy chủ chưa cấu hình tài khoản nhận chuyển khoản.';

  @override
  String get creditCopied => 'Đã sao chép';

  @override
  String get creditCopy => 'Sao chép';

  @override
  String get creditCancelOrder => 'Huỷ đơn';

  @override
  String get creditResultTitle => 'Kết quả';

  @override
  String get creditSuccessTitle => 'Nạp thành công';

  @override
  String creditSuccessAmount(String amount) {
    return '+$amount xu';
  }

  @override
  String get creditSuccessBody => 'Xu đã vào ví của bạn.';

  @override
  String get creditPendingTitle => 'Đang chờ xác nhận';

  @override
  String get creditPendingBody =>
      'Xu sẽ vào ví ngay khi cổng thanh toán xác nhận. Bạn có thể rời trang này.';

  @override
  String get creditFailTitle => 'Chưa nạp được';

  @override
  String get creditFailBody =>
      'Giao dịch đã bị huỷ hoặc hết hạn. Bạn chưa bị trừ tiền.';

  @override
  String get creditCheckAgain => 'Kiểm tra lại';

  @override
  String get creditTryAgain => 'Thử lại';

  @override
  String get creditDone => 'Xong';

  @override
  String get creditBackToWallet => 'Về ví xu';

  @override
  String get creditErrorTooManyPending =>
      'Bạn đang có quá nhiều đơn nạp chưa thanh toán. Đợi 15 phút để đơn hết hạn hoặc huỷ bớt.';

  @override
  String get creditErrorGeneric => 'Không thực hiện được, vui lòng thử lại.';

  @override
  String get creditPackagesError => 'Không tải được gói nạp';

  @override
  String get postingLimitTotalTitle => 'Đã đủ số tin miễn phí';

  @override
  String postingLimitTotalMessage(int limit) {
    return 'Tài khoản cá nhân được đăng tối đa $limit tin miễn phí cùng lúc trên tất cả chuyên mục.';
  }

  @override
  String postingLimitRecentMessage(String category, int days) {
    return 'Bạn đã đăng miễn phí nhiều lần ở mục $category trong $days ngày qua. Mỗi chuyên mục được đăng miễn phí tối đa gấp đôi số suất trong $days ngày.';
  }

  @override
  String postingPayTitle(int credits) {
    return 'Đăng tin này với $credits xu';
  }

  @override
  String postingPayBalance(int available) {
    return 'Ví của bạn: $available xu';
  }

  @override
  String get postingPayNote =>
      'Xu được giữ khi gửi tin và chỉ bị trừ khi tin được duyệt. Tin bị từ chối sẽ được hoàn xu.';

  @override
  String postingPayMissing(int missing) {
    return 'Bạn cần nạp thêm $missing xu.';
  }

  @override
  String postingPayContinue(int credits) {
    return 'Tiếp tục · $credits xu';
  }

  @override
  String postingPayPublish(int credits) {
    return 'Đăng · $credits xu';
  }

  @override
  String get postingTopUp => 'Nạp xu';

  @override
  String get postingFreeWaysTitle => 'Hoặc giải phóng suất miễn phí';

  @override
  String postingQuotaTotalUsage(int used, int limit) {
    return 'Đã dùng $used/$limit tin miễn phí của tài khoản';
  }

  @override
  String postingQuotaPaidHint(int credits) {
    return 'Hết suất? Đăng thêm bằng xu, từ $credits xu một tin.';
  }

  @override
  String accExpiresIn(int days) {
    return 'Còn $days ngày';
  }

  @override
  String get accExpired => 'Hết hạn';

  @override
  String get accReactivate => 'Kích hoạt lại';

  @override
  String get accReactivated => 'Đã kích hoạt lại tin';

  @override
  String get accExtend => 'Gia hạn tin';

  @override
  String accExtendMessage(int days, int credits) {
    return 'Tin hiển thị thêm $days ngày với $credits xu. Xu bị trừ ngay, không cần duyệt lại.';
  }

  @override
  String accExtendPay(int credits) {
    return 'Gia hạn · $credits xu';
  }

  @override
  String accExtendTooEarly(int days) {
    return 'Gia hạn được khi tin còn tối đa $days ngày.';
  }

  @override
  String get accExtended => 'Đã gia hạn tin';

  @override
  String postingPayReactivate(int credits) {
    return 'Kích hoạt · $credits xu';
  }

  @override
  String get postingLater => 'Để sau';

  @override
  String get duplicateActiveTitle => 'Bạn đã có tin này';

  @override
  String get duplicateActiveMessage =>
      'Tin giống vậy của bạn đang hiển thị hoặc chờ duyệt, không cần đăng thêm.';

  @override
  String get duplicateInactiveTitle => 'Dùng lại tin cũ?';

  @override
  String get duplicateInactiveMessage =>
      'Bạn có tin giống vậy đã ẩn hoặc hết hạn. Kích hoạt lại tin cũ để giữ lượt xem và lượt lưu.';

  @override
  String get duplicateOpenOld => 'Xem tin cũ';

  @override
  String get duplicatePostNew => 'Vẫn đăng mới';

  @override
  String postingPayReactivateTitle(int credits) {
    return 'Hiện lại tin này với $credits xu';
  }

  @override
  String get postingPayNowNote =>
      'Xu bị trừ ngay khi tin hiện lại, không cần duyệt lại.';

  @override
  String get boostSheetMessage =>
      'Tin được đưa lên đầu danh sách trong 24 giờ.';

  @override
  String boostFreeNote(int left, int perMonth) {
    return 'Dùng 1 lượt miễn phí của gói, còn $left/$perMonth lượt tháng này.';
  }

  @override
  String boostPayNote(int credits) {
    return 'Giá $credits xu, trừ ngay khi đẩy.';
  }

  @override
  String boostDiscountNote(int percent) {
    return 'Gói của bạn được giảm $percent%.';
  }

  @override
  String get boostUseFree => 'Đẩy miễn phí';

  @override
  String boostPay(int credits) {
    return 'Đẩy tin · $credits xu';
  }

  @override
  String get boostDone => 'Đã đẩy tin lên đầu';

  @override
  String boostTooSoon(int hours) {
    return 'Tin vừa được đẩy. Bạn đẩy lại được sau $hours giờ nữa.';
  }

  @override
  String get plansTitle => 'Gói tài khoản';

  @override
  String get plansSubtitle => 'Trả bằng Xu, mỗi lần dùng 30 ngày';

  @override
  String get plansCurrent => 'Gói hiện tại';

  @override
  String plansCurrentUntil(String date) {
    return 'Dùng đến $date';
  }

  @override
  String get plansFree => 'Miễn phí';

  @override
  String get plansPersonalBenefitFree =>
      '1 đến 3 tin miễn phí mỗi chuyên mục, tối đa 5 tin';

  @override
  String get plansPersonalBenefitPay => 'Hết suất thì đăng thêm bằng Xu';

  @override
  String plansPrice(int price) {
    return '$price xu / 30 ngày';
  }

  @override
  String plansBenefitActive(int count) {
    return '$count tin đang hiển thị cùng lúc';
  }

  @override
  String plansBenefitDaily(int count) {
    return '$count tin mới mỗi ngày';
  }

  @override
  String plansBenefitDrafts(int count) {
    return 'Giữ $count tin nháp';
  }

  @override
  String plansBenefitBoosts(int count) {
    return '$count lượt đẩy tin miễn phí mỗi tháng';
  }

  @override
  String plansBenefitBoostDiscount(int percent) {
    return 'Giảm $percent% giá đẩy tin';
  }

  @override
  String get plansBenefitPriority => 'Ưu tiên hiển thị trong chuyên mục chính';

  @override
  String get plansBenefitShopPage => 'Trang cửa hàng riêng (sắp có)';

  @override
  String get plansBuy => 'Mua gói';

  @override
  String get plansRenew => 'Gia hạn';

  @override
  String get plansUpgrade => 'Nâng cấp';

  @override
  String get plansInUse => 'Đang dùng';

  @override
  String get plansLowerLocked => 'Chọn được khi gói hiện tại hết hạn';

  @override
  String get plansNote =>
      'Nâng gói giữa kỳ được trừ phần còn lại của gói cũ. Gia hạn thì cộng thêm 30 ngày. Xu bị trừ ngay, gói có hiệu lực luôn.';

  @override
  String get plansCheckoutPrice => 'Giá gói';

  @override
  String get plansCheckoutCredit => 'Trừ phần còn lại của gói cũ';

  @override
  String get plansCheckoutTotal => 'Cần trả';

  @override
  String get plansCheckoutUntil => 'Dùng đến';

  @override
  String get plansCheckoutCategory => 'Chuyên mục chính';

  @override
  String get plansCheckoutCategoryHint =>
      'Tin ở chuyên mục này được ưu tiên hiển thị.';

  @override
  String plansCredits(int count) {
    return '$count xu';
  }

  @override
  String plansPay(int amount) {
    return 'Thanh toán $amount xu';
  }

  @override
  String plansActivated(String name) {
    return 'Đã kích hoạt gói $name';
  }

  @override
  String get plansLoadError => 'Không tải được danh sách gói.';

  @override
  String get plansActionError => 'Không thực hiện được. Vui lòng thử lại.';

  @override
  String get plansUpgradeAction => 'Nâng cấp gói';

  @override
  String get postingUpgradeHint => 'Cần đăng nhiều hơn? Nâng cấp gói';

  @override
  String get hotSaleTitle => 'Hot sale';

  @override
  String get featureAction => 'Lên Hot sale';

  @override
  String get featureSheetMessage =>
      'Tin hiện ở mục Hot sale trên trang chủ và đầu trang chuyên mục, xếp trên các tin khác trong suốt thời gian đã chọn.';

  @override
  String featureDays(int days) {
    return '$days ngày';
  }

  @override
  String featurePay(int credits) {
    return 'Mua · $credits xu';
  }

  @override
  String get featureDone => 'Tin đã lên Hot sale';

  @override
  String featureRunning(String date) {
    return 'Tin đang ở Hot sale đến $date.';
  }

  @override
  String get featureUnavailable =>
      'Chỉ tin đang hiển thị mới lên được Hot sale.';

  @override
  String get featureNoOptions => 'Hiện chưa có gói Hot sale nào đang bán.';

  @override
  String accExpiresOn(String date, int days) {
    return 'Hết hạn $date · còn $days ngày';
  }

  @override
  String accExpiredOn(String date) {
    return 'Đã hết hạn $date';
  }

  @override
  String previewDisplayDays(int days) {
    return 'Tin hiển thị $days ngày kể từ khi được duyệt. Gần hết hạn bạn có thể gia hạn, hết hạn thì kích hoạt lại.';
  }

  @override
  String get hotSaleSubtitle =>
      'Tin đang được người bán ưu tiên hiển thị, cập nhật liên tục.';

  @override
  String get hotSaleLoadError => 'Không tải được tin Hot sale';

  @override
  String get hotSaleEmptyTitle => 'Chưa có tin Hot sale';

  @override
  String get hotSaleEmptyBody =>
      'Các tin được người bán đưa lên Hot sale sẽ hiện ở đây.';

  @override
  String get hotSaleEnd => 'Đã xem hết tin Hot sale';

  @override
  String get displayDaysTitle => 'Thời gian hiển thị';

  @override
  String displayDaysFree(int days) {
    return 'Miễn phí $days ngày';
  }

  @override
  String displayDaysPlus(int days) {
    return '+$days ngày';
  }

  @override
  String displayDaysRange(String start, String end, int days) {
    return '$start → $end · $days ngày';
  }

  @override
  String get displayDaysStart => 'Bắt đầu';

  @override
  String get displayDaysEnd => 'Kết thúc';

  @override
  String get displayDaysToday => 'Hôm nay, khi tin được duyệt';

  @override
  String get displayDaysCount => 'Số ngày hiển thị';

  @override
  String get displayDaysExtraCount => 'Số ngày thêm';

  @override
  String displayDaysIncluded(int free) {
    return 'Gồm $free ngày miễn phí của chuyên mục';
  }

  @override
  String displayDaysExtraPrice(int days, int credits) {
    return 'Thêm $days ngày: $credits xu';
  }

  @override
  String get displayDaysNoCharge => 'Miễn phí';

  @override
  String displayDaysPackSave(int days, int credits) {
    return 'Giá theo mốc $days ngày, tiết kiệm $credits xu';
  }

  @override
  String displayDaysSuggest(int days, int credits) {
    return 'Lấy $days ngày chỉ $credits xu';
  }

  @override
  String displayDaysMax(int days) {
    return 'Chuyên mục này hiển thị tối đa $days ngày.';
  }

  @override
  String get displayDaysPayNote =>
      'Xu được giữ khi gửi tin, trừ khi tin được duyệt, hoàn lại nếu bị từ chối.';

  @override
  String get displayDaysDone => 'Xong';

  @override
  String get displayDaysCardHint => 'Chạm để đổi ngày bắt đầu hoặc thêm ngày';

  @override
  String displayDaysScheduled(String date) {
    return 'Hẹn hiện từ $date';
  }

  @override
  String extendNewEnd(String date) {
    return 'Hết hạn mới: $date';
  }

  @override
  String extendCurrentEnd(String date) {
    return 'Đang hiển thị đến $date';
  }

  @override
  String extendAddable(int days) {
    return 'Thêm được tối đa $days ngày nữa';
  }

  @override
  String extendLimitReached(int days) {
    return 'Tin đã hiển thị tối đa $days ngày, chưa gia hạn thêm được.';
  }

  @override
  String get extendChargeNote => 'Xu bị trừ ngay, không cần duyệt lại.';

  @override
  String get autoExtendTitle => 'Tự gia hạn 30 ngày';

  @override
  String autoExtendBody(int credits) {
    return 'Khi tin còn dưới 1 ngày, tự trừ $credits xu nếu ví đủ.';
  }

  @override
  String get autoExtendOn => 'Đã bật tự gia hạn';

  @override
  String get autoExtendOff => 'Đã tắt tự gia hạn';

  @override
  String accExtendedDays(int days) {
    return 'Đã gia hạn thêm $days ngày';
  }

  @override
  String get displayDaysTodayShort => 'Hôm nay';

  @override
  String get displayDaysShortTitle => 'Không đủ xu cho ngày thêm';

  @override
  String displayDaysShortBody(int missing) {
    return 'Ví còn thiếu $missing xu để hiển thị thêm ngày. Bạn có thể nạp xu, hoặc đăng với số ngày miễn phí.';
  }

  @override
  String displayDaysUseFree(int days) {
    return 'Đăng với $days ngày miễn phí';
  }

  @override
  String get originalPriceLabel => 'Giá gốc (trước giảm)';

  @override
  String get originalPricePlaceholder => 'Để trống nếu không giảm giá';

  @override
  String get originalPriceHint =>
      'Dành cho shop: người mua thấy giá gốc gạch ngang và % giảm. Sau khi đăng không sửa tăng được.';

  @override
  String originalPriceDiscount(int percent) {
    return 'Giảm $percent% so với giá gốc';
  }

  @override
  String get originalPriceError => 'Giá gốc phải cao hơn giá bán';

  @override
  String get promoTitle => 'Quảng bá tin';

  @override
  String get promoNotPromotable =>
      'Tin chưa hiển thị nên chưa quảng bá được. Hiện lại tin trong Quản lý tin rồi quay lại đây.';

  @override
  String promoBoostRunning(String date) {
    return 'Đang ở đầu danh sách đến $date';
  }

  @override
  String promoBoostAgainAt(String date) {
    return 'Đẩy lại sau $date';
  }

  @override
  String get promoRunning => 'Đang chạy';

  @override
  String get promoHistoryTitle => 'Lượt quảng bá gần đây';

  @override
  String get promoHistoryEmpty => 'Tin này chưa được quảng bá lần nào.';

  @override
  String promoHistoryFeature(int days) {
    return 'Hot sale $days ngày';
  }

  @override
  String get promoFree => 'Lượt tặng';

  @override
  String get promoEnded => 'Đã kết thúc';

  @override
  String get promoLoadError => 'Không tải được thông tin quảng bá';

  @override
  String promoBalanceAfter(int left) {
    return 'Ví còn $left xu sau khi trả.';
  }

  @override
  String get promoPickTitle => 'Chọn tin để quảng bá';

  @override
  String get promoPickSubtitle =>
      'Chỉ tin đang hiển thị mới đẩy hoặc lên Hot sale được';

  @override
  String get promoPickEmpty => 'Bạn chưa có tin nào đang hiển thị.';

  @override
  String get hubTitle => 'Quảng bá';

  @override
  String hubFreeBoosts(int left, int perMonth) {
    return 'Đẩy miễn phí còn $left/$perMonth lượt';
  }

  @override
  String hubThisMonth(int boosts, int features) {
    return 'Tháng này: $boosts lượt đẩy · $features lượt Hot sale';
  }

  @override
  String get hubFilterAll => 'Tất cả';

  @override
  String get hubFilterRunning => 'Đang quảng bá';

  @override
  String get hubFilterExpiring => 'Sắp hết hạn';

  @override
  String get hubFilterIdle => 'Chưa quảng bá';

  @override
  String hubBoostedFor(String time) {
    return 'Đang đẩy · còn $time';
  }

  @override
  String hubFeaturedFor(String time) {
    return 'Hot sale · còn $time';
  }

  @override
  String hubExpiresIn(String time) {
    return 'Hết hạn sau $time';
  }

  @override
  String hubHours(int count) {
    return '$count giờ';
  }

  @override
  String hubDays(int count) {
    return '$count ngày';
  }

  @override
  String get hubAutoExtend => 'Tự gia hạn';

  @override
  String get hubDetails => 'Chi tiết';

  @override
  String get hubEmptyRunning =>
      'Chưa có tin nào đang được đẩy hoặc ở Hot sale.';

  @override
  String get hubEmptyExpiring => 'Không có tin nào hết hạn trong 7 ngày tới.';

  @override
  String get hubEmptyIdle => 'Tin nào của bạn cũng đang được quảng bá.';

  @override
  String hubExpiringTip(int count) {
    return '$count tin sắp hết hạn: gia hạn để tin không bị ẩn.';
  }

  @override
  String get insTitle => 'Thống kê';

  @override
  String insRangeDays(int days) {
    return '$days ngày';
  }

  @override
  String get insViews => 'Lượt xem';

  @override
  String get insSaves => 'Lượt lưu tin';

  @override
  String get insChats => 'Người nhắn tin';

  @override
  String insUp(int percent) {
    return 'Tăng $percent% so với kỳ trước';
  }

  @override
  String insDown(int percent) {
    return 'Giảm $percent% so với kỳ trước';
  }

  @override
  String get insSame => 'Bằng kỳ trước';

  @override
  String get insNew => 'Kỳ trước chưa có';

  @override
  String get insChartTitle => 'Lượt xem theo ngày';

  @override
  String get insChartEmpty => 'Chưa có lượt xem nào trong khoảng này.';

  @override
  String insChartDay(String date, int views, int saves) {
    return '$date: $views lượt xem · $saves lượt lưu';
  }

  @override
  String get insChartHint => 'Chạm vào cột để xem từng ngày';

  @override
  String get insListingsTitle => 'Tin đăng';

  @override
  String get insActive => 'Đang bán';

  @override
  String get insPending => 'Chờ duyệt';

  @override
  String get insHidden => 'Đã ẩn';

  @override
  String get insSold => 'Đã bán';

  @override
  String get insTopTitle => 'Tin được xem nhiều';

  @override
  String insTopStats(int views, int saves) {
    return '$views lượt xem · $saves lượt lưu';
  }

  @override
  String get insTopEmpty => 'Chưa có tin nào đang hiển thị.';

  @override
  String get insTipsTitle => 'Gợi ý';

  @override
  String insTipBoost(String title) {
    return '\"$title\" đang được xem nhiều nhất. Đẩy tin để giữ ở đầu danh sách.';
  }

  @override
  String insTipExpiring(int count) {
    return '$count tin sắp hết hạn trong 7 ngày. Gia hạn để tin không bị ẩn.';
  }

  @override
  String get insTipNoViews =>
      'Tin chưa có lượt xem: thêm ảnh rõ, tiêu đề cụ thể và giá hợp lý để dễ được chú ý hơn.';

  @override
  String insPromotions(int boosts, int features) {
    return 'Trong kỳ: $boosts lượt đẩy · $features lượt Hot sale';
  }

  @override
  String get insLoadError => 'Không tải được thống kê';

  @override
  String get insViewsNote => 'Lượt xem theo ngày được ghi từ 11/11/2026.';

  @override
  String get spTitle => 'Poster shop';

  @override
  String get spCreate => 'Tạo poster';

  @override
  String get spLoadError => 'Không tải được poster';

  @override
  String get spNoShopTitle => 'Bạn chưa có trang shop';

  @override
  String get spNoShopBody =>
      'Poster hiện ở trang shop và trang Shop uy tín, nên cần có trang shop trước.';

  @override
  String get spPlanTitle => 'Poster dành cho gói Cửa hàng';

  @override
  String get spPlanBody =>
      'Nâng lên gói Cửa hàng để chạy poster ở trang shop và trang Shop uy tín.';

  @override
  String get spSeePlans => 'Xem gói';

  @override
  String get spSlots => 'Poster cùng lúc';

  @override
  String get spMonthly => 'Đã gửi tháng này';

  @override
  String get spUnverified =>
      'Shop chưa được xác minh nên poster đã duyệt chưa hiện công khai.';

  @override
  String spCooldown(String date) {
    return 'Bạn bị tạm khóa gửi poster đến $date vì poster bị từ chối nhiều lần.';
  }

  @override
  String spRules(int min, int max) {
    return 'Ảnh 1200×600 (tỉ lệ 2:1), chạy $min đến $max ngày. Admin duyệt trong khoảng 24 giờ.';
  }

  @override
  String spMonthlyFull(int limit) {
    return 'Bạn đã gửi đủ $limit poster của tháng này.';
  }

  @override
  String get spFilterAll => 'Tất cả';

  @override
  String get spFilterRunning => 'Đang chạy';

  @override
  String get spFilterPending => 'Chờ duyệt';

  @override
  String get spFilterScheduled => 'Đã lên lịch';

  @override
  String get spFilterRejected => 'Bị từ chối';

  @override
  String get spFilterEnded => 'Đã kết thúc';

  @override
  String get spStateStopped => 'Đã dừng';

  @override
  String get spEmpty => 'Chưa có poster nào';

  @override
  String get spEmptyBody =>
      'Tạo poster đầu tiên để quảng bá chương trình của shop.';

  @override
  String get spEmptyFilter => 'Không có poster nào ở mục này.';

  @override
  String spDates(String start, String end, int days) {
    return '$start – $end · $days ngày';
  }

  @override
  String get spOpensShop => 'Bấm vào mở trang shop';

  @override
  String spOpensListing(String title) {
    return 'Bấm vào mở tin: $title';
  }

  @override
  String spRejectedReason(String reason) {
    return 'Lý do từ chối: $reason';
  }

  @override
  String get spReasonWrongSize => 'Sai kích thước ảnh';

  @override
  String get spReasonMisleadingPrice => 'Giá hoặc ưu đãi gây hiểu lầm';

  @override
  String get spReasonBrandMisuse => 'Dùng logo, thương hiệu không thuộc shop';

  @override
  String get spReasonProhibited => 'Nội dung bị cấm';

  @override
  String get spReasonTooMuchText => 'Quá nhiều chữ trên ảnh';

  @override
  String get spReasonOther => 'Lý do khác';

  @override
  String get spEdit => 'Sửa';

  @override
  String get spResubmit => 'Sửa và gửi lại';

  @override
  String get spStop => 'Dừng';

  @override
  String get spCancel => 'Hủy gửi';

  @override
  String get spStopTitle => 'Dừng poster này?';

  @override
  String get spStopBody => 'Poster ngừng hiện ngay và không chạy lại được.';

  @override
  String get spCancelTitle => 'Hủy poster đang chờ duyệt?';

  @override
  String get spCancelBody => 'Lượt gửi trong tháng không được hoàn lại.';

  @override
  String get spConfirmStop => 'Dừng poster';

  @override
  String get spConfirmCancel => 'Hủy poster';

  @override
  String get spKeep => 'Giữ lại';

  @override
  String get spStopped => 'Đã dừng poster';

  @override
  String get spNewTitle => 'Tạo poster';

  @override
  String get spEditTitle => 'Sửa poster';

  @override
  String get spImage => 'Ảnh poster';

  @override
  String get spPickImage => 'Chọn ảnh 1200×600';

  @override
  String get spChangeImage => 'Đổi ảnh';

  @override
  String get spImageHint =>
      'Chọn ảnh bất kỳ rồi kéo, thu phóng cho vừa khung 2:1. Chữ nên nằm sẵn trong ảnh.';

  @override
  String get spImageRequired => 'Hãy chọn ảnh poster.';

  @override
  String get spName => 'Tên chương trình';

  @override
  String get spNameHint => 'VD: Galaxy Week giảm tới 20%';

  @override
  String get spNameHelper =>
      'Không hiện trên ảnh, dùng cho trình đọc màn hình và để bạn dễ quản lý.';

  @override
  String get spNameRequired => 'Hãy nhập tên chương trình.';

  @override
  String get spOpens => 'Khi bấm vào poster';

  @override
  String get spOpenShop => 'Mở trang shop';

  @override
  String get spOpenListing => 'Mở một tin';

  @override
  String get spChooseListing => 'Chọn tin';

  @override
  String get spNoListings => 'Shop chưa có tin nào đang bán.';

  @override
  String get spListingRequired => 'Hãy chọn tin.';

  @override
  String get spStart => 'Ngày bắt đầu';

  @override
  String get spStartNow => 'Ngay khi được duyệt';

  @override
  String get spStartOn => 'Chọn ngày';

  @override
  String get spDuration => 'Thời gian chạy';

  @override
  String spDays(int days) {
    return '$days ngày';
  }

  @override
  String spEndsOn(String date) {
    return 'Kết thúc khoảng $date';
  }

  @override
  String get spEditRunningNote =>
      'Poster đang chạy sẽ tạm ẩn cho tới khi admin duyệt lại.';

  @override
  String get spSubmit => 'Gửi duyệt';

  @override
  String get spSubmitted =>
      'Đã gửi poster, admin sẽ duyệt trong khoảng 24 giờ.';

  @override
  String get spErrSlotFull =>
      'Khung giờ này đã đủ số poster chạy cùng lúc. Hãy chọn ngày khác hoặc dừng một poster.';

  @override
  String get spErrMonthly => 'Bạn đã gửi đủ số poster của tháng này.';

  @override
  String get spErrCooldown => 'Bạn đang bị tạm khóa gửi poster.';

  @override
  String get spErrPlan => 'Chỉ gói Cửa hàng mới đăng được poster.';

  @override
  String get spErrShop => 'Bạn cần có trang shop để đăng poster.';

  @override
  String get spErrListing => 'Tin này không còn bán, hãy chọn tin khác.';

  @override
  String get spErrStartLate => 'Chỉ hẹn ngày bắt đầu trước tối đa 14 ngày.';

  @override
  String get spErrImage => 'Tải ảnh thất bại, hãy thử ảnh khác.';

  @override
  String get spErrNotEditable => 'Poster đã kết thúc, hãy tạo poster mới.';

  @override
  String get spErrGeneric => 'Không gửi được, vui lòng thử lại.';

  @override
  String get spSchedule => 'Lịch chạy';

  @override
  String get spCropTitle => 'Căn chỉnh poster';

  @override
  String get spAdjust => 'Căn chỉnh lại';

  @override
  String get cropDone => 'Dùng ảnh này';

  @override
  String get cropFill => 'Lấp đầy khung';

  @override
  String get cropFit => 'Vừa toàn ảnh';

  @override
  String get cropZoom => 'Thu phóng';

  @override
  String get cropHint =>
      'Kéo để di chuyển, chụm hai ngón hoặc kéo thanh trượt để phóng to, thu nhỏ. Phần trống được tô bằng nền bạn chọn.';

  @override
  String get cropLowRes =>
      'Ảnh gốc khá nhỏ so với khung, ảnh có thể bị mờ. Thử thu nhỏ hoặc chọn ảnh lớn hơn.';

  @override
  String get cropLoadError => 'Không mở được ảnh này, hãy thử ảnh khác.';

  @override
  String get accAvatarSection => 'Ảnh đại diện';

  @override
  String get accAvatarHint =>
      'Ảnh hiển thị trong khung tròn ở hồ sơ, tin đăng và tin nhắn. Bấm Căn chỉnh để chọn phần ảnh muốn hiện.';

  @override
  String get accAdjustAvatar => 'Căn chỉnh';

  @override
  String get accAvatarCropTitle => 'Căn chỉnh ảnh đại diện';

  @override
  String get accInfoSection => 'Thông tin hồ sơ';

  @override
  String get accDisplayNameHint => 'VD: Nguyễn Văn A hoặc tên cửa hàng';

  @override
  String get accUsernameHelper =>
      '3–30 ký tự: chữ thường, số, dấu chấm hoặc gạch dưới.';

  @override
  String get accBioHint => 'Vài dòng giới thiệu về bạn hoặc cửa hàng';

  @override
  String get cropBackground => 'Nền';

  @override
  String get cropBgBlur => 'Mờ';

  @override
  String get cropBgAuto => 'Theo ảnh';

  @override
  String get cropBgWhite => 'Trắng';

  @override
  String get cropBgBlack => 'Đen';

  @override
  String get cropTrim => 'Bỏ viền thừa';

  @override
  String get cropTrimOn => 'Đã bỏ viền thừa';

  @override
  String get msTitle => 'Quản lý shop';

  @override
  String get msLoadError => 'Chưa tải được thông tin shop';

  @override
  String get msPlanTitle => 'Trang shop dành cho gói Cửa hàng';

  @override
  String get msPlanBody =>
      'Nâng cấp gói Cửa hàng để mở trang shop riêng với logo, ảnh bìa và poster, và có thể được xác minh để lên mục Shop uy tín.';

  @override
  String get msCreateTitle => 'Mở trang shop của bạn';

  @override
  String get msCreateBody =>
      'Đặt tên shop trước, sau đó bạn thêm logo, ảnh bìa và giới thiệu.';

  @override
  String get msCreateAction => 'Mở shop';

  @override
  String get msCreated => 'Đã mở trang shop';

  @override
  String get msName => 'Tên shop';

  @override
  String get msNameHint => 'VD: Góc Nhà Decor';

  @override
  String get msNameRequired => 'Tên shop từ 2 đến 60 ký tự.';

  @override
  String get msNameLocked =>
      'Shop đã xác minh nên không tự đổi tên được. Liên hệ ReStore nếu cần đổi.';

  @override
  String get msTagline => 'Câu giới thiệu ngắn';

  @override
  String get msTaglineHint => 'VD: Đồ decor handmade, giao nhanh nội thành';

  @override
  String get msDescription => 'Giới thiệu shop';

  @override
  String get msDescriptionHint =>
      'Shop bán gì, cam kết chất lượng, chính sách đổi trả...';

  @override
  String get msAddress => 'Địa chỉ hiển thị';

  @override
  String get msAddressHint => 'VD: Quận 1, TP. Hồ Chí Minh';

  @override
  String get msInfoSection => 'Thông tin shop';

  @override
  String get msColorSection => 'Màu nhận diện';

  @override
  String get msColorHint =>
      'Dùng cho logo chữ, ảnh bìa mặc định và điểm nhấn trên trang shop.';

  @override
  String get msColorAuto => 'Mặc định';

  @override
  String get msChangeCover => 'Đổi ảnh bìa';

  @override
  String get msChangeLogo => 'Đổi logo';

  @override
  String get msImageNew => 'Chọn ảnh mới';

  @override
  String get msImageAdjust => 'Căn chỉnh lại';

  @override
  String get msImageRemove => 'Xóa ảnh';

  @override
  String get msCoverCropTitle => 'Căn chỉnh ảnh bìa';

  @override
  String get msLogoCropTitle => 'Căn chỉnh logo';

  @override
  String get msStatFollowers => 'Người theo dõi';

  @override
  String get msStatListings => 'Tin đang bán';

  @override
  String get msStatPostersRunning => 'Poster đang chạy';

  @override
  String get msStatPostersPending => 'Poster chờ duyệt';

  @override
  String get msVerifiedTitle => 'Shop đã xác minh';

  @override
  String get msVerifiedBody => 'Shop đang hiện ở mục Shop uy tín.';

  @override
  String msCertificate(String code) {
    return 'Mã chứng nhận: $code.';
  }

  @override
  String get msUnverifiedTitle => 'Shop chưa xác minh';

  @override
  String get msUnverifiedBody =>
      'Shop chưa hiện ở mục Shop uy tín và poster chưa chạy được. Liên hệ ReStore để được xác minh.';

  @override
  String get msPlanExpiredTitle => 'Gói Cửa hàng đã hết hạn';

  @override
  String get msPlanExpiredBody =>
      'Poster của shop đang tạm ẩn. Gia hạn gói để poster chạy lại.';

  @override
  String get msViewPublic => 'Xem trang shop';

  @override
  String get msPosters => 'Poster shop';

  @override
  String get msPostersBody =>
      'Quảng bá shop bằng poster trên trang shop và Shop uy tín.';

  @override
  String get msSave => 'Lưu thay đổi';

  @override
  String get msSaved => 'Đã lưu thông tin shop';

  @override
  String get msErrExists => 'Bạn đã có trang shop.';

  @override
  String get msErrImage => 'Ảnh tải lên không hợp lệ, hãy thử ảnh khác.';

  @override
  String get msErrGeneric => 'Không lưu được, vui lòng thử lại.';

  @override
  String get followShopsTab => 'Shop';

  @override
  String get followShopsEmpty => 'Bạn chưa theo dõi shop nào';

  @override
  String get followShopsEmptyHint =>
      'Theo dõi shop uy tín để xem tin mới của họ ở cùng một chỗ.';

  @override
  String get followShopsBrowse => 'Khám phá Shop uy tín';

  @override
  String followShopsNewCount(int count) {
    return '$count tin mới';
  }

  @override
  String followShopsFollowerCount(int count) {
    return '$count người theo dõi';
  }

  @override
  String get followShopsFeedTitle => 'Shop bạn theo dõi';

  @override
  String get followShopsFeedCta => 'Xem tin mới';

  @override
  String followShopsFeedNew(int count) {
    return '$count tin mới trong 7 ngày qua';
  }

  @override
  String followShopsCount(int count) {
    return 'Đang theo dõi $count shop';
  }

  @override
  String get followShopsStripHint => 'Bấm vào shop để mở trang của shop';

  @override
  String get followShopsLatest => 'Tin mới nhất';

  @override
  String get followShopsLatestHint => 'Tin vừa đăng của các shop bạn theo dõi';

  @override
  String get followShopsListingsEmpty => 'Chưa có tin nào';

  @override
  String get followShopsListingsEmptyHint =>
      'Các shop bạn theo dõi chưa có tin đang bán.';

  @override
  String get followShopsEnd => 'Bạn đã xem hết tin mới';

  @override
  String get followShopsLoadError => 'Chưa tải được shop bạn theo dõi';

  @override
  String get msFollowersTitle => 'Người theo dõi shop';

  @override
  String msFollowersTitleCount(int count) {
    return 'Người theo dõi ($count)';
  }

  @override
  String get msFollowersEmpty => 'Chưa có ai theo dõi shop';

  @override
  String get msFollowersEmptyHint =>
      'Người mua theo dõi shop của bạn sẽ hiện ở đây.';

  @override
  String msFollowedSince(String date) {
    return 'Từ $date';
  }

  @override
  String get followingHubTitle => 'Đang theo dõi';

  @override
  String get followingHubSubtitle => 'Tin mới từ shop và người bạn theo dõi';

  @override
  String get followingHubOnboardSubtitle => 'Chọn vài shop để bắt đầu';

  @override
  String get followingHubManage => 'Quản lý danh sách theo dõi';

  @override
  String get followingHubPeopleTitle => 'Người bạn theo dõi';

  @override
  String get followingHubSeeAll => 'Xem tất cả';

  @override
  String get followingHubFeedTitle => 'Mới từ shop bạn theo dõi';

  @override
  String get followingHubFeedHint =>
      'Chọn một shop để xem riêng tin của shop đó';

  @override
  String get followingHubAll => 'Tất cả';

  @override
  String get followingHubOpenShop => 'Xem shop';

  @override
  String get followingHubSuggestHint =>
      'Ưu tiên shop hợp danh mục bạn hay xem, lưu và đối tác của ReStore';

  @override
  String get followingHubOnboardTitle => 'Theo dõi shop để không bỏ lỡ tin mới';

  @override
  String get followingHubOnboardBody =>
      'Bấm Theo dõi ở các shop bên dưới, tin mới của họ sẽ gom về trang này.';

  @override
  String get followingHubBenefitFeed => 'Tin mới của mọi shop gom về một chỗ';

  @override
  String get followingHubBenefitFilter => 'Lọc nhanh theo từng shop';

  @override
  String get followingHubBenefitVerified => 'Chỉ shop đã được ReStore xác minh';

  @override
  String get followingHubNoSuggestions => 'Chưa có shop nào để gợi ý';

  @override
  String followingHubSeeFeed(int count) {
    return 'Xem tin mới từ $count shop';
  }

  @override
  String followShopsFollowerCountText(String count) {
    return '$count người theo dõi';
  }

  @override
  String get followingHubPostsTitle => 'Bạn bè vừa đăng';

  @override
  String get followingHubPostsHint =>
      'Bài mới trên Bảng tin của người bạn theo dõi';

  @override
  String get followingHubForYouTitle => 'Shop dành cho bạn';

  @override
  String get followingHubPartner => 'Đối tác';
}
