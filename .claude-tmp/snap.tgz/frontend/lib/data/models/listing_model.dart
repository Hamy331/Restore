import 'dart:ui' show PlatformDispatcher;

import 'package:equatable/equatable.dart';
import 'package:restore/data/models/enums/listing_condition.dart';
import 'package:restore/data/models/enums/listing_status.dart';
import 'package:restore/shared/models/geo_point.dart';
import 'package:restore/shared/models/localized_text.dart';
import 'package:restore/core/config/app_environment.dart';
import 'package:restore/modules/location/models/address_info.dart';

/// Một dòng của bảng Listing (prisma/schema.prisma), tên khoá JSON giống
/// tên cột (camelCase).
///
/// Các trường đánh dấu "(đề xuất)" chưa có trong schema hiện tại; chúng theo
/// docs/listing-api-contract.md và để null cho tới khi backend thêm cột.
class ListingModel extends Equatable {
  final String id;
  final String ownerId;
  final String title;
  final String description;

  /// Giá VND. Cột Decimal nên API có thể trả về chuỗi hoặc số.
  final int? price;

  /// (đề xuất) Giá gốc trước khi giảm, chỉ có khi tin đang giảm giá
  /// (lớn hơn [price])
  final int? originalPrice;
  final bool isNegotiable;
  final ListingCondition? condition;
  final ListingStatus status;
  final bool allowSale;
  final bool allowExchange;
  final List<String> images;
  final int viewCount;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  /// Hết hạn hiển thị (null = tin cũ / chưa duyệt); quá hạn thì tin tự ẩn
  final DateTime? expiresAt;

  /// Số xu đã trả cho tin (chỉ chủ tin thấy); > 0 thì tin không chiếm suất miễn phí
  final int paidCredits;

  /// Ngày hẹn bắt đầu hiển thị (null = hiện ngay khi duyệt)
  final DateTime? startsAt;

  /// Số ngày hiển thị người bán chọn lúc đăng (null = số ngày miễn phí)
  final int? displayDays;

  /// Tự gia hạn khi sắp hết hạn (chỉ chủ tin thấy, gói Cửa hàng)
  final bool autoExtend;

  /// (đề xuất) Danh mục và thuộc tính theo danh mục (jsonb)
  final String? categoryId;
  final String categoryName;
  final Map<String, Object?> attributes;

  /// (đề xuất) Mã tỉnh/thành, phường/xã và toạ độ cho tính năng "gần bạn"
  final String? provinceCode;
  final String? wardCode;
  final GeoPoint? geoPoint;
  final AddressInfo? address;
  final String sellerName;
  final String exchangeWish;
  final String? reviewReason;
  final String sellerType;
  final bool isFavorite;

  const ListingModel({
    required this.id,
    required this.ownerId,
    required this.title,
    required this.description,
    this.price,
    this.originalPrice,
    this.isNegotiable = true,
    this.condition,
    this.status = ListingStatus.available,
    this.allowSale = true,
    this.allowExchange = false,
    this.images = const [],
    this.viewCount = 0,
    this.createdAt,
    this.updatedAt,
    this.expiresAt,
    this.paidCredits = 0,
    this.startsAt,
    this.displayDays,
    this.autoExtend = false,
    this.categoryId,
    this.categoryName = '',
    this.attributes = const {},
    this.provinceCode,
    this.wardCode,
    this.geoPoint,
    this.address,
    this.sellerName = '',
    this.exchangeWish = '',
    this.reviewReason,
    this.sellerType = 'PERSONAL',
    this.isFavorite = false,
  });

  String? get coverImage => images.isEmpty ? null : images.first;

  /// Phần trăm giảm so với [originalPrice] (làm tròn), null khi không giảm
  int? get discountPercent {
    final price = this.price;
    final originalPrice = this.originalPrice;
    if (price == null || originalPrice == null || originalPrice <= price) {
      return null;
    }
    final percent = ((1 - price / originalPrice) * 100).round();
    return percent > 0 ? percent : null;
  }

  static int? _parseMoney(Object? value) =>
      value is num ? value.toInt() : num.tryParse('$value')?.toInt();

  factory ListingModel.fromJson(
    Map<String, dynamic> json, {
    String? apiBaseUrl,
  }) {
    final location = json['location'];
    return ListingModel(
      id: '${json['id']}',
      ownerId: '${json['ownerId'] ?? ''}',
      title: json['title'] as String? ?? '',
      description: json['description'] as String? ?? '',
      price: _parseMoney(json['price']),
      originalPrice: _parseMoney(json['originalPrice']),
      isNegotiable: json['isNegotiable'] as bool? ?? true,
      condition: ListingCondition.fromApi(json['condition'] as String?),
      status:
          ListingStatus.fromApi(json['status'] as String?) ??
          ListingStatus.available,
      allowSale: json['allowSale'] as bool? ?? true,
      allowExchange: json['allowExchange'] as bool? ?? false,
      images: [
        for (final image in json['images'] as List? ?? const [])
          '$image'.startsWith('/api/')
              ? '${Uri.parse(apiBaseUrl ?? AppEnvironment.apiBaseUrl).origin}$image'
              : '$image',
      ],
      viewCount: (json['viewCount'] as num?)?.toInt() ?? 0,
      createdAt: DateTime.tryParse('${json['createdAt']}'),
      updatedAt: DateTime.tryParse('${json['updatedAt']}'),
      expiresAt: DateTime.tryParse('${json['expiresAt']}'),
      paidCredits: (json['paidCredits'] as num?)?.toInt() ?? 0,
      startsAt: DateTime.tryParse('${json['startsAt']}'),
      displayDays: (json['displayDays'] as num?)?.toInt(),
      autoExtend: json['autoExtend'] == true,
      categoryId: json['categoryId'] as String?,
      // Tên danh mục từ API là chuỗi hoặc map theo ngôn ngữ {vi, en}
      categoryName: LocalizedText.fromJson(
        (json['category'] as Map?)?['name'],
      ).resolve(PlatformDispatcher.instance.locale.languageCode),
      attributes: Map<String, Object?>.from(json['attributes'] as Map? ?? {}),
      provinceCode: location is Map
          ? location['provinceCode'] as String?
          : null,
      wardCode: location is Map ? location['wardCode'] as String? : null,
      geoPoint: location is Map && location['latitude'] != null
          ? GeoPoint.fromJson(Map<String, dynamic>.from(location))
          : null,
      address:
          location is Map &&
              location['province'] is Map &&
              location['ward'] is Map
          ? AddressInfo.fromJson({
              ...Map<String, dynamic>.from(location),
              'geoPoint': location['latitude'] == null
                  ? null
                  : {
                      'latitude': location['latitude'],
                      'longitude': location['longitude'],
                    },
              'isGeoPointFromDevice': location['geoSource'] == 'device',
            })
          : null,
      sellerName: (json['owner'] as Map?)?['fullName'] as String? ?? '',
      exchangeWish: json['exchangeWish'] as String? ?? '',
      reviewReason: json['reviewReason'] as String?,
      sellerType: json['sellerType'] as String? ?? 'PERSONAL',
      isFavorite: json['isFavorite'] == true,
    );
  }

  @override
  List<Object?> get props => [
    id,
    ownerId,
    title,
    description,
    price,
    originalPrice,
    isNegotiable,
    condition,
    status,
    allowSale,
    allowExchange,
    images,
    viewCount,
    createdAt,
    updatedAt,
    expiresAt,
    paidCredits,
    startsAt,
    displayDays,
    autoExtend,
    categoryId,
    categoryName,
    attributes,
    provinceCode,
    wardCode,
    geoPoint,
    address,
    sellerName,
    exchangeWish,
    reviewReason,
    sellerType,
    isFavorite,
  ];
}
